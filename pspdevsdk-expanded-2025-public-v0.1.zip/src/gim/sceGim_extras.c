static __inline__ int sceGimPicturePow2( int num )
{
	union { float f ; int i ; } u ;
	u.f = (float)num - 0.5f ;
	return 1 << ( ( u.i >> 23 ) - 126 ) ;
}
static __inline__ int sceGimPictureCLZ( int num )
{
	int i ;
	for ( i = 31 ; i >= 0 ; -- i ) if ( ( 1 << i ) & num ) return 31 - i ;
	return 32 ;
}
static __inline__ int sceGimPictureCTZ( int num )
{
	int i ;
	for ( i = 0 ; i <= 31 ; i ++ ) if ( ( 1 << i ) & num ) return i ;
	return 32 ;
}

/* ---------------------------------------------------------------- */
/*  image functions                                                 */
/* ---------------------------------------------------------------- */

static __inline__ int sceGimImageGetFormat( const SceGimImageHeader *image )
{
	return image->format ;
}

static __inline__ int sceGimImageGetOrder( const SceGimImageHeader *image )
{
	return image->order ;
}

static __inline__ int sceGimImageGetBPP( const SceGimImageHeader *image )
{
	return image->bpp ;	/* bits per pixel */
}

static __inline__ int sceGimImageGetWidth( const SceGimImageHeader *image, int level )
{
	int width = image->width ;
	if ( level > 0 && image->level_type == SCEGIM_TYPE_MIPMAP ) {
		while ( -- level >= 0 ) width = ( width + 1 ) / 2 ;
	}
	return width ;
}

static __inline__ int sceGimImageGetHeight( const SceGimImageHeader *image, int level )
{
	int height = image->height ;
	if ( level > 0 && image->level_type == SCEGIM_TYPE_MIPMAP ) {
		while ( -- level >= 0 ) height = ( height + 1 ) / 2 ;
	}
	return height ;
}

static __inline__ int sceGimImageGetPitch( const SceGimImageHeader *image, int width )
{
	int align = image->pitch_align * 8 - 1 ;
	return ( ( image->bpp * width + align ) & ~align ) / 8 ;
}

static __inline__ int sceGimImageGetBufWidth( const SceGimImageHeader *image, int width )
{
	int align = image->pitch_align * 8 / image->bpp - 1 ;
	return ( width + align ) & ~align ;
}

static __inline__ int sceGimImageGetBufHeight( const SceGimImageHeader *image, int height )
{
	int align = image->height_align - 1 ;
	return ( height + align ) & ~align ;
}

static __inline__ int sceGimImageGetTexWidth( const SceGimImageHeader *image, int width )
{
	(void)image ;
	return sceGimPicturePow2( width ) ;
}

static __inline__ int sceGimImageGetTexHeight( const SceGimImageHeader *image, int height )
{
	(void)image ;
	return sceGimPicturePow2( height ) ;
}

static __inline__ int sceGimImageGetPlaneMask( const SceGimImageHeader *image )
{
	return image->plane_mask ;
}

static __inline__ int sceGimImageGetLevelCount( const SceGimImageHeader *image )
{
	return image->level_count ;
}

static __inline__ int sceGimImageGetFrameCount( const SceGimImageHeader *image )
{
	return image->frame_count ;
}

static __inline__ void *sceGimImageGetUserData( const SceGimImageHeader *image )
{
	if ( image->offsets <= image->header_size ) return 0 ;
	return (char *)image + image->header_size ;
}

static __inline__ int sceGimImageGetUserDataSize( const SceGimImageHeader *image )
{
	return image->offsets - image->header_size ;
}

static __inline__ void *sceGimImageGetPixels( const SceGimImageHeader *image, int level, int frame )
{
	void **offsets = (void **)( (char *)image + image->offsets ) ;
	int n_levels = image->level_count ;
	int n_frames = image->frame_count ;
	if ( level < 0 || level >= n_levels ) return 0 ;
	frame %= n_frames ;
	if ( frame < 0 ) frame += n_frames ;
	return offsets[ n_levels * frame + level ] ;
}

static __inline__ int SCEGIM_CHUNK_TYPE( SceGimChunk *chunk )
{
	return chunk->type ;
}

static __inline__ SceGimChunk *SCEGIM_CHUNK_NEXT( SceGimChunk *chunk )
{
	return (SceGimChunk *)( (char *)chunk + chunk->next_offs ) ;
}

static __inline__ SceGimChunk *SCEGIM_CHUNK_CHILD( SceGimChunk *chunk )
{
	return (SceGimChunk *)( (char *)chunk + chunk->child_offs ) ;
}

static __inline__ void *SCEGIM_CHUNK_DATA( SceGimChunk *chunk )
{
	return (SceGimChunk *)( (char *)chunk + chunk->data_offs ) ;
}

static __inline__ int SCEGIM_CHUNK_SIZE( SceGimChunk *chunk )
{
	return chunk->next_offs ;
}

static __inline__ int SCEGIM_CHUNK_TAG_SIZE( SceGimChunk *chunk )
{
	(void)chunk ;
	return 16 ;
}

static __inline__ int SCEGIM_CHUNK_DATA_SIZE( SceGimChunk *chunk )
{
	return chunk->child_offs - chunk->data_offs ;
}

static __inline__ int SCEGIM_CHUNK_CHILD_SIZE( SceGimChunk *chunk )
{
	return chunk->next_offs - chunk->child_offs ;
}

static __inline__ void *SCEGIM_CHUNK_SKIPSTRING( const char *str, int align )
{
	str += strlen( str ) + 1 ;
	align -= 1 ;
	return (void *)( ( (int)str + align ) & ~align ) ;
}
