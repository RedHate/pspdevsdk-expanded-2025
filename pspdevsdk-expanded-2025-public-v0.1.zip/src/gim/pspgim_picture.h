
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#ifndef SCEGIM_TARGET_PREVIEWER
#include <stdbool.h>
#include <pspgu.h>
#include <pspgum.h>
#endif /* SCEGIM_TARGET_PREVIEWER */

#include <pspgim_format.h>

/* ---------------------------------------------------------------- */
/*  enums                                                           */
/* ---------------------------------------------------------------- */

enum SceGimDuplicate{
	SCEGIM_DUPLICATE_REFERENCE	= 0x0000,
	SCEGIM_DUPLICATE_STRUCTURE	= 0x0001,
	SCEGIM_DUPLICATE_AUTOMATIC	= 0x0002,

	SCEGIM_DUPLICATE_PICTURE	= 0x0008,
	SCEGIM_DUPLICATE_IMAGE		= 0x0010,
	SCEGIM_DUPLICATE_PALETTE	= 0x0020,
	SCEGIM_DUPLICATE_SEQUENCE	= 0x0040
} ;

enum SceGimEnable{
	SCEGIM_ENABLE_ALL			= 0xffff,
	SCEGIM_ENABLE_DISSOLVE		= 0x0001,
	SCEGIM_ENABLE_FACTOR		= 0x0002,
	SCEGIM_ENABLE_CROP			= 0x0004,
	SCEGIM_ENABLE_BLEND			= 0x0100,
	SCEGIM_ENABLE_FUNC			= 0x0200,
	SCEGIM_ENABLE_FILTER		= 0x0400,
	SCEGIM_ENABLE_WRAP			= 0x0800,
} ;

/* ---------------------------------------------------------------- */
/*  classes                                                         */
/* ---------------------------------------------------------------- */

typedef struct SceGimPicture SceGimPicture ;

/* ---------------------------------------------------------------- */
/*  callback                                                        */
/* ---------------------------------------------------------------- */

void sceGimPictureSetMemoryManager( void *(*alloc_func)( size_t ), void (*free_func)( void * ) ) ;
void sceGimPictureSetMemoryManager2( void *(*alloc_func)( size_t ), void (*free_func)( void * ) ) ;

void *sceGimPictureAllocMemory( size_t size ) ;
void sceGimPictureFreeMemory( void *addr ) ;
void *sceGimPictureAllocMemory2( size_t size ) ;
void sceGimPictureFreeMemory2( void *addr ) ;

/* ---------------------------------------------------------------- */
/*  picture file                                                    */
/* ---------------------------------------------------------------- */

bool sceGimPictureCheckFileHeader( const void *buf, int size ) ;
int sceGimPictureGetChunkCount( const void *buf, int size ) ;
SceGimChunk *sceGimPictureGetChunk( const void *buf, int size, int index ) ;

/* ---------------------------------------------------------------- */
/*  picture class                                                   */
/* ---------------------------------------------------------------- */

SceGimPicture *sceGimPictureCreate( SceGimChunk *chunk ) ;
void sceGimPictureDelete( SceGimPicture *picture ) ;
SceGimPicture *sceGimPictureDuplicate( SceGimPicture *picture, int flags ) ;

bool sceGimPictureLoadFile( SceGimPicture *picture, const void *buf, int size, int index ) ;
bool sceGimPictureLoadTm2( SceGimPicture *picture, const void *buf, int size, int index ) ;
bool sceGimPictureLoadTga( SceGimPicture *picture, const void *buf, int size ) ;
bool sceGimPictureLoadBmp( SceGimPicture *picture, const void *buf, int size ) ;

bool sceGimPictureLoad( SceGimPicture *picture, SceGimChunk *chunk ) ;
void sceGimPictureUnload( SceGimPicture *picture ) ;
void sceGimPictureAnimate( SceGimPicture *picture, float step ) ;
void sceGimPictureControl( SceGimPicture *picture, int param, float value ) ;
void sceGimPictureActivate( SceGimPicture *picture ) ;
void sceGimPictureActivateTexture( SceGimPicture *picture ) ;
void sceGimPictureActivateRenderState( SceGimPicture *picture ) ;
bool sceGimPictureLoadCache( SceGimPicture *picture ) ;
void sceGimPictureUnloadCache( SceGimPicture *picture ) ;

void sceGimPictureSetEnableBits( SceGimPicture *picture, int bits, int value ) ;
int sceGimPictureGetEnableBits( SceGimPicture *picture ) ;
void sceGimPictureSetImageCrop( SceGimPicture *picture, const float *crop ) ;
const float *sceGimPictureGetImageCrop( SceGimPicture *picture ) ;

SceGimImageHeader *sceGimPictureGetImage( SceGimPicture *picture ) ;
SceGimPaletteHeader *sceGimPictureGetPalette( SceGimPicture *picture ) ;
void *sceGimPictureGetImagePixels( SceGimPicture *picture, int level, int frame ) ;
void *sceGimPictureGetPalettePixels( SceGimPicture *picture, int level, int frame ) ;
void sceGimPictureSetImagePixels( SceGimPicture *picture, int level, int frame, void *pixels ) ;
void sceGimPictureSetPalettePixels( SceGimPicture *picture, int level, int frame, void *pixels ) ;
bool sceGimPictureReallocImage( SceGimPicture *picture, int format, int w, int h, int level, int frame, void *pixels ) ;
bool sceGimPictureReallocPalette( SceGimPicture *picture, int format, int w, int level, int frame, void *pixels ) ;

bool sceGimPictureHasAnimation( SceGimPicture *picture ) ;
void sceGimPictureSetFrameLoop( SceGimPicture *picture, float start, float end ) ;
const float *sceGimPictureGetFrameLoop( SceGimPicture *picture ) ;
void sceGimPictureSetFrameRate( SceGimPicture *picture, float fps ) ;
float sceGimPictureGetFrameRate( SceGimPicture *picture ) ;
void sceGimPictureSetFrameRepeat( SceGimPicture *picture, int mode ) ;
int sceGimPictureGetFrameRepeat( SceGimPicture *picture ) ;
void sceGimPictureSetFrame( SceGimPicture *picture, float frame ) ;
float sceGimPictureGetFrame( SceGimPicture *picture ) ;
void sceGimPictureSetImageFrame( SceGimPicture *picture, int frame ) ;
int sceGimPictureGetImageFrame( SceGimPicture *picture ) ;
void sceGimPictureSetImageFrame2( SceGimPicture *picture, int frame ) ;
int sceGimPictureGetImageFrame2( SceGimPicture *picture ) ;
void sceGimPictureSetPaletteFrame( SceGimPicture *picture, int frame ) ;
int sceGimPictureGetPaletteFrame( SceGimPicture *picture ) ;
void sceGimPictureSetPaletteFrame2( SceGimPicture *picture, int frame ) ;
int sceGimPictureGetPaletteFrame2( SceGimPicture *picture ) ;
void sceGimPictureSetDissolve( SceGimPicture *picture, float dissolve ) ;
float sceGimPictureGetDissolve( SceGimPicture *picture ) ;

int sceGimPictureGetSequenceCount( SceGimPicture *picture ) ;
SceGimSequenceHeader *sceGimPictureGetSequence( SceGimPicture *picture, int index ) ;
void sceGimPictureSetCurrentSequence( SceGimPicture *picture, int index ) ;
int sceGimPictureGetCurrentSequence( SceGimPicture *picture ) ;

int sceGimPictureGetImagePlaneCount( SceGimPicture *picture ) ;
void sceGimPictureSetImagePlane( SceGimPicture *picture, int plane ) ;
int sceGimPictureGetImagePlane( SceGimPicture *picture ) ;
void sceGimPictureSetPaletteOffset( SceGimPicture *picture, int shift, int mask, int offs ) ;
const int *sceGimPictureGetPaletteOffset( SceGimPicture *picture ) ;

void sceGimPictureSetBlend( SceGimPicture *picture, int mode ) ;
const int *sceGimPictureGetBlend( SceGimPicture *picture ) ;
void sceGimPictureSetFunc( SceGimPicture *picture, int mode, int comp ) ;
const int *sceGimPictureGetFunc( SceGimPicture *picture ) ;
void sceGimPictureSetFilter( SceGimPicture *picture, int mag, int min ) ;
const int *sceGimPictureGetFilter( SceGimPicture *picture ) ;
void sceGimPictureSetWrap( SceGimPicture *picture, int u, int v ) ;
const int *sceGimPictureGetWrap( SceGimPicture *picture ) ;

/* ---------------------------------------------------------------- */
/*  compatibility functions                                         */
/* ---------------------------------------------------------------- */

void sceGimPictureInitDevice( void *device, int flags ) ;
void sceGimPictureTermDevice() ;

int sceGimPicturePow2( int num );
int sceGimPictureCLZ( int num );
int sceGimPictureCTZ( int num );

/* ---------------------------------------------------------------- */
/*  image functions                                                 */
/* ---------------------------------------------------------------- */

int sceGimImageGetFormat( const SceGimImageHeader *image );
int sceGimImageGetOrder( const SceGimImageHeader *image );
int sceGimImageGetBPP( const SceGimImageHeader *image );
int sceGimImageGetWidth( const SceGimImageHeader *image, int level );
int sceGimImageGetHeight( const SceGimImageHeader *image, int level );
int sceGimImageGetPitch( const SceGimImageHeader *image, int width );
int sceGimImageGetBufWidth( const SceGimImageHeader *image, int width );
int sceGimImageGetBufHeight( const SceGimImageHeader *image, int height );
int sceGimImageGetTexWidth( const SceGimImageHeader *image, int width );
int sceGimImageGetTexHeight( const SceGimImageHeader *image, int height );
int sceGimImageGetPlaneMask( const SceGimImageHeader *image );
int sceGimImageGetLevelCount( const SceGimImageHeader *image );
int sceGimImageGetFrameCount( const SceGimImageHeader *image );
void *sceGimImageGetUserData( const SceGimImageHeader *image );
int sceGimImageGetUserDataSize( const SceGimImageHeader *image );
void *sceGimImageGetPixels( const SceGimImageHeader *image, int level, int frame );
