/*
 * PSP Software Development Kit Expansion - https://github.com/redhate/pspdev
 * -----------------------------------------------------------------------
 * Licensed under the BSD license, see LICENSE in PSPSDK root for details.
 *
 * pspmpeg.h - Prototypes for the libmpeg library
 *
 * Copyright (c) 2025 ultros
 *
 */

#ifndef __LIBMPEG_H__
#define __LIBMPEG_H__

// MPEG PACK SIZE
#define	SCE_MPEG_PACK_SIZE					(2048)

// LIBMPEG ERROR CODES
#define _SCE_MPEG_API_COMPLETION			(0x8001)
#define	_SCE_MPEG_API_PACKHEADER_FIELDFLAG	(0x8002)
#define	_SCE_MPEG_API_RINGBUFFER			(0x8003)
#define	_SCE_MPEG_API_NO_RAPI				(0x8004)
#define	_SCE_MPEG_API_ALREADY_USED			(0x8005)
#define	_SCE_MPEG_API_INTERNAL				(0x8006)
#define	_SCE_MPEG_API_ILLEGAL_STREAM		(0x8007)

// AVC DECODE ERRORS
#define _SCE_MPEG_VIDEO_CODEC_ERROR			(0x8001)
#define _SCE_MPEG_VIDEO_CODEC_FATAL			(0x8002)


// ERROR CODES
#define SCE_MPEG_OK		SCE_OK
#define SCE_MPEG_ERROR_NOT_COMPLETED		SCE_ERROR_MAKE_ERROR(SCE_ERROR_FACILITY_MPEG, _SCE_MPEG_API_COMPLETION)
#define SCE_MPEG_ERROR_INVALID_VALUE		SCE_ERROR_MAKE_ERROR(SCE_ERROR_FACILITY_MPEG,  SCE_ERROR_INVALID_VALUE)
#define SCE_MPEG_ERROR_UNMATCHED_VERSION	SCE_ERROR_MAKE_ERROR(SCE_ERROR_FACILITY_MPEG,  SCE_ERROR_UNMATECHED_VERSION)
#define SCE_MPEG_ERROR_INVALID_POINTER		SCE_ERROR_MAKE_ERROR(SCE_ERROR_FACILITY_MPEG,  SCE_ERROR_INVALID_POINTER)
#define SCE_MPEG_ERROR_OUT_OF_MEMORY		SCE_ERROR_MAKE_ERROR(SCE_ERROR_FACILITY_MPEG,  SCE_ERROR_OUT_OF_MEMORY)
#define SCE_MPEG_ERROR_NO_RAPI				SCE_ERROR_MAKE_ERROR(SCE_ERROR_FACILITY_MPEG, _SCE_MPEG_API_NO_RAPI)
#define SCE_MPEG_ERROR_ALREADY_USED			SCE_ERROR_MAKE_ERROR(SCE_ERROR_FACILITY_MPEG, _SCE_MPEG_API_ALREADY_USED)
#define SCE_MPEG_ERROR_INTERNAL				SCE_ERROR_MAKE_ERROR(SCE_ERROR_FACILITY_MPEG, _SCE_MPEG_API_INTERNAL)
#define SCE_MPEG_ERROR_ILLEGAL_STREAM		SCE_ERROR_MAKE_ERROR(SCE_ERROR_FACILITY_MPEG, _SCE_MPEG_API_ILLEGAL_STREAM)

// VIDEO DECODER 
#define SCE_MPEG_ERROR_VIDEO_INVALID_VALUE  	SCE_ERROR_MAKE_ERROR(SCE_ERROR_FACILITY_AVC, SCE_ERROR_INVALID_VALUE)
#define SCE_MPEG_ERROR_VIDEO_UNMATCHED_VERSION 	SCE_ERROR_MAKE_ERROR(SCE_ERROR_FACILITY_AVC, SCE_ERROR_UNMATECHED_VERSION)
#define SCE_MPEG_ERROR_VIDEO_ERROR				SCE_ERROR_MAKE_ERROR(SCE_ERROR_FACILITY_AVC, _SCE_MPEG_VIDEO_CODEC_ERROR)
#define SCE_MPEG_ERROR_VIDEO_FATAL 				SCE_ERROR_MAKE_ERROR(SCE_ERROR_FACILITY_AVC, _SCE_MPEG_VIDEO_CODEC_FATAL)

// AUDIO DECOER 
#define SCE_MPEG_ERROR_AUDIO_INVALID_VALUE SCE_ERROR_MAKE_ERROR(SCE_ERROR_FACILITY_CODEC, 0x0001)
#define SCE_MPEG_ERROR_AUDIO_ERROR SCE_ERROR_MAKE_ERROR(SCE_ERROR_FACILITY_CODEC, 0x0002)

typedef SceUInt32 sceMpegStreamId;
typedef SceUChar8* sceMpegHandle;

typedef struct sceMpegTimeStamp {
	SceUInt32 MSB_ts;
	SceUInt32 ts;
} sceMpegTimeStamp;

#define SCE_MPEG_VOID_TIMESTAMP (-1)

typedef struct sceMpegAu {
	sceMpegTimeStamp pts;
	sceMpegTimeStamp dts;
	SceUChar8 *pEsBuf;
	SceInt32 iEsSize;
} sceMpegAu;

typedef struct sceMpegStream {
	sceMpegStreamId qStreamId;
	sceMpegStreamId qStreamIdMask;
	SceVoid *m_pRAPICtrlStream;
	SceUChar8 *m_pRAPI;
	SceInt32 m_iAuNum;
	SceInt32 m_iPesPacketForwardSize;
	SceInt32 m_iPesPacketForwardFlag;
	SceShort16 m_iPesPacketAULocator;
	SceShort16 reserved;
	SceInt32 m_iPesPacketNum;
	SceInt32 m_iAuSize;
	SceInt32 m_iBoundarySize;
	SceInt32 m_iAuSizeOfProceed;
	SceUInt32 m_iGetAuMode;
	SceInt32 m_iPayloadHeaderRemainderFlag;
	SceInt32 m_iPayloadHeaderRemainderSize;
	SceChar8 m_cPayloadHeaderBuf[4];
} sceMpegStream;

typedef struct sceMpeg {
    SceVoid *sys;		/* system data for decoding*/
} sceMpeg;

// STREAM TYPES 
typedef enum sceMpegStrType_enum{
	SCE_MPEG_STREAM_M4AVC		= 0, 	/* MPEG4 AVC video stream*/
	SCE_MPEG_STREAM_ATRAC		= 1,    /* ATRAC3plus stream*/
	SCE_MPEG_STREAM_PCM         = 2,    /* PCM data */
	SCE_MPEG_STREAM_AUDIO       = 15    /* ATRAC3plus or PCM */
} sceMpegStrType_enum;

typedef SceInt32 sceMpegStrType;


// -------------- PSMF ---------------
SceInt32 sceMpegQueryStreamOffset (sceMpeg *mp, const SceVoid* addr, SceUInt32* offset);
SceInt32 sceMpegQueryStreamSize (const SceVoid* addr, SceUInt32* stream_size);


// -------------- RING BUFFER --------------- 
typedef SceInt32 (*sceMpegRBCallback)(SceVoid *pBuf, SceInt32 iPackNum, SceVoid *CallbackData);

typedef struct sceMpegRingbuffer {
	SceInt32 m_iBufsize;
	SceInt32 m_iRpos;
	SceInt32 m_iWpos;
	SceInt32 m_iInlen;
	SceInt32 m_iTypeSize;
	SceVoid *m_pBuf;
	sceMpegRBCallback callback;
	SceVoid *m_CallbackData;
	SceVoid *pPack;
	SceInt32	iSemaRB;
	SceVoid *mp;
} sceMpegRingbuffer;

SceInt32 sceMpegRingbufferQueryMemSize(SceInt32 iPackNum);
SceInt32 sceMpegRingbufferConstruct(sceMpegRingbuffer *pRingbuffer, SceInt32 iPackNum, SceVoid *pBuf, SceInt32 iSize, sceMpegRBCallback callback, SceVoid *pCallbackData);
SceInt32 sceMpegRingbufferDestruct(sceMpegRingbuffer *pRingbuffer);
SceInt32 sceMpegRingbufferPut(sceMpegRingbuffer *pRB, SceInt32 iPackNum, SceInt32 iAvailable);
SceInt32 sceMpegRingbufferAvailableSize( sceMpegRingbuffer *pRB);

// -------------- MPEG --------------- 
SceInt32 sceMpegInit(SceVoid);
SceInt32 sceMpegFinish(SceVoid);
SceInt32 sceMpegQueryMemSize(SceInt32 iMpegMode);
SceInt32 sceMpegCreate(sceMpeg * mp, SceUChar8 * work_area, SceInt32 size, sceMpegRingbuffer *pPSRB, SceInt32 iFrameWidth, SceInt32 iMpegMode, SceVoid *pDDRTop);
SceInt32 sceMpegDelete(sceMpeg *mp);

sceMpegStream *sceMpegRegistStream(sceMpeg *mp, sceMpegStrType iStreamType, SceInt32 ch);
SceInt32 sceMpegUnRegistStream(sceMpeg *mp, sceMpegStream *pStream);

sceMpegHandle sceMpegMallocAvcEsBuf(sceMpeg *mp);
SceInt32 sceMpegFreeAvcEsBuf(sceMpeg *mp, sceMpegHandle tHandle);

SceInt32 sceMpegQueryAtracEsSize(sceMpeg *mp, SceInt32 *iEsSize, SceInt32 *iOutSize);
SceInt32 sceMpegQueryPcmEsSize(sceMpeg *mp, SceInt32 *iEsSize, SceInt32 *iOutSize);

SceInt32 sceMpegInitAu(
	sceMpeg *mp,
	sceMpegHandle hEsBuf,
	sceMpegAu *pAu
);

typedef enum sceMpegAuMode_enum{
	SCE_MPEG_AU_MODE_NORMAL = 0,
	SCE_MPEG_AU_MODE_JUMP = 1
} sceMpegAuMode_enum;

typedef SceInt32 sceMpegAuMode;

SceInt32 sceMpegChangeGetAuMode(sceMpeg *mp,sceMpegStream *pStream,sceMpegAuMode iAuMode);
SceInt32 sceMpegGetAvcAu(sceMpeg *mp,sceMpegStream *pStream,sceMpegAu *pAu,SceInt32 *iAttr);
SceInt32 sceMpegGetAtracAu(sceMpeg *mp,sceMpegStream *pStream,sceMpegAu *pAu,SceVoid **pAtracBody);
SceInt32 sceMpegGetPcmAu(sceMpeg *mp,sceMpegStream *pStream,sceMpegAu *pAu,SceInt32 *iAttr);
SceInt32 sceMpegFlushAllStream(sceMpeg *mp);
SceInt32 sceMpegFlushStream(sceMpeg *mp,sceMpegStream *pStream);


//-------------AVC----------------
SceInt32 sceMpegAvcDecode(sceMpeg *mp,sceMpegAu *pAu,SceInt32 iFrameWidth,SceUChar8 *pRGBA[],SceInt32 *iNum);

typedef enum sceMpeg_SAVD_RESULT{
	SCE_MPEG_ERROR_AVC_FATAL = -8,
	SCE_MPEG_ERROR_AVC_SYNTAX,
	SCE_MPEG_ERROR_AVC_ADDR,
	SCE_MPEG_ERROR_AVC_SIZE,
	SCE_MPEG_ERROR_AVC_LIB,
	SCE_MPEG_ERROR_AVC_CABAC,
	SCE_MPEG_AVC_OK = 1
} sceMpeg_SAVD_RESULT;

typedef struct sceMpegAvcDecodeDetailInfo{
	SceInt32	iDecodeResult;
	SceUInt32	uiRecoveryPoint;
	SceUInt32	uiHorizontalSize;
	SceUInt32	uiVerticalSize;
	SceUInt32	uiFrameCropLeftOffset;
	SceUInt32	uiFrameCropRightOffset;
	SceUInt32	uiFrameCropTopOffset;
	SceUInt32	uiFrameCropBottomOffset;
	SceUInt32	uiDisplayFrameNum;
} sceMpegAvcDecodeDetailInfo;

SceInt32 sceMpegAvcDecodeDetail(sceMpeg *mp,sceMpegAvcDecodeDetailInfo *pDetail);
SceInt32 sceMpegAvcDecodeFlush(sceMpeg *mp);
SceInt32 sceMpegAvcDecodeStop(sceMpeg *mp,SceInt32 iFrameWidth,SceUChar8 *pRGBA[],SceInt32 *iNum);

#define	SCE_MPEG_AVC_DEC_NO_CHANGE  		(-1)

typedef enum SCE_MPEG_AVC_PIXEL_FORMAT{
	SCE_MPEG_AVC_PIXEL_NO_CHANGE	= -1,
	SCE_MPEG_AVC_PIXEL_RGB565		= 0,
	SCE_MPEG_AVC_PIXEL_RGBA5551		= 1,
	SCE_MPEG_AVC_PIXEL_RGBA4444		= 2,
	SCE_MPEG_AVC_PIXEL_RGBA8888		= 3
} SCE_MPEG_AVC_PIXEL_FORMAT;

#define SCE_MPEG_AVC_YCBCR_EXTERNAL 	(1)
#define SCE_MPEG_AVC_YCBCR_INTERNAL		(2)

typedef struct sceMpegAvcMode{
	SceInt32	iDecodeMode;
	SceInt32	iPixelFormat;
} sceMpegAvcMode;

SceInt32 sceMpegAvcDecodeMode(sceMpeg *mp,sceMpegAvcMode *pMode);
SceInt32 sceMpegAtracDecode(sceMpeg *mp,sceMpegAu *pAu,SceUChar8 *pPcmData,SceInt32 iInitFlag);

typedef struct sceMpegAvcYCbCrRange{
	SceUInt32 uiStartWidth;
	SceUInt32 uiStartHeight;
	SceUInt32 uiLenWidth;
	SceUInt32 uiLenHeight;
} sceMpegAvcYCbCrRange;

SceInt32 sceMpegAvcQueryYCbCrSize(sceMpeg *mp,SceInt32 iYCbCrMode,SceInt32 iYCbCrWidth,SceInt32 iYCbCrHeight,SceInt32 *iAvcYCbCrSize);
SceInt32 sceMpegAvcInitYCbCr(sceMpeg *mp,SceInt32 iYCbCrMode,SceInt32 iYCbCrWidth,SceInt32 iYCbCrHeight,SceUChar8 *pAvcYCbCr);
SceInt32 sceMpegAvcDecodeYCbCr(sceMpeg *mp,sceMpegAu *pAu,SceUChar8 *pAvcYCbCr[],SceInt32 *iNum);
SceInt32 sceMpegAvcDecodeStopYCbCr(sceMpeg *mp,SceUChar8 *pAvcYCbCr[],SceInt32 *iNum);
SceInt32 sceMpegAvcCsc(sceMpeg *mp,SceUChar8 *pAvcYCbCr,sceMpegAvcYCbCrRange *pRange,SceInt32 iFrameWidth,SceUChar8 *pRGBA);

#ifdef __cplusplus
}
#endif

#endif

