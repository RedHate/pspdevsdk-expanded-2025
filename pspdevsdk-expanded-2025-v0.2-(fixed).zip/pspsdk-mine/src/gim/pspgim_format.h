#ifndef __PSPGIM_FORMAT_H__
#define __PSPGIM_FORMAT_H__

#ifdef __cplusplus
extern "C" {
#endif


//  enums                                                           
#define	SCEGIM_FORMAT_SIGNATURE		(0x2e47494d)	// '.GIM' 
#define	SCEGIM_FORMAT_VERSION		(0x312e3030)	// '1.00' 
#define	SCEGIM_FORMAT_STYLE_PSP		(0x00505350)	// 'PSP'  

enum SceGimBase{
	SCEGIM_BASE_RESERVED		= 0x0000,	// 0000-0fff : reserved 
	SCEGIM_BASE_PRIVATE			= 0x1000,	// 1000-3fff : private use 
	SCEGIM_BASE_PUBLIC			= 0x4000,	// 4000-7fff : public use 
	
	SCEGIM_BLOCK				= 0x0001,
	SCEGIM_FILE					= 0x0002,
	SCEGIM_PICTURE				= 0x0003,
	SCEGIM_IMAGE				= 0x0004,
	SCEGIM_PALETTE				= 0x0005,
	SCEGIM_SEQUENCE				= 0x0006,
	SCEGIM_FILE_INFO			= 0x00ff
} ;

enum SceGimImageFormat{
	SCEGIM_FORMAT_RGBA5650		= 0,
	SCEGIM_FORMAT_RGBA5551		= 1,
	SCEGIM_FORMAT_RGBA4444		= 2,
	SCEGIM_FORMAT_RGBA8888		= 3,
	SCEGIM_FORMAT_INDEX4		= 4,
	SCEGIM_FORMAT_INDEX8		= 5,
	SCEGIM_FORMAT_INDEX16		= 6,
	SCEGIM_FORMAT_INDEX32		= 7,
	SCEGIM_FORMAT_DXT1			= 8,
	SCEGIM_FORMAT_DXT3			= 9,
	SCEGIM_FORMAT_DXT5			= 10,
	SCEGIM_FORMAT_DXT1EXT		= 264,
	SCEGIM_FORMAT_DXT3EXT		= 265,
	SCEGIM_FORMAT_DXT5EXT		= 266,

	// obsolete 
	SCEGIM_RGBA_5650		= 0,
	SCEGIM_RGBA_5551		= 1,
	SCEGIM_RGBA_4444		= 2,
	SCEGIM_RGBA_8888		= 3,
	SCEGIM_INDEX_4			= 4,
	SCEGIM_INDEX_8			= 5,
	SCEGIM_INDEX_16			= 6,
	SCEGIM_INDEX_32			= 7
} ;

enum SceGimOrder{
	SCEGIM_ORDER_NORMAL		= 0,
	SCEGIM_ORDER_PSPIMAGE	= 1
} ;

enum SceGimType{
	SCEGIM_TYPE_GENERIC		= 0,
	SCEGIM_TYPE_MIPMAP		= 1,
	SCEGIM_TYPE_MIPMAP2		= 2,
	SCEGIM_TYPE_SEQUENCE	= 3
} ;

enum SceGimInterp{
	SCEGIM_INTERP_TYPEMASK		= 0x0f,
	SCEGIM_INTERP_DISSOLVE		= 0x80,
	SCEGIM_INTERP_EVENT			= 0x40,

	SCEGIM_INTERP_CONSTANT		= 0,
	SCEGIM_INTERP_LINEAR		= 1
} ;

enum SceGimRepeat{
	SCEGIM_REPEAT_HOLD			= 0,
	SCEGIM_REPEAT_CYCLE			= 1,
} ;

enum SceGimParam{
	SCEGIM_PARAM_IMAGE_INDEX	= 0,
	SCEGIM_PARAM_IMAGE_PLANE	= 1,
	SCEGIM_PARAM_IMAGE_LEVEL	= 2,
	SCEGIM_PARAM_IMAGE_FRAME	= 3,
	SCEGIM_PARAM_PALETTE_INDEX	= 8,
	SCEGIM_PARAM_PALETTE_LEVEL	= 10,
	SCEGIM_PARAM_PALETTE_FRAME	= 11,
	SCEGIM_PARAM_CROP_U			= 16,
	SCEGIM_PARAM_CROP_V			= 17,
	SCEGIM_PARAM_CROP_W			= 18,
	SCEGIM_PARAM_CROP_H			= 19,
	SCEGIM_PARAM_BLEND_MODE		= 32,
	SCEGIM_PARAM_FUNC_MODE		= 34,
	SCEGIM_PARAM_FUNC_COMP		= 35,
	SCEGIM_PARAM_FILTER_MAG		= 36,
	SCEGIM_PARAM_FILTER_MIN		= 37,
	SCEGIM_PARAM_WRAP_U			= 38,
	SCEGIM_PARAM_WRAP_V			= 39
};

enum SceGimBlend{
	SCEGIM_BLEND_OFF			= 0,
	SCEGIM_BLEND_MIX			= 1,
	SCEGIM_BLEND_ADD			= 2,
	SCEGIM_BLEND_SUB			= 3,
	SCEGIM_BLEND_MIN			= 4,
	SCEGIM_BLEND_MAX			= 5,
	SCEGIM_BLEND_ABS			= 6
};

enum SceGimTexType{
	SCEGIM_FUNC_MODULATE		= 0,
	SCEGIM_FUNC_DECAL			= 1,
};

enum SceGimPixelFormat{
	SCEGIM_FUNC_RGB				= 0,
	SCEGIM_FUNC_RGBA			= 1
};

enum SceGimFilter{
	SCEGIM_FILTER_NEAREST				 = 0,
	SCEGIM_FILTER_LINEAR				 = 1,
	SCEGIM_FILTER_NEAREST_MIPMAP_NEAREST = 4,
	SCEGIM_FILTER_LINEAR_MIPMAP_NEAREST  = 5,
	SCEGIM_FILTER_NEAREST_MIPMAP_LINEAR  = 6,
	SCEGIM_FILTER_LINEAR_MIPMAP_LINEAR   = 7
};

enum SceGimWrap{
	SCEGIM_WRAP_REPEAT		= 0,
	SCEGIM_WRAP_CLAMP		= 1
};

//   header structure                                               
typedef struct {
	unsigned int signature ;
	unsigned int version ;
	unsigned int style ;
	unsigned int option ;
} SceGimHeader ;

//  chunk structure                                                 
typedef struct {
	unsigned short type ;
	unsigned short unused ;
	unsigned int next_offs ;
	unsigned int child_offs ;
	unsigned int data_offs ;
} SceGimChunk ;

int SCEGIM_CHUNK_TYPE( SceGimChunk *chunk );
SceGimChunk *SCEGIM_CHUNK_NEXT( SceGimChunk *chunk );
SceGimChunk *SCEGIM_CHUNK_CHILD( SceGimChunk *chunk );
void *SCEGIM_CHUNK_DATA( SceGimChunk *chunk );
int SCEGIM_CHUNK_SIZE( SceGimChunk *chunk );
int SCEGIM_CHUNK_TAG_SIZE( SceGimChunk *chunk );
int SCEGIM_CHUNK_DATA_SIZE( SceGimChunk *chunk );
int SCEGIM_CHUNK_CHILD_SIZE( SceGimChunk *chunk );
void *SCEGIM_CHUNK_SKIPSTRING( const char *str, int align );

//   image chunk data                                               
typedef struct {
	unsigned short header_size ;
	unsigned short reference ;
	unsigned short format ;
	unsigned short order ;
	unsigned short width ;
	unsigned short height ;
	unsigned short bpp ;
	unsigned short pitch_align ;
	unsigned short height_align ;
	unsigned short dim_count ;
	unsigned short reserved ;
	unsigned short reserved2 ;
	unsigned int offsets ;
	unsigned int images ;
	unsigned int total ;
	unsigned int plane_mask ;
	unsigned short level_type ;
	unsigned short level_count ;
	unsigned short frame_type ;
	unsigned short frame_count ;
} SceGimImageHeader ;

//  palette chunk data                                              
typedef SceGimImageHeader SceGimPaletteHeader;

//  sequence chunk data                                             
typedef struct {
	unsigned short header_size ;
	unsigned short reference ;
	unsigned short frame_start ;
	unsigned short frame_end ;
	unsigned short frame_rate ;
	unsigned short frame_repeat ;
	unsigned short n_constants ;
	unsigned short n_functions ;
	unsigned int constants ;
	unsigned int functions ;
	unsigned int keyframes ;
	unsigned int total ;
} SceGimSequenceHeader ;

typedef struct {
	unsigned short param ;
	short value ;
} SceGimConstant ;

typedef struct {
	unsigned short param ;
	unsigned short interp ;
	unsigned int keyframes ;
} SceGimFunction ;

typedef struct {
	short count ;
	short values[ 1 ] ;
} SceGimKeyframe ;

//  file info chunk data                                            
typedef struct {
	char project_name[ 1 ] ;
	// char user_name[ n ] ; 	// use SCEGIM_CHUNK_SKIPSTRING() 
	// char saved_date[ n ] ; 	// use SCEGIM_CHUNK_SKIPSTRING() 
	// char originator[ n ] ; 	// use SCEGIM_CHUNK_SKIPSTRING() 
} SceGimFileInfo;


#ifdef __cplusplus
}
#endif

#endif
