/*
 * PSP Software Development Kit - https://github.com/pspdev
 * -----------------------------------------------------------------------
 * Licensed under the BSD license, see LICENSE in PSPSDK root fordetails.
 *
 * main.c - Simple elf based network example.
 * 
 * Now 100% PSP API
 *
 * Copyright (c) 2005 James F <tyranid@gmail.com>
 * Copyright (c) 2025 Ultros (redhate) <redhate@ymail.com>
 * 
 * v0.4 (made some mistakes in the network api prototypes headers corrected)
 *
 */

#include <errno.h>
#include <pspkernel.h>

#include <pspsdk.h>
#include <psputility.h>
#include <string.h>
#include <unistd.h>

#include <pspctrl.h>

//the required networking headers
#include <pspnet.h>
#include <pspnet_inet.h>
#include <pspnet_apctl.h>
#include <pspnet_resolver.h>
#include <pspnet/sys/socket.h>

#define printf pspDebugScreenPrintf

#define HELLO_MSG   "Hello there. Type away.\n"
#define MODULE_NAME " NetSample"
#define SERVER_PORT 23

PSP_MODULE_INFO(MODULE_NAME, 0, 1, 1);
PSP_MAIN_THREAD_ATTR(THREAD_ATTR_USER | THREAD_ATTR_VFPU);
//PSP_HEAP_SIZE_KB(1024*1024);
PSP_HEAP_THRESHOLD_SIZE_KB(0x8000);

/* for error checking */
int do_error(const char *msg, int err)
{
	pspDebugScreenSetTextColor(0xFF0000FF);	
	printf(MODULE_NAME ": %s failed with error %d\n", msg, err);
	pspDebugScreenSetTextColor(0xFFFFFFFF);	
	sceKernelDelayThread(2000000);
	return err;
}

/* Initialise the network */
int init_network()
{
	// for return values
	int r;
	
	// load the common modules
	r = sceUtilityLoadNetModule(PSP_NET_MODULE_COMMON);
	if(r != PSP_OK){ return do_error("sceUtilityLoadNetModule", r); }
	
	// load the inet modules
	r = sceUtilityLoadNetModule(PSP_NET_MODULE_INET);
	if(r != PSP_OK){ return do_error("sceUtilityLoadNetModule", r); }

	// init network
	r = sceNetInit(0x20000, 0x20, 0x1000, 0x20, 0x1000);
	if(r != PSP_OK){ return do_error("sceNetInit", r); }

	// init inet
	r = sceNetInetInit();
	if(r != PSP_OK){ return do_error("sceNetInetInit", r); }

	// init resolver
	r = sceNetResolverInit();
	if(r != PSP_OK){ return do_error("sceNetResolverInit", r); }
	
	// init apctl
	r = sceNetApctlInit(0x1600, 0x42);
	if(r != PSP_OK){ return do_error("sceNetApctlInit", r); }
	
	return PSP_OK;
}

/* Terminate network */
int term_network()
{
	// for return values
	int r;
	
	// terminate apctl
	r = sceNetApctlTerm();
	if(r != PSP_OK){ return do_error("sceNetApctlTerm", r); }
	
	//terminate resolver
	r = sceNetResolverTerm();
	if(r != PSP_OK){ return do_error("sceNetResolverTerm", r); }
	
	// terminate inet
	r = sceNetInetTerm();
	if(r != PSP_OK){ return do_error("sceNetInetTerm", r); }
	
	// terminate the network
	r = sceNetTerm();
	if(r != PSP_OK){ return do_error("sceNetTerm", r); }
	
	// unload the inet module
	r = sceUtilityUnloadNetModule(PSP_NET_MODULE_INET);
	if(r != PSP_OK){ return do_error("sceUtilityUnloadNetModule", r); }
	
	//unload the common modules
	r = sceUtilityUnloadNetModule(PSP_NET_MODULE_COMMON);
	if(r != PSP_OK){ return do_error("sceUtilityUnloadNetModule", r); }
	
	return PSP_OK;
}

/* Start a simple tcp echo server */
int start_server(const char *ip_address, uint16_t port)
{
	//vars
	int new = -1;
	static char t_name[1024];
	static struct SceNetInetInAddr t_addr;
	struct SceNetInetSockaddrIn local, client;
	
	// create a socket
	int sock = sceNetInetSocket(PSP_NET_INET_AF_INET, PSP_NET_INET_SOCK_STREAM, 0);
	if(sock < 0) { return do_error("Error creating server socket %d", sock); }

	printf(MODULE_NAME ": Socket created: %d\n", sock);

	//apply up socket information
	local.sin_family      = PSP_NET_INET_AF_INET;
	local.sin_port 		  = sceNetHtons(port);
	local.sin_addr.s_addr = PSP_NET_INET_INADDR_ANY;
	
	// for return values
	int r;
	
	// bind a socket - this function is weird to me because we're typecasting a totally different shaped structure (even done in real network stuff)
	// for example bind(sockfd, (struct sockaddr *) &local, sizeof(local)  from: "struct sockaddr_in local" in posix sockets
	r = sceNetInetBind(sock, (struct SceNetInetSockaddr*)&local, sizeof(local));
	if(r != PSP_OK){ return do_error("sceNetInetBind", r); }

	printf(MODULE_NAME ": Socket bind socket %d to port %d\n", sock, SERVER_PORT);
	
	// listen to the socket
	r = sceNetInetListen(sock, 1);
	if(r != PSP_OK){ return do_error("sceNetInetListen", r); }

	printf(MODULE_NAME ": Listening for connections port %d\n", SERVER_PORT);

	// vars for socked file descripters
	SceNetInetFdSet set;
	SceNetInetFdSet setsave;

	// zero the socket file descripter
	SceNetInetFD_ZERO(&set);
	// set the socket file descripter to the socket returned previously by sceNetInetSocket
	SceNetInetFD_SET(sock, &set);
	// backup the current socket file descripter
	setsave = set;

	while(1)
	{
		
		// load the back socket file descripter into the current socket file descripter
		set = setsave;
		
		// set the timeout interval for the socket select function below: sceNetInetSelect
		struct SceNetInetTimeval timeout;
		timeout.tv_sec  = 0;
		timeout.tv_usec = 50;
		
		// select the socket file descripter
		r = sceNetInetSelect(PSP_NET_INET_FD_SETSIZE, &set, NULL, NULL, &timeout);
		if(r < 0) { return do_error("sceNetInetSelect %d", r); }
		
		// loop through all possible socket file descripters
		int current_sock;
		for(current_sock=0; current_sock<PSP_NET_INET_FD_SETSIZE; current_sock++)
		{
			// set the socket file descripter
			if(SceNetInetFD_ISSET(current_sock, &set))
			{
				// buffer socket data that's to be read in
				char data[1024];
				
				// is the current loop item the chosen socket?
				if(current_sock == sock)
				{
					// accept the socket connection
					// accept new connection on a socket
					// again, this function is weird to me because we're typecasting a totally different shaped structure (even done in real network stuff)
					// for example: accept(sockfd, (struct sockaddr *) &client, &size); from: "struct sockaddr_in client" in posix sockets
					SceNetInetSocklen_t size;
					new = sceNetInetAccept(sock, (struct SceNetInetSockaddr*)&client, &size);
					if(new < 0)
					{
						sceNetInetShutdown(sock, PSP_NET_INET_SHUT_RDWR);
						return do_error("sceNetInetShutdown %d", new);
					}
										
					// some local vars
					int rid = -1;
					char rbuf[1024];
					
					/* Create a resolver */
					r = sceNetResolverCreate(&rid, rbuf, sizeof(rbuf));
					if(r != PSP_OK){ return do_error("sceNetResolverCreate", r); }
					
					// printf(MODULE_NAME ": Created resolver with id %d\n", rid);

					/* Resolve the network address to a name */
					r = sceNetResolverStartAtoN(rid, &client.sin_addr, t_name, sizeof(t_name), 2, 3);
					if(r != PSP_OK){ return do_error("sceNetResolverStartAtoN", r); }

					// printf(MODULE_NAME ": Resolved %08X to %s\n", *(unsigned int*)&addr, name);

					/* Resolve a name to an network address for demonstration purposes */
					r = sceNetResolverStartNtoA(rid, t_name, &t_addr, 2, 3);
					if(r != PSP_OK){ return do_error("sceNetResolverStartNtoA", r); }
					
					// printf(MODULE_NAME ": Resolved %s to %08X\n", name, *(unsigned int*)&addr);
					
					/* Delete the resolver */
					r = sceNetResolverDelete(rid);
					if(r != PSP_OK){ return do_error("sceNetResolverDelete", r); }
					
					// printf(MODULE_NAME ": Deleting resolver with id %d\n", rid);
					
					/* Resolve the ip address of client */
					static char ip_addr[PSP_NET_INET_INET_ADDRSTRLEN+1];
					if(sceNetInetInetNtop(PSP_NET_INET_AF_INET,  &client.sin_addr, ip_addr, PSP_NET_INET_INET_ADDRSTRLEN) == NULL)
					{
						return do_error("sceNetInetInetNtop", r);
					}
					
					// pspDebugScreenClear();
					
					// print message for new connection
					pspDebugScreenSetTextColor(0xFF00FF00);	
					printf(MODULE_NAME ": %s (%s) on socket %d addr_in %08X\n", t_name, ip_addr, current_sock, *(unsigned int*)&t_addr);  
					pspDebugScreenSetTextColor(0xFFFFFFFF);
						
					// set welcome message
					r = sceNetInetSend(new, HELLO_MSG, strlen(HELLO_MSG), PSP_NET_INET_SO_KEEPALIVE);
					if(r < 0){ return do_error("sceNetInetSend", r); }
					
					// set fd
					SceNetInetFD_SET(new, &setsave);
				}
				else
				{
					// wait for bytes to be received from socket
					int bytesread = sceNetInetRecv(current_sock, data, sizeof(data), PSP_NET_INET_SO_KEEPALIVE);
					// bytes are less thank 0? (socket closed)
					if(bytesread <= 0)
					{
						pspDebugScreenSetTextColor(0xFF0000FF); 
						printf(MODULE_NAME ": Socket %d closed\n", current_sock);
						SceNetInetFD_CLR(current_sock, &setsave);
						sceNetInetShutdown(current_sock, PSP_NET_INET_SHUT_RDWR);
					}
					// bytes are greater than 0, we've got some bytes from the network
					// bytes are equal to 0, the connection is still established
					else
					{
						// print the data received
						printf(" %s: %.*s",t_name, bytesread, data);
					
					/*
						if(strcmp(data, "shutdown", bytesread-1) == PSP_OK){
							sceNetInetShutdown(sock, PSP_NET_INET_SHUT_RDWR);
							term_network();
							return PSP_OK;
						}
					*/
						
						// send the data that was received back to the user who sent it
						r = sceNetInetSend(current_sock, data, bytesread, PSP_NET_INET_SO_KEEPALIVE);
						if(r < 0){ return do_error("sceNetInetSend", r); }
					}
				}
			}
		}
	}

	// shutdown the socket
	sceNetInetShutdown(sock, PSP_NET_INET_SHUT_RDWR);
	
	// return OK
	return PSP_OK;
}

/* Print the mac address */
int mac_info()
{
	//print the ethernet address
	printf(MODULE_NAME ": Ethernet Address ");
	struct SceNetEtherAddr addr; 

	// fetch the systems mac address
	int r = sceNetGetLocalEtherAddr(&addr);
	if(r != PSP_OK){ return do_error("sceNetGetLocalEtherAddr", r); }
	else
	{
		// print the systems mac address
		int i;
		for(i=0;i<PSP_NET_ETHER_ADDR_LEN;i++)
		{
			printf("%02X", addr.data[i]);
			if(i < PSP_NET_ETHER_ADDR_LEN-1) printf(":");
		}
	}
	printf("\n");
	
	return PSP_OK;
}

/* Print info about the apctl */
int apctl_info()
{
	// var for apctl data to be stored
	union SceNetApctlInfo info;
	
	// for return values
	int r;
	
	// fetch the apctl information
	r = sceNetApctlGetInfo(PSP_NET_APCTL_INFO_CNF_NAME, &info);
	if(r != PSP_OK){ return do_error("sceNetApctlGetInfo PSP_NET_APCTL_INFO_CNF_NAME", r); }
	printf(MODULE_NAME ": AP cnf_name      %s\n", info.cnf_name);
	
	r = sceNetApctlGetInfo(PSP_NET_APCTL_INFO_BSSID, &info);
	if(r != PSP_OK){ return do_error("sceNetApctlGetInfo PSP_NET_APCTL_INFO_BSSID", r); }
	printf(MODULE_NAME ": AP bssid         %s\n", info.bssid);
	
	r = sceNetApctlGetInfo(PSP_NET_APCTL_INFO_SSID, &info);
	if(r != PSP_OK){ return do_error("sceNetApctlGetInfo PSP_NET_APCTL_INFO_SSID", r); }
	printf(MODULE_NAME ": AP ssid          %s\n", info.ssid);
	
	r = sceNetApctlGetInfo(PSP_NET_APCTL_INFO_SSID_LEN, &info);
	if(r != PSP_OK){ return do_error("sceNetApctlGetInfo PSP_NET_APCTL_INFO_SSID_LEN", r); }
	printf(MODULE_NAME ": AP ssidlen       %d\n", info.ssidlen);
	
	r = sceNetApctlGetInfo(PSP_NET_APCTL_INFO_AUTH_PROTO, &info);
	if(r != PSP_OK){ return do_error("sceNetApctlGetInfo PSP_NET_APCTL_INFO_AUTH_PROTO", r); }
	printf(MODULE_NAME ": AP auth_proto    ");
	printf((!info.auth_proto)? "PSP_NET_APCTL_INFO_AUTH_PROTO_NOAUTH\n" : "PSP_NET_APCTL_INFO_AUTH_PROTO_WEP\n");
	
	r = sceNetApctlGetInfo(PSP_NET_APCTL_INFO_RSSI, &info);
	if(r != PSP_OK){ return do_error("sceNetApctlGetInfo PSP_NET_APCTL_INFO_RSSI", r); }
	printf(MODULE_NAME ": AP rssi          %d\n", info.rssi);
	
	r = sceNetApctlGetInfo(PSP_NET_APCTL_INFO_CHANNEL, &info);
	if(r != PSP_OK){ return do_error("sceNetApctlGetInfo PSP_NET_APCTL_INFO_CHANNEL", r); }
	printf(MODULE_NAME ": AP channel       %d\n", info.channel);
	
	r = sceNetApctlGetInfo(PSP_NET_APCTL_INFO_PWRSAVE, &info);
	if(r != PSP_OK){ return do_error("sceNetApctlGetInfo PSP_NET_APCTL_INFO_PWRSAVE", r); }
	printf(MODULE_NAME ": AP pwrsave       %d\n", info.pwrsave);
	
	r = sceNetApctlGetInfo(PSP_NET_APCTL_INFO_IP_ADDRESS, &info);
	if(r != PSP_OK){ return do_error("sceNetApctlGetInfo PSP_NET_APCTL_INFO_IP_ADDRESS", r); }
	printf(MODULE_NAME ": AP ip_address    %s\n", info.ip_address);
	
	r = sceNetApctlGetInfo(PSP_NET_APCTL_INFO_NETMASK, &info);
	if(r != PSP_OK){ return do_error("sceNetApctlGetInfo PSP_NET_APCTL_INFO_NETMASK", r); }
	printf(MODULE_NAME ": AP netmask       %s\n", info.netmask);
	
	r = sceNetApctlGetInfo(PSP_NET_APCTL_INFO_DEFAULT_ROUTE, &info);
	if(r != PSP_OK){ return do_error("sceNetApctlGetInfo PSP_NET_APCTL_INFO_DEFAULT_ROUTE", r); }
	printf(MODULE_NAME ": AP default_route %s\n", info.default_route);
	
	r = sceNetApctlGetInfo(PSP_NET_APCTL_INFO_PRIMARY_DNS, &info);
	if(r != PSP_OK){ return do_error("sceNetApctlGetInfo PSP_NET_APCTL_INFO_PRIMARY_DNS", r); }
	printf(MODULE_NAME ": AP primary_dns   %s\n", info.primary_dns);
	
	r = sceNetApctlGetInfo(PSP_NET_APCTL_INFO_SECONDARY_DNS, &info);
	if(r != PSP_OK){ return do_error("sceNetApctlGetInfo PSP_NET_APCTL_INFO_SECONDARY_DNS", r); }
	printf(MODULE_NAME ": AP secondary_dns %s\n", info.secondary_dns);
	
	r = sceNetApctlGetInfo(PSP_NET_APCTL_INFO_HTTP_PROXY_FLAG, &info);
	if(r != PSP_OK){ return do_error("sceNetApctlGetInfo PSP_NET_APCTL_INFO_HTTP_PROXY_FLAG", r); }
	printf(MODULE_NAME ": AP http_proxy_flag ");
	printf((!info.http_proxy_flag)? "PSP_NET_APCTL_INFO_HTTP_PROXY_OFF\n" : "PSP_NET_APCTL_INFO_HTTP_PROXY_ON\n");
	
	r = sceNetApctlGetInfo(PSP_NET_APCTL_INFO_HTTP_PROXY_SERVER, &info);
	if(r != PSP_OK){ return do_error("sceNetApctlGetInfo PSP_NET_APCTL_INFO_HTTP_PROXY_SERVER", r); }
	printf(MODULE_NAME ": AP http_proxy_server %s\n", info.http_proxy_server);
	
	r = sceNetApctlGetInfo(PSP_NET_APCTL_INFO_HTTP_PROXY_PORT, &info);
	if(r != PSP_OK){ return do_error("sceNetApctlGetInfo PSP_NET_APCTL_INFO_HTTP_PROXY_PORT", r); }
	printf(MODULE_NAME ": AP http_proxy_port %d\n", info.http_proxy_port);
	
	return PSP_OK;
}

/* Connect to an access point */
int connect_to_apctl(int config)
{
	/* Connect using the first profile */
	int r = sceNetApctlConnect(config);
	if(r != PSP_OK){ return do_error("sceNetApctlConnect", r); }

	printf(MODULE_NAME ": Connecting to wifi AP\n");
	
	// last state var
	int laststate = 0;
	
	while(1)
	{
		// state var filled out by sceNetApctlGetState below
		int state = 0;
		
		// get the current apctl state
		r = sceNetApctlGetState(&state);
		if(r != PSP_OK){ return do_error("sceNetApctlGetState", r); }
		
		// check the apctl state
		if(state != laststate)
		{
			switch(state)
			{
				case PSP_NET_APCTL_STATE_Disconnected: printf(MODULE_NAME ": Disconnected\n"); break;
				case PSP_NET_APCTL_STATE_Scanning:     printf(MODULE_NAME ": Scanning\n"); break;
				case PSP_NET_APCTL_STATE_Joining:      printf(MODULE_NAME ": Joining\n"); break;
				case PSP_NET_APCTL_STATE_IPObtaining:  printf(MODULE_NAME ": IP Obtaining\n"); break;
				case PSP_NET_APCTL_STATE_IPObtained:   printf(MODULE_NAME ": IP Obtained\n"); return PSP_OK; break; // ip is obtained break the loop
				case PSP_NET_APCTL_STATE_MAX:          printf(MODULE_NAME ": Max\n"); break;
			}
		}
		
		// save the state from this loop
		laststate = state;
		
		// wait a little before polling again
		sceKernelDelayThread(50 * 1000); // 50ms
	}
	
	// return OK
	return PSP_OK;
}

/* Select an apctl config */
int select_apctl_cfg()
{
	
	// returned var
	int select = 1;

	// var for input ctrl
	SceCtrlData ctrl;
	
	// for return values
	int r;
	
	// set the control sampling cycle
	r = sceCtrlSetSamplingCycle(0);
	if(r != PSP_OK){ return do_error("sceCtrlSetSamplingCycle", r); }
	
	// set the type of sampling mode
	r = sceCtrlSetSamplingMode(PSP_CTRL_MODE_ANALOG);
	if(r != PSP_OK){ return do_error("sceCtrlSetSamplingMode", r); }
	
	// apctl config selection
	while(1)
	{
		// set text position
		pspDebugScreenSetXY(0, 2);
		
		// print a message
		printf(MODULE_NAME ": Welcome please select an access point\n");
		printf(MODULE_NAME ": AP Ctl selected: %d\n", select);
		printf(MODULE_NAME ": Press UP / DOWN to select AP, press X to choose\n");

		// poll the ctrl input
		r = sceCtrlReadBufferPositive(&ctrl, 1);
		if(r <= PSP_OK){ return do_error("sceCtrlReadBufferPositive", r); }
		
		if (ctrl.Buttons != PSP_OK)
		{
			// decrement selection value
			if (ctrl.Buttons & PSP_CTRL_UP)
			{
				if(select > 1) select--;
				sceKernelDelayThread(250000);
			}
			// increment selection value
			if (ctrl.Buttons & PSP_CTRL_DOWN)
			{
				// 3 wifi ap configs max (iirc)
				if(select < 3) select++;
				sceKernelDelayThread(250000);
			}
			// cross pressed (make selection)
			if (ctrl.Buttons & PSP_CTRL_CROSS)
			{
				//break the loop
				break;
			}
		}
	}
	
	// return the selection
	return select;
	
}

/* Exit callback */
int exit_callback(int arg1, int arg2, void *common)
{
	// terminate the network
	term_network();
	
	// exit the game
	sceKernelExitGame();
	
	// return OK
	return PSP_OK;
}

/* Callback thread */
int callback_thread(SceSize args, void *argp)
{
	
	// for return values
	int r;
	
	// create a callback
	int cbid = sceKernelCreateCallback("Exit Callback", exit_callback, NULL);
	
	// register exit callback
	r = sceKernelRegisterExitCallback(cbid);
	if(r != PSP_OK){ return do_error("sceKernelRegisterExitCallback", r); }
	
	// sleep the callback
	r = sceKernelSleepThreadCB();
	if(r != PSP_OK){ return do_error("sceKernelRegisterExitCallback", r); }
	
	return PSP_OK;
}

/* Sets up the callback thread and returns its thread id */
int setup_callbacks(void)
{
	// create a callback thread
	SceUID thid = sceKernelCreateThread("update_thread", callback_thread, 0x11, 0xFA0, PSP_THREAD_ATTR_USER, 0);
	
	// if the UID is >= 0 then start the tread
	if(thid >= 0) sceKernelStartThread(thid, 0, 0);
	// otherwise return err (1)
	else{ return do_error("sceKernelStartThread", thid); }
	
	// return OK
	return PSP_OK;
}

/* Simple thread */
int main(int argc, char **argv)
{
	// for return values
	int r;
	
	// init the debug lib
	pspDebugScreenInit();
	
	// set up the exit callback
	r = setup_callbacks();
	if(r != PSP_OK){ return do_error("setup_callbacks", r); }
	
	// init network functions and modules
	r = init_network();
	if(r != PSP_OK){ return do_error("init_network", r); }
		
	// apctl config
	int apCtrlConfSelect = 0;
	
	// select the apctl configuration
	apCtrlConfSelect = select_apctl_cfg();
	if(apCtrlConfSelect <= 0 || apCtrlConfSelect >=2){ return do_error("apCtrlConfSelect out of bounds.", apCtrlConfSelect); }
	
	// connect to apctl and start server
	do
	{
		/* add apctl selection */	
		if(connect_to_apctl(apCtrlConfSelect) == PSP_OK)
		{
			// print a message so we know somethings happened
			printf(MODULE_NAME ": Connected to wifi AP using config #%d\n", apCtrlConfSelect);
			
			// get the apctl configuration information (after connecting)
			r = apctl_info();
			if(r != PSP_OK){ return do_error("apctl_info", r); }
			
			// print the mac address
			r = mac_info();
			if(r != PSP_OK){ return do_error("mac_info", r); }
			
			// SceNetApctlInfo var can only be refered to once connected
			union SceNetApctlInfo info;
				
			// start the echo server
			r = start_server(info.ip_address, SERVER_PORT);
			if(r != PSP_OK){ return do_error("start_server", r); }
		}
		
	} while(0);
	
	// disconnect from ap
	r = sceNetApctlDisconnect();
	if(r != PSP_OK){ return do_error("sceNetApctlDisconnect", r); }
	
	// shutdown network functions and modules
	r = term_network();
	if(r != PSP_OK){ return do_error("term_network", r); }
	
	// exit delete
	r = sceKernelExitDeleteThread(0);
	if(r != PSP_OK){ return do_error("sceKernelExitDeleteThread", r); }
	
	// return OK
	return PSP_OK;
}

/* module stop function */
int module_stop(SceSize args, void *argp)
{
	// terminate the network
	int r = term_network();
	if(r != PSP_OK){ return r; }
	// return OK
	return PSP_OK;
}

