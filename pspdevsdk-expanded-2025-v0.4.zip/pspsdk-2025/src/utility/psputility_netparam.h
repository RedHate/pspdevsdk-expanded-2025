/*
 * PSP Software Development Kit - https://github.com/pspdev
 * -----------------------------------------------------------------------
 * Licensed under the BSD license, see LICENSE in PSPSDK root for details.
 *
 *  psputility_netparam.h - Definitions and Functions to manage Network  
 *                          parameters.
 *
 * Copyright (c) 2005 John Kelley <ps2dev@kelley.ca>
 *
 */
#ifndef __PSPUTILITY_NETPARAM_H__
#define __PSPUTILITY_NETPARAM_H__

#ifdef __cplusplus
extern "C" {
#endif

#include <psptypes.h>

#define PSP_UTILITY_NET_PARAM_TEMP_CNF_ID 0

#define PSP_UTILITY_NET_PARAM_SSID_LEN            32
#define PSP_UTILITY_NET_PARAM_WEP_KEY_LEN         13
#define PSP_UTILITY_NET_PARAM_CNF_NAME_LEN        64
#define PSP_UTILITY_NET_PARAM_IPV4_ADDR_STR_LEN   16
#define PSP_UTILITY_NET_PARAM_HOSTNAME_LEN       128
#define PSP_UTILITY_NET_PARAM_AUTH_NAME_LEN      128
#define PSP_UTILITY_NET_PARAM_AUTH_KEY_LEN       128

/* Code */
#define PSP_UTILITY_NET_PARAM_CODE_CNF_NAME                0
#define PSP_UTILITY_NET_PARAM_CODE_SSID                    1
#define PSP_UTILITY_NET_PARAM_CODE_AUTH_PROTO              2
#define PSP_UTILITY_NET_PARAM_CODE_WEP_KEY                 3
#define PSP_UTILITY_NET_PARAM_CODE_HOW_TO_SET_IP           4
#define PSP_UTILITY_NET_PARAM_CODE_IP_ADDRESS              5
#define PSP_UTILITY_NET_PARAM_CODE_NETMASK                 6
#define PSP_UTILITY_NET_PARAM_CODE_DEFAULT_ROUTE           7
#define PSP_UTILITY_NET_PARAM_CODE_DNS_FLAG                8
#define PSP_UTILITY_NET_PARAM_CODE_PRIMARY_DNS             9
#define PSP_UTILITY_NET_PARAM_CODE_SECONDARY_DNS           10
#define PSP_UTILITY_NET_PARAM_CODE_AUTH_NAME               11
#define PSP_UTILITY_NET_PARAM_CODE_AUTH_KEY                12
#define PSP_UTILITY_NET_PARAM_CODE_HTTP_PROXY_FLAG         13
#define PSP_UTILITY_NET_PARAM_CODE_HTTP_PROXY_SERVER       14
#define PSP_UTILITY_NET_PARAM_CODE_HTTP_PROXY_PORT         15

/* value: auth_proto */
#define PSP_UTILITY_NET_PARAM_AUTH_PROTO_NOAUTH  0
#define PSP_UTILITY_NET_PARAM_AUTH_PROTO_WEP64   1
#define PSP_UTILITY_NET_PARAM_AUTH_PROTO_WEP128  2

/* value: how_to_set_ip */
#define PSP_UTILITY_NET_PARAM_HOW_TO_SET_IP_DHCP    0
#define PSP_UTILITY_NET_PARAM_HOW_TO_SET_IP_STATIC  1
#define PSP_UTILITY_NET_PARAM_HOW_TO_SET_IP_PPPOE   2

/* value: dns_flag */
#define PSP_UTILITY_NET_PARAM_DNS_FLAG_AUTO   0
#define PSP_UTILITY_NET_PARAM_DNS_FLAG_MANUAL 1

/* value: http_proxy_flag */
#define PSP_UTILITY_NET_PARAM_HTTP_PROXY_FLAG_OFF 0
#define PSP_UTILITY_NET_PARAM_HTTP_PROXY_FLAG_ON  1

union SceUtilityNetParamEntry {
	SceChar8 cnf_name[PSP_UTILITY_NET_PARAM_CNF_NAME_LEN];
	SceChar8 ssid[PSP_UTILITY_NET_PARAM_SSID_LEN + 1];
	SceUInt32 auth_proto;
	SceChar8 wep_key[PSP_UTILITY_NET_PARAM_WEP_KEY_LEN];
	SceUInt32 how_to_set_ip;
	SceChar8 ip_address[PSP_UTILITY_NET_PARAM_IPV4_ADDR_STR_LEN];
	SceChar8 netmask[PSP_UTILITY_NET_PARAM_IPV4_ADDR_STR_LEN];
	SceChar8 default_route[PSP_UTILITY_NET_PARAM_IPV4_ADDR_STR_LEN];
	SceUInt32 dns_flag;
	SceChar8 primary_dns[PSP_UTILITY_NET_PARAM_IPV4_ADDR_STR_LEN];
	SceChar8 secondary_dns[PSP_UTILITY_NET_PARAM_IPV4_ADDR_STR_LEN];
	SceChar8 auth_name[PSP_UTILITY_NET_PARAM_AUTH_NAME_LEN];
	SceChar8 auth_key[PSP_UTILITY_NET_PARAM_AUTH_KEY_LEN];
	SceUInt32 http_proxy_flag;
	SceChar8 http_proxy_server[PSP_UTILITY_NET_PARAM_HOSTNAME_LEN];
	SceUInt32 http_proxy_port;
};

/*
 * netparam error code:
 *   facility: 0x011 (PSP_ERROR_FACILITY_UTILITY)
 *   sub ID: 0x06
 */
#define PSP_ERROR_UTILITY_NET_PARAM_NO_SUCH_CNF                0x80110601
#define PSP_ERROR_UTILITY_NET_PARAM_INVALID_ID                 0x80110602
#define PSP_ERROR_UTILITY_NET_PARAM_INVALID_POINTER            0x80110603
#define PSP_ERROR_UTILITY_NET_PARAM_INVALID_CODE               0x80110604
#define PSP_ERROR_UTILITY_NET_PARAM_INVALID_VALUE              0x80110605


/**
 * Check existance of a Net Configuration
 *
 * @param id - id of net Configuration (1 to n)
 * @return 0 on success, 
 */
int sceUtilityCheckNetParam(int id);

/**
 * Get Net Configuration Parameter
 *
 * @param id - Net Configuration number (1 to n)
 * @param code - which parameter to get
 * @param entry - parameter data
 * @return 0 on success, 
 */
int sceUtilityGetNetParam(int id, int code, union SceUtilityNetParamEntry *entry);


/**
 * Create a new Network Configuration
 * @note This creates a new configuration at conf and clears 0
 *
 * @param conf - Net Configuration number (1 to n)
 *
 * @return 0 on success
 */
int sceUtilityCreateNetParam(int conf);

/**
 * Sets a network parameter
 * @note This sets only to configuration 0
 *
 * @param param - Which parameter to set
 * @param val - Pointer to the the data to set
 *
 * @return 0 on success
 */
int sceUtilitySetNetParam(int param, const void *val);

/**
 * Copies a Network Configuration to another
 *
 * @param src - Source Net Configuration number (0 to n)
 * @param dest - Destination Net Configuration number (0 to n)
 *
 * @return 0 on success
 */
int sceUtilityCopyNetParam(int src, int dest);

/**
 * Deletes a Network Configuration
 *
 * @param conf - Net Configuration number (1 to n)
 *
 * @return 0 on success
 */
int sceUtilityDeleteNetParam(int conf);

#ifdef __cplusplus
}
#endif

#endif
