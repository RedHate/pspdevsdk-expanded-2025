#ifndef __PSPNET_AP_DIALOG_DUMMY_H__
#define __PSPNET_AP_DIALOG_DUMMY_H__

#ifdef __cplusplus
extern "C" {
#endif

#include <psptypes.h>
#include <utility/psputility_netparam.h>

struct SceNetApDialogDummyParam {
	char ssid[PSP_UTILITY_NET_PARAM_SSID_LEN + 1];
	unsigned int auth_proto;
	char wep_key[PSP_UTILITY_NET_PARAM_WEP_KEY_LEN];
	unsigned int how_to_set_ip;
	union ip_opt {
		struct static_ip {
			char ip_address[PSP_UTILITY_NET_PARAM_IPV4_ADDR_STR_LEN];
			char netmask[PSP_UTILITY_NET_PARAM_IPV4_ADDR_STR_LEN];
			char default_route[PSP_UTILITY_NET_PARAM_IPV4_ADDR_STR_LEN];
		} static_ip;
		struct pppoe {
			char auth_name[PSP_UTILITY_NET_PARAM_AUTH_NAME_LEN];
			char auth_key[PSP_UTILITY_NET_PARAM_AUTH_KEY_LEN];
		} pppoe;
	} ip_opt;
	unsigned int dns_flag;
	char primary_dns[PSP_UTILITY_NET_PARAM_IPV4_ADDR_STR_LEN];
	char secondary_dns[PSP_UTILITY_NET_PARAM_IPV4_ADDR_STR_LEN];
	unsigned int http_proxy_flag;
	char http_proxy_server[PSP_UTILITY_NET_PARAM_HOSTNAME_LEN];
	SceUShort16 http_proxy_port;
};

/* state */
#define SceNetApDialogDummyState_Initialized   0
#define SceNetApDialogDummyState_Connecting    1
#define SceNetApDialogDummyState_Connected     2
#define SceNetApDialogDummyState_Disconnected  3

struct SceNetApDialogDummyStateInfo {
	int state;
	int error_code;
};
/**
 * Init the ap dialog.
 *
 * @return < 0 on error.
 */
int sceNetApDialogDummyInit(void);
/**
 * Terminnte the ap dialog.
 *
 * @return < 0 on error.
 */
int sceNetApDialogDummyTerm(void);
/**
 * Connect the ap dialog.
 *
 * @param state - SceNetApDialogDummyParam structure to pass
 * 
 * @return < 0 on error.
 */
int sceNetApDialogDummyConnect(struct SceNetApDialogDummyParam *param);
/**
 * Get the state the ap dialog.
 * 
 * @param state - SceNetApDialogDummyStateInfo structure to pass
 *
 * @return < 0 on error.
 */
int sceNetApDialogDummyGetState(struct SceNetApDialogDummyStateInfo *state);

#ifdef __cplusplus
}
#endif

#endif
