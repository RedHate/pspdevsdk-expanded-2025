/*
 * PSP Software Development Kit - https://github.com/pspdev
 * -----------------------------------------------------------------------
 * Licensed under the BSD license, see LICENSE in PSPSDK root for details.
 *
 * pspnet_netcnf.h - Prototypes for the sceJpeg library
 *
 * Copyright (c) 2007 dot_blank
 *
 */
 
 
#ifndef __PSPNET_NETCNF_H__
#define __PSPNET_NETCNF_H__

#ifdef __cplusplus
extern "C" {
#endif

/*
 * 	 libnetcnf error code:
 *   facility: 		0x041 (PSP_ERROR_FACILITY_NETWORK)
 *   module ID: 	0x09
 */

// errors
#define PSP_ERROR_NET_NETCNF_MODULE_CODE				(0x041 << 8)
#define PSP_ERROR_NET_NETCNF_NOT_TERMINATED             (0x80410901)

int sceNetCnfInit(void);
int sceNetCnfTerm(void);

#ifdef __cplusplus
}
#endif

#endif
