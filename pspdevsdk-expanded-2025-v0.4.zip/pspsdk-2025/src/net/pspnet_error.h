#ifndef __PSPNET_ERROR_H__
#define __PSPNET_ERROR_H__

#ifdef __cplusplus
extern "C" {
#endif

#include <psperror.h>

/* MODULE ID */
#define PSP_ERROR_NET_MODULE_ID_COMMON            0x00
#define PSP_ERROR_NET_MODULE_ID_CORE              0x01
#define PSP_ERROR_NET_MODULE_ID_INET              0x02
#define PSP_ERROR_NET_MODULE_ID_POECLIENT         0x03
#define PSP_ERROR_NET_MODULE_ID_RESOLVER          0x04
#define PSP_ERROR_NET_MODULE_ID_DHCP              0x05
#define PSP_ERROR_NET_MODULE_ID_ADHOC_AUTH        0x06
#define PSP_ERROR_NET_MODULE_ID_ADHOC             0x07
#define PSP_ERROR_NET_MODULE_ID_ADHOC_MATCHING    0x08
#define PSP_ERROR_NET_MODULE_ID_NETCNF            0x09
#define PSP_ERROR_NET_MODULE_ID_APCTL             0x0a
#define PSP_ERROR_NET_MODULE_ID_ADHOCCTL          0x0b
#define PSP_ERROR_NET_MODULE_ID_RESERVED01        0x0c
#define PSP_ERROR_NET_MODULE_ID_WLAN              0x0d

/* 0x00 common error */
#define	PSP_ERROR_NET_NO_SPACE						0x80410001/* No enough internal memory pool. */
#define PSP_ERROR_NET_INTERNAL						0x80410002/* Library internal error,
	 * usually this erorr is not occurred. */
#define PSP_ERROR_NET_INVALID_ARG					0x80410003/* Invalid argument was specified. */
#define PSP_ERROR_NET_NO_ENTRY						0x80410004/* no such entry. */

/* 0x01 pspnet_core */
#define	PSP_ERROR_NET_CORE_NOT_TERMINATED			0x80410101/* Not Terminated */
#define	PSP_ERROR_NET_CORE_INTERFACE_BUSY			0x80410102/* Invalid argument */
#define	PSP_ERROR_NET_CORE_INVALID_ARG				0x80410103/* Invalid argument */
#define	PSP_ERROR_NET_CORE_THREAD_NOT_FOUND			0x80410104/* Invalid argument */
#define	PSP_ERROR_NET_CORE_THREAD_BUSY				0x80410105/* Invalid argument */
#define	PSP_ERROR_NET_CORE_80211_NO_BSS				0x80410106/* there is no BSS */
#define	PSP_ERROR_NET_CORE_80211_NO_AVAIL_BSS		0x80410107/* there is no available BSS */

/* 0x02 pspnet_inet */
#define	PSP_ERROR_NET_INET_NOT_TERMINATED			0x80410201/* Not Terminated */
#define	PSP_ERROR_NET_INET_SOCKET_BUSY				0x80410202/* Not Terminated */
#define	PSP_ERROR_NET_INET_CONFIG_INVALID_ARG		0x80410203/* Invalid Argument */
#define	PSP_ERROR_NET_INET_GET_IFADDR				0x80410204/* failed to get if addr */
#define	PSP_ERROR_NET_INET_SET_IFADDR				0x80410205/* failed to set if addr */
#define	PSP_ERROR_NET_INET_DEL_IFADDR				0x80410206/* failed to delete if addr */
#define	PSP_ERROR_NET_INET_NO_DEFAULT_ROUTE			0x80410207/* there is no default route */
#define	PSP_ERROR_NET_INET_GET_ROUTE				0x80410208/* failed to get route */
#define	PSP_ERROR_NET_INET_SET_ROUTE				0x80410209/* failed to add route */
#define	PSP_ERROR_NET_INET_FLUSH_ROUTE				0x8041020a/* failed to flush route */
#define	PSP_ERROR_NET_INET_INVALID_ARG				0x8041020b/* Invalid argument was specified. */

/* 0x03 pspnet_poeclient */
#define PSP_ERROR_NET_POECLIENT_INIT				0x80410301/* PPPoE init error.*/
#define PSP_ERROR_NET_POECLIENT_NO_PADO				0x80410302/* Can't get PADO. */
#define	PSP_ERROR_NET_POECLIENT_NO_PADS				0x80410303/* Can't get PADS. */
#define	PSP_ERROR_NET_POECLIENT_GET_PADT			0x80410304/* PADT received. */
#define	PSP_ERROR_NET_POECLIENT_SERVICE_NAME		0x80410305/* Service name error. */
#define	PSP_ERROR_NET_POECLIENT_AC_SYSTEM			0x80410306/* AC system error. */
#define	PSP_ERROR_NET_POECLIENT_GENERIC				0x80410307/* Generic error. */
#define	PSP_ERROR_NET_POECLIENT_AUTH				0x80410308/* Authentication error. */
#define	PSP_ERROR_NET_POECLIENT_NETWORK				0x80410309/* Network error. */
#define	PSP_ERROR_NET_POECLIENT_TERMINATE			0x8041030a/* Terminate error. */
#define PSP_ERROR_NET_POECLIENT_NOT_STARTED			0x8041030b/* PPPoE not started .*/

/* 0x04 pspnet_resolver */
#define	PSP_ERROR_NET_RESOLVER_NOT_TERMINATED		0x80410401/* Not Terminated */
#define PSP_ERROR_NET_RESOLVER_NO_DNS_SERVER		0x80410402/* DNS server is not set */
#define PSP_ERROR_NET_RESOLVER_INVALID_PTR			0x80410403/* invalid pointer */
#define PSP_ERROR_NET_RESOLVER_INVALID_BUFLEN		0x80410404/* invalid buffer length */
#define PSP_ERROR_NET_RESOLVER_INVALID_ID			0x80410405/* invalid resolver id */
#define PSP_ERROR_NET_RESOLVER_ID_MAX				0x80410406/* there is no id space for new ctx */
#define PSP_ERROR_NET_RESOLVER_NO_MEM				0x80410407/* memory pool allocation for specified size failed. */
#define PSP_ERROR_NET_RESOLVER_ID_NOT_FOUND			0x80410408/* no such resolver id */
#define PSP_ERROR_NET_RESOLVER_CTX_BUSY				0x80410409/* ctx is busy */
#define PSP_ERROR_NET_RESOLVER_ALREADY_STOPPED		0x8041040a/* ctx is already stopped. */
#define PSP_ERROR_NET_RESOLVER_NOT_SUPPORTED		0x8041040b/* Not supported functionality. */
#define PSP_ERROR_NET_RESOLVER_BUF_NO_SPACE			0x8041040c/* there is no space at send buffer */
#define PSP_ERROR_NET_RESOLVER_INVALID_PACKET		0x8041040d/* received DNS response was invalid. */
#define PSP_ERROR_NET_RESOLVER_STOPPED				0x8041040e/* stopped */
#define PSP_ERROR_NET_RESOLVER_SOCKET				0x8041040f/* socket error */
#define PSP_ERROR_NET_RESOLVER_TIMEOUT				0x80410410/* timeout */
#define PSP_ERROR_NET_RESOLVER_NO_RECORD			0x80410411/* no record for this query */
#define PSP_ERROR_NET_RESOLVER_RES_PACKET_FORMAT	0x80410412/* server could not recognize DNS query packet */
#define PSP_ERROR_NET_RESOLVER_RES_SERVER_FAILURE	0x80410413/* Server failure. */
#define PSP_ERROR_NET_RESOLVER_NO_HOST				0x80410414/* there is no entry for this hostname */
#define PSP_ERROR_NET_RESOLVER_RES_NOT_IMPLEMENTED	0x80410415/* Kind of query is not supported. */
#define PSP_ERROR_NET_RESOLVER_RES_SERVER_REFUSED	0x80410416/* Refused by server. */
#define PSP_ERROR_NET_RESOLVER_INTERNAL				0x80410417/* internal error of resolver library */

/* 0x05 pspnet_dhcp */
#define PSP_ERROR_NET_DHCP_INVALID_PACKET			0x80410501/* Received invalid packet. */
#define PSP_ERROR_NET_DHCP_NO_SERVER				0x80410502/* There is no server. */
#define PSP_ERROR_NET_DHCP_SENT_DECLINE				0x80410503/* Sent DHCPDECLINE packet. */
#define PSP_ERROR_NET_DHCP_LEASE_TIME				0x80410504/* Lease time expired. */
#define PSP_ERROR_NET_DHCP_GET_NAK		 			0x80410505/* Received Nak packet. */

/* 0x06 pspnet_adhoc_auth */
#define PSP_ERROR_NET_ADHOC_AUTH_ALREADY_INITIALIZED	0x80410601/* Library module is already initialized */

/* 0x07 pspnet_adhoc */
#define PSP_ERROR_NET_ADHOC_INVALID_SOCKET_ID		0x80410701/* Invalid socket id was specified. */
#define PSP_ERROR_NET_ADHOC_INVALID_ADDR			0x80410702/* Invalid address was specified.  */
#define PSP_ERROR_NET_ADHOC_INVALID_PORT			0x80410703/* Invalid port was specified. */
#define PSP_ERROR_NET_ADHOC_INVALID_BUFLEN			0x80410704/* Invalid buffer length was specified. */
#define PSP_ERROR_NET_ADHOC_INVALID_DATALEN			0x80410705/* Invalid data length was specified. */
#define PSP_ERROR_NET_ADHOC_NOT_ENOUGH_SPACE		0x80400706/* Specified buffer space is not enough. */
#define PSP_ERROR_NET_ADHOC_SOCKET_DELETED			0x80410707/* Socket has been deleted. */
#define PSP_ERROR_NET_ADHOC_SOCKET_ALERTED			0x80410708/* Socket alert has been set. */
#define PSP_ERROR_NET_ADHOC_WOULD_BLOCK				0x80410709/* Fall iin block state in non-blocking mode. */
#define PSP_ERROR_NET_ADHOC_PORT_IN_USE				0x8041070a/* Specified port is in use. */
#define PSP_ERROR_NET_ADHOC_NOT_CONNECTED			0x8041070b/* Socket is not connected. */
#define PSP_ERROR_NET_ADHOC_DISCONNECTED			0x8041070c/* Socket is disconnected. */
#define PSP_ERROR_NET_ADHOC_NOT_OPENED				0x8040070d/* Socket is not opened. */
#define PSP_ERROR_NET_ADHOC_NOT_LISTENED			0x8040070e/* Socket is not listened. */
#define PSP_ERROR_NET_ADHOC_SOCKET_ID_NOT_AVAIL		0x8041070f/* Any socket id is not available. */
#define PSP_ERROR_NET_ADHOC_PORT_NOT_AVAIL			0x80410710/* Any port is not available. */
#define PSP_ERROR_NET_ADHOC_INVALID_ARG				0x80410711/* Invalid argument was specified. */
#define PSP_ERROR_NET_ADHOC_NOT_INITIALIZED			0x80410712/* Library module is not initialized. */
#define PSP_ERROR_NET_ADHOC_ALREADY_INITIALIZED		0x80410713/* Library module is already initialized. */
#define PSP_ERROR_NET_ADHOC_BUSY					0x80410714/* Library module is busy. */
#define PSP_ERROR_NET_ADHOC_TIMEOUT					0x80410715/* API call was timeout. */
#define PSP_ERROR_NET_ADHOC_NO_ENTRY				0x80410716/* No entry was found. */
#define PSP_ERROR_NET_ADHOC_EXCEPTION_EVENT			0x80410717/* Exception event was occured. */
#define PSP_ERROR_NET_ADHOC_CONNECTION_REFUSED		0x80410718/* Connection was refused by peer. */
#define PSP_ERROR_NET_ADHOC_THREAD_ABORTED			0x80410719/* Caller was aborted by sceNetThreadAbort(). */
#define PSP_ERROR_NET_ADHOC_ALREADY_CREATED			0x8041071a/* GameMode handle is already created */
#define PSP_ERROR_NET_ADHOC_NOT_IN_GAMEMODE			0x8041071b/* State is not in gamemode */
#define PSP_ERROR_NET_ADHOC_NOT_CREATED				0x8041071c/* GameMode handle is not created */

/* 0x08 pspnet_adhoc_matching */
#define PSP_ERROR_NET_ADHOC_MATCHING_INVALID_MODE			0x80410801/* Invalid mode was specified. */
#define PSP_ERROR_NET_ADHOC_MATCHING_INVALID_PORT			0x80410802/* Invalid port was specified. */
#define PSP_ERROR_NET_ADHOC_MATCHING_INVALID_MAXNUM			0x80410803/* Invalid maxnum was specified. */
#define PSP_ERROR_NET_ADHOC_MATCHING_RXBUF_TOO_SHORT		0x80410804/* Receive buffer is too short. */
#define PSP_ERROR_NET_ADHOC_MATCHING_INVALID_OPTLEN			0x80410805/* Option data is too long. */
#define PSP_ERROR_NET_ADHOC_MATCHING_INVALID_ARG			0x80410806/* Invalid argument was specified. */
#define PSP_ERROR_NET_ADHOC_MATCHING_INVALID_ID				0x80410807/* Invalid id was specified. */
#define PSP_ERROR_NET_ADHOC_MATCHING_ID_NOT_AVAIL			0x80410808/* Id is not available. */
#define PSP_ERROR_NET_ADHOC_MATCHING_NO_SPACE				0x80410809/* Internal memory pool shortage was occured. */
#define PSP_ERROR_NET_ADHOC_MATCHING_IS_RUNNING				0x8041080a/* Matching protocol is already running. */
#define PSP_ERROR_NET_ADHOC_MATCHING_NOT_RUNNING			0x8041080b/* Matching protocol is not running. */
#define PSP_ERROR_NET_ADHOC_MATCHING_UNKNOWN_TARGET			0x8041080c/* Target is not known. */
#define PSP_ERROR_NET_ADHOC_MATCHING_TARGET_NOT_READY		0x8041080d/* Target is not ready for request. */
#define PSP_ERROR_NET_ADHOC_MATCHING_EXCEED_MAXNUM			0x8041080e/* Too many targets to send request. */
#define PSP_ERROR_NET_ADHOC_MATCHING_REQUEST_IN_PROGRESS	0x8041080f/* Previous request is now in progress. */
#define PSP_ERROR_NET_ADHOC_MATCHING_ALREADY_ESTABLISHED	0x80410810/* Target is already in established state. */
#define PSP_ERROR_NET_ADHOC_MATCHING_BUSY					0x80410811/* Some contexts have been exist yet. */
#define PSP_ERROR_NET_ADHOC_MATCHING_ALREADY_INITIALIZED	0x80410812/* Library module is already initialized. */
#define PSP_ERROR_NET_ADHOC_MATCHING_NOT_INITIALIZED		0x80410813/* Library module is not initialized. */
#define PSP_ERROR_NET_ADHOC_MATCHING_PORT_IN_USE			0x80410814/* Specified port is already in use. */

/* 0x09 pspnet_netcnf */
// MISSING ERROR DEFS FOR NETCNF! GAH!
// 0x80410bXX


/* 0x0a pspnet_apctl */
#define	PSP_ERROR_NET_APCTL_NOT_TERMINATED			0x80410a01/* Not Terminated */
#define PSP_ERROR_NET_APCTL_INVALID_CODE			0x80410a02/* specified code is invalid */
#define PSP_ERROR_NET_APCTL_INVALID_ADDR			0x80410a03/* IP addr is invalid */
#define PSP_ERROR_NET_APCTL_IF_RUNNING				0x80410a04/* Not Disconnected */
#define PSP_ERROR_NET_APCTL_NOT_IN_BSS				0x80410a05/* Not in BSS currently */
#define PSP_ERROR_NET_APCTL_WLAN_SWITCH_OFF			0x80410a06/* WLAN Switch becomes off */
#define PSP_ERROR_NET_APCTL_WLAN_BEACON_LOST		0x80410a07/* Beacon Lost */
#define PSP_ERROR_NET_APCTL_WLAN_DISASSOCIATION		0x80410a08/* Disassociated from AP */
#define PSP_ERROR_NET_APCTL_ID_NOT_FOUND			0x80410a09/* specified ID is not found */
#define PSP_ERROR_NET_APCTL_WLAN_SUSPENDED  		0x80410a0a/* suspended */
#define PSP_ERROR_NET_APCTL_TIMEOUT					0x80410a0b/* timeout */

/* 0x0b pspnet_adhocctl */
#define PSP_ERROR_NET_ADHOCCTL_NOT_LEFT_IBSS			0x80410b01/* Still in IBSS */
#define PSP_ERROR_NET_ADHOCCTL_ALREADY_CONNECTED		0x80410b02/* Connecting IBSS already */
#define PSP_ERROR_NET_ADHOCCTL_WLAN_SWITCH_OFF			0x80410b03/* WLAN Switch becomes off */
#define PSP_ERROR_NET_ADHOCCTL_INVALID_ARG				0x80410b04/* Invalid argument was specified. */
#define PSP_ERROR_NET_ADHOCCTL_TIMEOUT					0x80410b05/* timeout */
#define PSP_ERROR_NET_ADHOCCTL_ID_NOT_FOUND				0x80410b06/* specified ID is not found */
#define PSP_ERROR_NET_ADHOCCTL_ALREADY_INITIALIZED		0x80410b07/* Service is already started. */
#define PSP_ERROR_NET_ADHOCCTL_NOT_INITIALIZED			0x80410b08/* Service is not ready. */
#define PSP_ERROR_NET_ADHOCCTL_DISCONNECTED				0x80410b09/* Disconnected IBSS. */
#define PSP_ERROR_NET_ADHOCCTL_NO_SCAN_INFO				0x80410b0a/* Cannot find scn info */
#define PSP_ERROR_NET_ADHOCCTL_INVALID_IBSS				0x80410b0b/* IBSS type is different */
#define PSP_ERROR_NET_ADHOCCTL_NOT_ENTER_GAMEMODE		0x80410b0c/* Not enter GameMode */
#define PSP_ERROR_NET_ADHOCCTL_CHANNEL_NOT_AVAILABLE	0x80410b0d/* No channel is available */
#define PSP_ERROR_NET_ADHOCCTL_WLAN_BEACON_LOST			0x80410b0e/* Beacon Lost (Gamemode only) */
#define PSP_ERROR_NET_ADHOCCTL_WLAN_SUSPENDED			0x80410b0f/* suspended */
#define PSP_ERROR_NET_ADHOCCTL_BUSY						0x80410b10/* Adhocctl module is busy */
#define PSP_ERROR_NET_ADHOCCTL_CHANNEL_NOT_MATCH		0x80410b11/* cannot join due to user's channel setting */

/* 0x0d wlan */
#define PSP_ERROR_NET_WLAN_ALREADY_JOINED				0x80410d01/* Wlan Device has already joined network. */
#define PSP_ERROR_NET_WLAN_TRY_JOIN						0x80410d02/* Wlan Device is trying to join network.  */
#define PSP_ERROR_NET_WLAN_SCANNING						0x80410d03/* Wlan Device is scanning at now          */
#define PSP_ERROR_NET_WLAN_INVALID_PARAMETER			0x80410d04/* Invaild parameter is specified */
#define PSP_ERROR_NET_WLAN_NOT_SUPPORTED				0x80410d05/* Driver or Device is requested not supported function */
#define PSP_ERROR_NET_WLAN_NOT_JOIN_BSS					0x80410d06/* Mac Device has joined no BSS or IBSS */
#define PSP_ERROR_NET_WLAN_ASSOC_TIMEOUT				0x80410d07/* Association Timeout */
#define PSP_ERROR_NET_WLAN_ASSOC_REFUSED				0x80410d08/* AP refused STA association.*/
#define PSP_ERROR_NET_WLAN_ASSOC_FAIL					0x80410d09/* fail to associate. */
#define PSP_ERROR_NET_WLAN_DISASSOC_FAIL				0x80410d0a/* fail to disassociate */
#define PSP_ERROR_NET_WLAN_JOIN_FAIL					0x80410d0b/* fail to join to IBSS Network */
#define PSP_ERROR_NET_WLAN_POWER_OFF					0x80410d0c/* wlan switch is off */
#define PSP_ERROR_NET_WLAN_INTERNAL_FAIL				0x80410d0d/* Something Error occurs in the driver  */
#define PSP_ERROR_NET_WLAN_DEVICE_NOT_READY				0x80410d0e/* wlan device has not been initialized */
#define PSP_ERROR_NET_WLAN_ALREADY_ATTACHED				0x80410d0f/* wlan device had been attached to pspnet */
#define PSP_ERROR_NET_WLAN_NOT_SET_WEP					0x80410d10/* the driver trys to joined IBSS and BSS have privacy bit */
#define PSP_ERROR_NET_WLAN_TIMEOUT						0x80410d11/* wlan device did not response in time. */
#define PSP_ERROR_NET_WLAN_NO_SPACE						0x80410d12/* wlan device did not have enough internal memory pool */
#define PSP_ERROR_NET_WLAN_INVALID_ARG					0x80410d13/* Invalid argument was specified. */
#define PSP_ERROR_NET_WLAN_NOT_IN_GAMEMODE				0x80410d14/* wlan is not in gamemode */
#define PSP_ERROR_NET_WLAN_LEAVE_FAIL					0x80410d15/* fail to leave IBSS network */
#define PSP_ERROR_NET_WLAN_SUSPENDED					0x80410d16/* the driver is in suspend state */

#ifdef __cplusplus
}
#endif

#endif
