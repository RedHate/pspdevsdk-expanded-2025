#ifndef __PSPNET_H__
#define __PSPNET_H__

#ifdef __cplusplus
extern "C" {
#endif

#include <psptypes.h>
#include <pspkerneltypes.h>

#include <pspnet_resolver.h>
#include <pspnet_inet.h>
#include <pspnet/netinet/in.h>
#include <pspnet/netinet/ip_var.h>
#include <pspnet/netinet/tcp.h>
#include <pspnet/netinet/tcp_fsm.h>
#include <pspnet/netinet/tcp_var.h>
#include <pspnet/netinet/udp_var.h>
#include <pspnet/sys/poll.h>
#include <pspnet/sys/select.h>
#include <pspnet/sys/socket.h>
#include <pspnet/sys/time.h>
#include <pspnet/sys/uio.h>

#define PSPNET_80211_BSSID_LEN		6
#define PSPNET_80211_SSID_LEN		32
#define PSP_NET_ETHER_ADDR_LEN 		6

struct SceNetEtherAddr {
	SceUChar8 data[PSP_NET_ETHER_ADDR_LEN];
};

/**
 * Initialise the networking library
 *
 * @param poolsize 		- Memory pool size (appears to be for the whole of the networking library).
 * @param callout_tpl 	- Priority of the SceNetCallout thread.
 * @param callout_stack - Stack size of the SceNetCallout thread (defaults to 4096 on non 1.5 firmware regardless of what value is passed).
 * @param netintr_tpl 	- Priority of the SceNetNetintr thread.
 * @param netintr_stack - Stack size of the SceNetNetintr thread (defaults to 4096 on non 1.5 firmware regardless of what value is passed).
 *
 * @return 0 on success, < 0 on error
 */
int  sceNetInit( SceSize poolsize, int callout_tpl, SceSize callout_stack, int netintr_tpl, SceSize netintr_stack );
/**
 * Terminate the networking library
 *
 * @return 0 on success, < 0 on error
 */
int  sceNetTerm( void );
/**
 * Free (delete) thread info/data
 *
 * @param tid - The thread id.
 *
 * @return 0 on success, < 0 on error
 */
int  sceNetFreeThreadinfo(SceUID tid);
/**
 * Abort a thread
 *
 * @param tid - The thread id.
 *
 * @return 0 on success, < 0 on error
 */
int  sceNetThreadAbort(SceUID tid);
/**
 * Convert Mac address to a string
 *
 * @param addr - The Mac address to convert.
 * @param str - Pointer to a buffer to store the result.
 */
void sceNetEtherNtostr(const struct SceNetEtherAddr *addr, char *str);
/**
 * Convert string to a Mac address
 *
 * @param str - The string to convert.
 * @param addr - Pointer to a buffer to store the result.
 */
void sceNetEtherStrton(const char *str, struct SceNetEtherAddr *addr);
/**
 * Retrieve the local Mac address
 *
 * @param ether - Pointer to a buffer to store the result.
 *
 * @return 0 on success, < 0 on error
 */
int sceNetGetLocalEtherAddr( struct SceNetEtherAddr *addr );

/* structured data type for sceNetGetMallocStat */
struct SceNetMallocStat {
	int poolsize;
	int maxsize;
	int freesize;
};

/**
 * Retrieve the networking library memory usage
 *
 * @param pspnet_mstat - Pointer to a ::SceNetMallocStat type to store the result.
 *
 * @return 0 on success, < 0 on error
 */
int sceNetGetMallocStat(struct SceNetMallocStat *pspnet_mstat);

int sceNetGetDropRate(SceUInt *rate, SceUInt *duration);

int sceNetSetDropRate(SceUInt rate, SceUInt duration);


#ifdef __cplusplus
}
#endif

#endif 
