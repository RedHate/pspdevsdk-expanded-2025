#ifndef __PSPNET_NETINET_IN_H__
#define __PSPNET_NETINET_IN_H__

#ifdef __cplusplus
extern "C" {
#endif

/*
 * Protocols
 */
#define	PSP_NET_INET_IPPROTO_IP			0		/* dummy for IP */

#define PSP_NET_INET_IPPROTO_HOPOPTS	0		/* IP6 hop-by-hop options */
#define	PSP_NET_INET_IPPROTO_ICMP		1		/* control message protocol */
#define	PSP_NET_INET_IPPROTO_IGMP		2		/* group mgmt protocol */
#define	PSP_NET_INET_IPPROTO_GGP		3		/* gateway^2 (deprecated) */
#define PSP_NET_INET_IPPROTO_IPV4		4 		/* IP header */
#define	PSP_NET_INET_IPPROTO_IPIP		4		/* IP inside IP */
#define	PSP_NET_INET_IPPROTO_TCP		6		/* tcp */
#define	PSP_NET_INET_IPPROTO_EGP		8		/* exterior gateway protocol */
#define	PSP_NET_INET_IPPROTO_PUP		12		/* pup */
#define	PSP_NET_INET_IPPROTO_UDP		17		/* user datagram protocol */
#define	PSP_NET_INET_IPPROTO_IDP		22		/* xns idp */
#define	PSP_NET_INET_IPPROTO_TP			29 		/* tp-4 w/ class negotiation */
#define PSP_NET_INET_IPPROTO_IPV6		41		/* IP6 header */
#define PSP_NET_INET_IPPROTO_ROUTING	43		/* IP6 routing header */
#define PSP_NET_INET_IPPROTO_FRAGMENT	44		/* IP6 fragmentation header */
#define PSP_NET_INET_IPPROTO_RSVP		46		/* resource reservation */
#define PSP_NET_INET_IPPROTO_GRE		47		/* GRE encaps RFC 1701 */
#define	PSP_NET_INET_IPPROTO_ESP		50 		/* encap. security payload */
#define	PSP_NET_INET_IPPROTO_AH			51 		/* authentication header */
#define PSP_NET_INET_IPPROTO_MOBILE		55		/* IP Mobility RFC 2004 */
#define PSP_NET_INET_IPPROTO_IPV6_ICMP	58		/* IPv6 ICMP */
#define PSP_NET_INET_IPPROTO_ICMPV6		58		/* ICMP6 */
#define PSP_NET_INET_IPPROTO_NONE		59		/* IP6 no next header */
#define PSP_NET_INET_IPPROTO_DSTOPTS	60		/* IP6 destination option */
#define	PSP_NET_INET_IPPROTO_EON		80		/* ISO cnlp */
#define	PSP_NET_INET_IPPROTO_ENCAP		98		/* encapsulation header */
#define PSP_NET_INET_IPPROTO_PIM		103		/* Protocol indep. multicast */
#define PSP_NET_INET_IPPROTO_IPCOMP		108		/* IP Payload Comp. Protocol */

#define	PSP_NET_INET_IPPROTO_RAW		255		/* raw IP packet */
#define	PSP_NET_INET_IPPROTO_MAX		256

/* last return value of *_input(), meaning "all job for this pkt is done".  */
#define	PSP_NET_INET_IPPROTO_DONE		257


/*
 * Local port number conventions:
 *
 * Ports < IPPORT_RESERVED are reserved for privileged processes (e.g. root),
 * unless a kernel is compiled with IPNOPRIVPORTS defined.
 *
 * When a user does a bind(2) or connect(2) with a port number of zero,
 * a non-conflicting local port address is chosen.
 *
 * The default range is IPPORT_ANONMIX to IPPORT_ANONMAX, although
 * that is settable by sysctl(3); net.inet.ip.anonportmin and
 * net.inet.ip.anonportmax respectively.
 *
 * A user may set the IPPROTO_IP option IP_PORTRANGE to change this
 * default assignment range.
 *
 * The value IP_PORTRANGE_DEFAULT causes the default behavior.
 *
 * The value IP_PORTRANGE_HIGH is the same as IP_PORTRANGE_DEFAULT,
 * and exists only for FreeBSD compatibility purposes.
 *
 * The value IP_PORTRANGE_LOW changes the range to the "low" are
 * that is (by convention) restricted to privileged processes.
 * This convention is based on "vouchsafe" principles only.
 * It is only secure if you trust the remote host to restrict these ports.
 * The range is IPPORT_RESERVEDMIN to IPPORT_RESERVEDMAX.
 */

#define	PSP_NET_INET_IPPORT_RESERVED		1024
#define	PSP_NET_INET_IPPORT_ANONMIN			49152
#define	PSP_NET_INET_IPPORT_ANONMAX			65535
#define	PSP_NET_INET_IPPORT_RESERVEDMIN		600
#define	PSP_NET_INET_IPPORT_RESERVEDMAX		(PSP_NET_INET_IPPORT_RESERVED-1)

/*
 * Internet address (a structure for historical reasons)
 */

struct SceNetInetInAddr {
	SceUInt32 s_addr;
};

/*
 * Definitions of bits in internet address integers.
 * On subnets, the decomposition of addresses to host and net parts
 * is done according to subnet mask, not the masks here.
 *
 * By byte-swapping the constants, we avoid ever having to byte-swap IP
 * addresses inside the kernel.  Unfortunately, user-level programs rely
 * on these macros not doing byte-swapping.
 */
#define	PSP_NET_INET___IPADDR(x)			((SceUInt32)(x))

#define	PSP_NET_INET_IN_CLASSA(i)			(((SceUInt32)(i) & PSP_NET_INET___IPADDR(0x80000000)) == PSP_NET_INET___IPADDR(0x00000000))
#define	PSP_NET_INET_IN_CLASSA_NET			PSP_NET_INET___IPADDR(0xff000000)
#define	PSP_NET_INET_IN_CLASSA_NSHIFT		24
#define	PSP_NET_INET_IN_CLASSA_HOST			PSP_NET_INET___IPADDR(0x00ffffff)
#define	PSP_NET_INET_IN_CLASSA_MAX			128

#define	PSP_NET_INET_IN_CLASSB(i)			(((SceUInt32)(i) & PSP_NET_INET___IPADDR(0xc0000000)) == PSP_NET_INET___IPADDR(0x80000000))
#define	PSP_NET_INET_IN_CLASSB_NET			PSP_NET_INET___IPADDR(0xffff0000)
#define	PSP_NET_INET_IN_CLASSB_NSHIFT		16
#define	PSP_NET_INET_IN_CLASSB_HOST			PSP_NET_INET___IPADDR(0x0000ffff)
#define	PSP_NET_INET_IN_CLASSB_MAX			65536

#define	PSP_NET_INET_IN_CLASSC(i)			(((SceUInt32)(i) & PSP_NET_INET___IPADDR(0xe0000000)) == PSP_NET_INET___IPADDR(0xc0000000))
#define	PSP_NET_INET_IN_CLASSC_NET			PSP_NET_INET___IPADDR(0xffffff00)
#define	PSP_NET_INET_IN_CLASSC_NSHIFT		8
#define	PSP_NET_INET_IN_CLASSC_HOST			PSP_NET_INET___IPADDR(0x000000ff)

#define	PSP_NET_INET_IN_CLASSD(i)			(((SceUInt32)(i) & PSP_NET_INET___IPADDR(0xf0000000)) == PSP_NET_INET___IPADDR(0xe0000000))
/* These ones aren't really net and host fields, but routing needn't know. */
#define	PSP_NET_INET_IN_CLASSD_NET			PSP_NET_INET___IPADDR(0xf0000000)
#define	PSP_NET_INET_IN_CLASSD_NSHIFT		28
#define	PSP_NET_INET_IN_CLASSD_HOST			PSP_NET_INET___IPADDR(0x0fffffff)
#define	PSP_NET_INET_IN_MULTICAST(i)		PSP_NET_INET_IN_CLASSD(i)

#define	PSP_NET_INET_IN_EXPERIMENTAL(i)		(((SceUInt32)(i) & PSP_NET_INET___IPADDR(0xf0000000)) == PSP_NET_INET___IPADDR(0xf0000000))
#define	PSP_NET_INET_IN_BADCLASS(i)			(((SceUInt32)(i) & PSP_NET_INET___IPADDR(0xf0000000)) == PSP_NET_INET___IPADDR(0xf0000000))
#define	PSP_NET_INET_IN_LOCAL_GROUP(i)		(((SceUInt32)(i) & PSP_NET_INET___IPADDR(0xffffff00)) == PSP_NET_INET___IPADDR(0xe0000000))

#define	PSP_NET_INET_INADDR_ANY				PSP_NET_INET___IPADDR(0x00000000)
#define	PSP_NET_INET_INADDR_LOOPBACK		PSP_NET_INET___IPADDR(0x7f000001)
#define	PSP_NET_INET_INADDR_BROADCAST		PSP_NET_INET___IPADDR(0xffffffff)	/* must be masked */
#define	PSP_NET_INET_INADDR_NONE			PSP_NET_INET___IPADDR(0xffffffff)	/* -1 return */
#define	PSP_NET_INET_INADDR_UNSPEC_GROUP	PSP_NET_INET___IPADDR(0xe0000000)	/* 224.0.0.0 */
#define	PSP_NET_INET_INADDR_ALLHOSTS_GROUP	PSP_NET_INET___IPADDR(0xe0000001)	/* 224.0.0.1 */
#define	PSP_NET_INET_INADDR_ALLRTRS_GROUP	PSP_NET_INET___IPADDR(0xe0000002)	/* 224.0.0.2 */
#define	PSP_NET_INET_INADDR_MAX_LOCAL_GROUP	PSP_NET_INET___IPADDR(0xe00000ff)	/* 224.0.0.255 */

#define	PSP_NET_INET_IN_LOOPBACKNET		127			/* official! */

/*
 * Socket address, internet style.
 */
struct SceNetInetSockaddrIn {
	SceUChar8 sin_len;
	SceUChar8 sin_family;
	SceUShort16 sin_port;
	struct SceNetInetInAddr sin_addr;
	SceChar8 sin_zero[8];
};

#define PSP_NET_INET_INET_ADDRSTRLEN        16

/*
 * Options for use with [gs]etsockopt at the IP level.
 * First word of comment is data type; bool is stored in int.
 */
#define	PSP_NET_INET_IP_OPTIONS             1    /* buf/ip_opts; set/get IP options */
#define	PSP_NET_INET_IP_HDRINCL             2    /* int; header is included with data */
#define	PSP_NET_INET_IP_TOS                 3    /* int; IP type of service and preced. */
#define	PSP_NET_INET_IP_TTL                 4    /* int; IP time to live */
#define	PSP_NET_INET_IP_RECVOPTS            5    /* bool; receive all IP opts w/dgram */
#define	PSP_NET_INET_IP_RECVRETOPTS			6    /* bool; receive IP opts for response */
#define	PSP_NET_INET_IP_RECVDSTADDR			7    /* bool; receive IP dst addr w/dgram */
#define	PSP_NET_INET_IP_RETOPTS				8    /* ip_opts; set/get IP options */
#define	PSP_NET_INET_IP_MULTICAST_IF		9    /* in_addr; set/get IP multicast i/f  */
#define	PSP_NET_INET_IP_MULTICAST_TTL		10   /* u_char; set/get IP multicast ttl */
#define	PSP_NET_INET_IP_MULTICAST_LOOP		11   /* u_char; set/get IP multicast loopback */
#define	PSP_NET_INET_IP_ADD_MEMBERSHIP		12   /* ip_mreq; add an IP group membership */
#define	PSP_NET_INET_IP_DROP_MEMBERSHIP		13   /* ip_mreq; drop an IP group membership */
#define PSP_NET_INET_IP_PORTRANGE			19   /* int; range to use for ephemeral port */
#define	PSP_NET_INET_IP_RECVIF				20   /* bool; receive reception if w/dgram */
#define	PSP_NET_INET_IP_ERRORMTU			21   /* int; get MTU of last xmit = EMSGSIZE */
#if 1 /*IPSEC*/
#define PSP_NET_INET_IP_IPSEC_POLICY		22 /* struct; get/set security policy */
#endif

/*
 * Defaults and limits for options
 */
#define	PSP_NET_INET_IP_DEFAULT_MULTICAST_TTL  	1	/* normally limit m'casts to 1 hop  */
#define	PSP_NET_INET_IP_DEFAULT_MULTICAST_LOOP 	1	/* normally hear sends if a member  */
#define	PSP_NET_INET_IP_MAX_MEMBERSHIPS			20	/* per socket; must fit in one mbuf */

/*
 * Argument structure for IP_ADD_MEMBERSHIP and IP_DROP_MEMBERSHIP.
 */
struct SceNetInetIpMreq {
	struct	SceNetInetInAddr imr_multiaddr;	/* IP multicast address of group */
	struct	SceNetInetInAddr imr_interface;	/* local IP address of interface */
};

#ifdef __cplusplus
}
#endif

#endif 
