#ifndef __PSPNET_NETINET_IP_VAR_H__
#define __PSPNET_NETINET_IP_VAR_H__

#ifdef __cplusplus
extern "C" {
#endif

struct SceNetInetIpstat {
	SceUInt64 ips_total;		/* total packets received */
	SceUInt64 ips_badsum;		/* checksum bad */
	SceUInt64 ips_tooshort;		/* packet too short */
	SceUInt64 ips_toosmall;		/* not enough data */
	SceUInt64 ips_badhlen;		/* ip header length < data size */
	SceUInt64 ips_badlen;		/* ip length < ip header length */
	SceUInt64 ips_fragments;		/* fragments received */
	SceUInt64 ips_fragdropped;	/* frags dropped (dups, out of space) */
	SceUInt64 ips_fragtimeout;	/* fragments timed out */
	SceUInt64 ips_forward;		/* packets forwarded */
	SceUInt64 ips_fastforward;	/* packets fast forwarded */
	SceUInt64 ips_cantforward;	/* packets rcvd for unreachable dest */
	SceUInt64 ips_redirectsent;	/* packets forwarded on same net */
	SceUInt64 ips_noproto;		/* unknown or unsupported protocol */
	SceUInt64 ips_delivered;		/* datagrams delivered to upper level*/
	SceUInt64 ips_localout;		/* total ip packets generated here */
	SceUInt64 ips_odropped;		/* lost packets due to nobufs, etc. */
	SceUInt64 ips_reassembled;	/* total packets reassembled ok */
	SceUInt64 ips_fragmented;	/* datagrams sucessfully fragmented */
	SceUInt64 ips_ofragments;	/* output fragments created */
	SceUInt64 ips_cantfrag;		/* don't fragment flag was set, etc. */
	SceUInt64 ips_badoptions;	/* error in option processing */
	SceUInt64 ips_noroute;		/* packets discarded due to no route */
	SceUInt64 ips_badvers;		/* ip version != 4 */
	SceUInt64 ips_rawout;		/* total raw ip packets generated */
	SceUInt64 ips_badfrags;		/* malformed fragments (bad length) */
	SceUInt64 ips_rcvmemdrop;	/* frags dropped for lack of memory */
	SceUInt64 ips_toolong;		/* ip length > max ip packet size */
	SceUInt64 ips_nogif;		/* no match gif found */
};
#ifdef __cplusplus
}
#endif

#endif 
