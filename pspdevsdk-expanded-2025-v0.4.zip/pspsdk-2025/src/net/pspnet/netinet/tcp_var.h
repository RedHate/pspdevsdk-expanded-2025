#ifndef __PSPNET_NETINET_TCP_VAR_H__
#define __PSPNET_NETINET_TCP_VAR_H__

#ifdef __cplusplus
extern "C" {
#endif

struct SceNetInetTcpcbstat {
	struct SceNetInetTcpcbstat *next;
	unsigned int	ts_so_snd_sb_cc;/* actual chars in send buffer */
	unsigned int	ts_so_rcv_sb_cc;/* actual chars in recv buffer */
	struct SceNetInetInAddr	ts_inp_laddr;	/* local address */
	struct SceNetInetInAddr	ts_inp_faddr;	/* foreign address */
	SceUShort16		ts_inp_lport;	/* local port */
	SceUShort16		ts_inp_fport;	/* foreign port */
	short		ts_t_state;	/* state of this connection */
};

/*
 * TCP statistics.
 * Many of these should be kept per connection,
 * but that's inconvenient at the moment.
 */
struct	SceNetInetTcpstat {
	SceUInt64 tcps_connattempt;	/* connections initiated */
	SceUInt64 tcps_accepts;		/* connections accepted */
	SceUInt64 tcps_connects;		/* connections established */
	SceUInt64 tcps_drops;		/* connections dropped */
	SceUInt64 tcps_conndrops;	/* embryonic connections dropped */
	SceUInt64 tcps_closed;		/* conn. closed (includes drops) */
	SceUInt64 tcps_segstimed;	/* segs where we tried to get rtt */
	SceUInt64 tcps_rttupdated;	/* times we succeeded */
	SceUInt64 tcps_delack;		/* delayed acks sent */
	SceUInt64 tcps_timeoutdrop;	/* conn. dropped in rxmt timeout */
	SceUInt64 tcps_rexmttimeo;	/* retransmit timeouts */
	SceUInt64 tcps_persisttimeo;	/* persist timeouts */
	SceUInt64 tcps_keeptimeo;	/* keepalive timeouts */
	SceUInt64 tcps_keepprobe;	/* keepalive probes sent */
	SceUInt64 tcps_keepdrops;	/* connections dropped in keepalive */
	SceUInt64 tcps_persistdrops;	/* connections dropped in persist */
	SceUInt64 tcps_connsdrained;	/* connections drained due to memory
					   shortage */
	SceUInt64 tcps_pmtublackhole;	/* PMTUD blackhole detected */

	SceUInt64 tcps_sndtotal;		/* total packets sent */
	SceUInt64 tcps_sndpack;		/* data packets sent */
	SceUInt64 tcps_sndbyte;		/* data bytes sent */
	SceUInt64 tcps_sndrexmitpack;	/* data packets retransmitted */
	SceUInt64 tcps_sndrexmitbyte;	/* data bytes retransmitted */
	SceUInt64 tcps_sndacks;		/* ack-only packets sent */
	SceUInt64 tcps_sndprobe;		/* window probes sent */
	SceUInt64 tcps_sndurg;		/* packets sent with URG only */
	SceUInt64 tcps_sndwinup;		/* window update-only packets sent */
	SceUInt64 tcps_sndctrl;		/* control (SYN|FIN|RST) packets sent */

	SceUInt64 tcps_rcvtotal;		/* total packets received */
	SceUInt64 tcps_rcvpack;		/* packets received in sequence */
	SceUInt64 tcps_rcvbyte;		/* bytes received in sequence */
	SceUInt64 tcps_rcvbadsum;	/* packets received with ccksum errs */
	SceUInt64 tcps_rcvbadoff;	/* packets received with bad offset */
	SceUInt64 tcps_rcvmemdrop;	/* packets dropped for lack of memory */
	SceUInt64 tcps_rcvshort;		/* packets received too short */
	SceUInt64 tcps_rcvduppack;	/* duplicate-only packets received */
	SceUInt64 tcps_rcvdupbyte;	/* duplicate-only bytes received */
	SceUInt64 tcps_rcvpartduppack;	/* packets with some duplicate data */
	SceUInt64 tcps_rcvpartdupbyte;	/* dup. bytes in part-dup. packets */
	SceUInt64 tcps_rcvoopack;	/* out-of-order packets received */
	SceUInt64 tcps_rcvoobyte;	/* out-of-order bytes received */
	SceUInt64 tcps_rcvpackafterwin;	/* packets with data after window */
	SceUInt64 tcps_rcvbyteafterwin;	/* bytes rcvd after window */
	SceUInt64 tcps_rcvafterclose;	/* packets rcvd after "close" */
	SceUInt64 tcps_rcvwinprobe;	/* rcvd window probe packets */
	SceUInt64 tcps_rcvdupack;	/* rcvd duplicate acks */
	SceUInt64 tcps_rcvacktoomuch;	/* rcvd acks for unsent data */
	SceUInt64 tcps_rcvackpack;	/* rcvd ack packets */
	SceUInt64 tcps_rcvackbyte;	/* bytes acked by rcvd acks */
	SceUInt64 tcps_rcvwinupd;	/* rcvd window update packets */
	SceUInt64 tcps_pawsdrop;		/* segments dropped due to PAWS */
	SceUInt64 tcps_predack;		/* times hdr predict ok for acks */
	SceUInt64 tcps_preddat;		/* times hdr predict ok for data pkts */

	SceUInt64 tcps_pcbhashmiss;	/* input packets missing pcb hash */
	SceUInt64 tcps_noport;		/* no socket on port */
	SceUInt64 tcps_badsyn;		/* received ack for which we have
					   no SYN in compressed state */

	/* These statistics deal with the SYN cache. */
	SceUInt64 tcps_sc_added;		/* # of entries added */
	SceUInt64 tcps_sc_completed;	/* # of connections completed */
	SceUInt64 tcps_sc_timed_out;	/* # of entries timed out */
	SceUInt64 tcps_sc_overflowed;	/* # dropped due to overflow */
	SceUInt64 tcps_sc_reset;		/* # dropped due to RST */
	SceUInt64 tcps_sc_unreach;	/* # dropped due to ICMP unreach */
	SceUInt64 tcps_sc_bucketoverflow;/* # dropped due to bucket overflow */
	SceUInt64 tcps_sc_aborted;	/* # of entries aborted (no mem) */
	SceUInt64 tcps_sc_dupesyn;	/* # of duplicate SYNs received */
	SceUInt64 tcps_sc_dropped;	/* # of SYNs dropped (no route/mem) */
	SceUInt64 tcps_sc_collisions;	/* # of hash collisions */
	SceUInt64 tcps_sc_retransmitted;	/* # of retransmissions */
};

int	sceNetInetGetTcpcbstat(int *unk, void *buf);

#ifdef __cplusplus
}
#endif

#endif 
