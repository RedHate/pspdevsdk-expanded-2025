#ifndef __PSPINET_SYS_UIO_H__
#define __PSPINET_SYS_UIO_H__

#ifdef __cplusplus
extern "C" {
#endif

struct SceNetIovec {
	void			*iov_base;	/* Base address. */
	unsigned int	 iov_len;	/* Length. */
};

#ifdef __cplusplus
}
#endif

#endif 
