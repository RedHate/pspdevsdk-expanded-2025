#ifndef __PSPINET_SYS_SOCKET_H__
#define __PSPINET_SYS_SOCKET_H__

#ifdef __cplusplus
extern "C" {
#endif


/*
 * Definitions related to sockets: types, address families, options.
 */

/*
 * Data types.
 */
typedef unsigned int	SceNetInetSocklen_t;

/*
 * Socket types.
 */
#define	PSP_NET_INET_SOCK_STREAM		1		/* stream socket */
#define	PSP_NET_INET_SOCK_DGRAM			2		/* datagram socket */
#define	PSP_NET_INET_SOCK_RAW			3		/* raw-protocol interface */
#define	PSP_NET_INET_SOCK_RDM			4		/* reliably-delivered message */
#define	PSP_NET_INET_SOCK_SEQPACKET		5		/* sequenced packet stream */

/*
 * Option flags per-socket.
 */
#define	PSP_NET_INET_SO_DEBUG		0x0001		/* turn on debugging info recording */
#define	PSP_NET_INET_SO_ACCEPTCONN	0x0002		/* socket has had listen() */
#define	PSP_NET_INET_SO_REUSEADDR	0x0004		/* allow local address reuse */
#define	PSP_NET_INET_SO_KEEPALIVE	0x0008		/* keep connections alive */
#define	PSP_NET_INET_SO_DONTROUTE	0x0010		/* just use interface addresses */
#define	PSP_NET_INET_SO_BROADCAST	0x0020		/* permit sending of broadcast msgs */
#define	PSP_NET_INET_SO_USELOOPBACK	0x0040		/* bypass hardware when possible */
#define	PSP_NET_INET_SO_LINGER		0x0080		/* linger on close if data present */
#define	PSP_NET_INET_SO_OOBINLINE	0x0100		/* leave received OOB data in line */
#define	PSP_NET_INET_SO_REUSEPORT	0x0200		/* allow local address & port reuse */
#define	PSP_NET_INET_SO_TIMESTAMP	0x0400		/* timestamp received dgram traffic */
#define	PSP_NET_INET_SO_ONESBCAST	0x0800		/* permit sending to 255.255.255.255 */

/*
 * Additional options, not kept in so_options.
 */
#define PSP_NET_INET_SO_SNDBUF		0x1001		/* send buffer size */
#define PSP_NET_INET_SO_RCVBUF		0x1002		/* receive buffer size */
#define PSP_NET_INET_SO_SNDLOWAT	0x1003		/* send low-water mark */
#define PSP_NET_INET_SO_RCVLOWAT	0x1004		/* receive low-water mark */
#define PSP_NET_INET_SO_SNDTIMEO	0x1005		/* send timeout */
#define PSP_NET_INET_SO_RCVTIMEO	0x1006		/* receive timeout */
#define	PSP_NET_INET_SO_ERROR		0x1007		/* get error status and clear */
#define	PSP_NET_INET_SO_TYPE		0x1008		/* get socket type */
#define PSP_NET_INET_SO_NBIO		0x1009		/* non-blocking I/O */

/*
 * Structure used for manipulating linger option.
 */
struct	SceNetInetLinger {
	int	l_onoff;		/* option on/off */
	int	l_linger;		/* linger time in seconds */
};

/*
 * Level number for (get/set)sockopt() to apply to socket itself.
 */
#define	PSP_NET_INET_SOL_SOCKET	0xffff		/* options for socket level */

/*
 * Address families.
 */
#define	PSP_NET_INET_AF_UNSPEC			0		/* unspecified */
#define	PSP_NET_INET_AF_LOCAL			1		/* local to host (pipes, portals) */
#define	PSP_NET_INET_AF_UNIX			AF_LOCAL	/* backward compatibility */
#define	PSP_NET_INET_AF_INET			2		/* internetwork: UDP, TCP, etc. */
#define	PSP_NET_INET_AF_IMPLINK			3		/* arpanet imp addresses */
#define	PSP_NET_INET_AF_PUP				4		/* pup protocols: e.g. BSP */
#define	PSP_NET_INET_AF_CHAOS			5		/* mit CHAOS protocols */
#define	PSP_NET_INET_AF_NS				6		/* XEROX NS protocols */
#define	PSP_NET_INET_AF_ISO				7		/* ISO protocols */
#define	PSP_NET_INET_AF_OSI				AF_ISO
#define	PSP_NET_INET_AF_ECMA			8		/* european computer manufacturers */
#define	PSP_NET_INET_AF_DATAKIT			9		/* datakit protocols */
#define	PSP_NET_INET_AF_CCITT			10		/* CCITT protocols, X.25 etc */
#define	PSP_NET_INET_AF_SNA				11		/* IBM SNA */
#define PSP_NET_INET_AF_DECnet			12		/* DECnet */
#define PSP_NET_INET_AF_DLI				13		/* DEC Direct data link interface */
#define PSP_NET_INET_AF_LAT				14		/* LAT */
#define	PSP_NET_INET_AF_HYLINK			15		/* NSC Hyperchannel */
#define	PSP_NET_INET_AF_APPLETALK		16		/* Apple Talk */
#define	PSP_NET_INET_AF_ROUTE			17		/* Internal Routing Protocol */
#define	PSP_NET_INET_AF_LINK			18		/* Link layer interface */
#if !defined(PSP_NET_INET__XOPEN_SOURCE)
#define	PSP_NET_INET_pseudo_AF_XTP		19		/* eXpress Transfer Protocol (no AF) */
#endif
#define	PSP_NET_INET_AF_COIP			20		/* connection-oriented IP, aka ST II */
#define	PSP_NET_INET_AF_CNT				21		/* Computer Network Technology */
#if !defined(PSP_NET_INET__XOPEN_SOURCE)
#define PSP_NET_INET_pseudo_AF_RTIP		22		/* Help Identify RTIP packets */
#endif
#define	PSP_NET_INET_AF_IPX				23		/* Novell Internet Protocol */
#define	PSP_NET_INET_AF_INET6			24		/* IP version 6 */
#if !defined(PSP_NET_INET__XOPEN_SOURCE)
#define PSP_NET_INET_pseudo_AF_PIP		25		/* Help Identify PIP packets */
#endif
#define PSP_NET_INET_AF_ISDN			26		/* Integrated Services Digital Network*/
#define PSP_NET_INET_AF_E164			AF_ISDN		/* CCITT E.164 recommendation */
#define PSP_NET_INET_AF_NATM			27		/* native ATM access */
#define PSP_NET_INET_AF_ARP				28		/* (rev.) addr. res. prot. (RFC 826) */
#if !defined(PSP_NET_INET__XOPEN_SOURCE)
#define PSP_NET_INET_pseudo_AF_KEY		29		/* Internal key management protocol  */
#define	PSP_NET_INET_pseudo_AF_HDRCMPLT 30		/* Used by BPF to not rewrite hdrs
					   in interface output routine */
#endif

#define	PSP_NET_INET_AF_MAX				31

/*
 * Structure used by kernel to store most
 * addresses.
 */
struct SceNetInetSockaddr {
	SceUChar8	sa_len;			/* total length */
	SceUChar8	sa_family;		/* address family */
	SceChar8	sa_data[14];		/* actually longer; address value */
};

/*
 * Maximum queue length specifiable by listen(2).
 */

#define	PSP_NET_INET_SOMAXCONN	128

/*
 * Message header for recvmsg and sendmsg calls.
 * Used value-result for recvmsg, value only for sendmsg.
 */
struct SceNetInetMsghdr {
	void				*msg_name;				/* optional address */
	SceNetInetSocklen_t	msg_namelen;			/* size of address */
	struct 				SceNetIovec	*msg_iov;	/* scatter/gather array */
	int					msg_iovlen;				/* # elements in msg_iov */
	void				*msg_control;			/* ancillary data, see below */
	SceNetInetSocklen_t	msg_controllen;			/* ancillary data buffer len */
	int					msg_flags;				/* flags on received message */
};

#define	PSP_NET_INET_MSG_OOB		0x1			/* process out-of-band data */
#define	PSP_NET_INET_MSG_PEEK		0x2			/* peek at incoming message */
#define	PSP_NET_INET_MSG_DONTROUTE	0x4			/* send without using routing tables */
#define	PSP_NET_INET_MSG_EOR		0x8			/* data completes record */
#define	PSP_NET_INET_MSG_TRUNC		0x10		/* data discarded before delivery */
#define	PSP_NET_INET_MSG_CTRUNC		0x20		/* control data lost before delivery */
#define	PSP_NET_INET_MSG_WAITALL	0x40		/* wait for full request or error */
#define	PSP_NET_INET_MSG_DONTWAIT	0x80		/* this message should be nonblocking */
#define	PSP_NET_INET_MSG_BCAST		0x100		/* this message was rcvd using link-level brdcst */
#define	PSP_NET_INET_MSG_MCAST		0x200		/* this message was rcvd using link-level mcast */

/*
 * Types of socket shutdown(2).
 */
#define	PSP_NET_INET_SHUT_RD		0			/* Disallow further receives. */
#define	PSP_NET_INET_SHUT_WR		1			/* Disallow further sends. */
#define	PSP_NET_INET_SHUT_RDWR		2			/* Disallow further sends/receives. */

/*
 * socket functions
 */
int	sceNetInetAccept(int s, struct SceNetInetSockaddr *addr, SceNetInetSocklen_t *addrlen);
int	sceNetInetBind(int s, const struct SceNetInetSockaddr *my_addr, SceNetInetSocklen_t addrlen);
int	sceNetInetConnect(int s, const struct SceNetInetSockaddr *serv_addr, SceNetInetSocklen_t addrlen);
int	sceNetInetGetpeername(int s, struct SceNetInetSockaddr *name, SceNetInetSocklen_t *namelen);
int	sceNetInetGetsockname(int s, struct SceNetInetSockaddr *name, SceNetInetSocklen_t *namelen);
int	sceNetInetGetsockopt(int s, int level, int optname, void *optval, SceNetInetSocklen_t *optlen);
int	sceNetInetListen(int s, int backlog);
int sceNetInetRecv(int s, void *buf, SceSize len, int flags);
int sceNetInetRecvfrom(int s, void *buf, SceSize flags, int, struct SceNetInetSockaddr *from, SceNetInetSocklen_t *fromlen);
int sceNetInetRecvmsg(int s, struct SceNetInetMsghdr *msg, int flags);
int sceNetInetSend(int s, const void *buf, SceSize len, int flags);
int	sceNetInetSendto(int s, const void *buf, SceSize len, int flags, const struct SceNetInetSockaddr *to, SceNetInetSocklen_t tolen);
int sceNetInetSendmsg(int s, const struct SceNetInetMsghdr *msg, int flags);
int	sceNetInetSetsockopt(int s, int level, int optname, const void *optval, SceNetInetSocklen_t optlen);
int	sceNetInetShutdown(int s, int how);
int	sceNetInetSocket(int domain, int type, int protocol);



#ifdef __cplusplus
}
#endif

#endif 
