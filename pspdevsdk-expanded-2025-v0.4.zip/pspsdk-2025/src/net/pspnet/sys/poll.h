#ifndef __PSPINET_SYS_POLL_H__
#define __PSPINET_SYS_POLL_H__

#ifdef __cplusplus
extern "C" {
#endif

typedef unsigned int	SceNetInetNfds_t;

struct SceNetInetPollfd {
	int		fd;			/* file descriptor */
	short	events;		/* events to look for */
	short	revents;	/* events returned */
};

/*
 * Testable events (may be specified in events field).
 */
#define PSP_NET_INET_POLLIN 	0x0001
#define PSP_NET_INET_POLLPRI 	0x0002
#define PSP_NET_INET_POLLOUT 	0x0004
#define PSP_NET_INET_POLLRDNORM 0x0040
#define PSP_NET_INET_POLLWRNORM PSP_NET_INET_POLLOUT
#define PSP_NET_INET_POLLRDBAND 0x0080
#define PSP_NET_INET_POLLWRBAND 0x0100

/*
 * Non-testable events (may not be specified in events field).
 */
#define PSP_NET_INET_POLLERR  0x0008
#define PSP_NET_INET_POLLHUP  0x0010
#define PSP_NET_INET_POLLNVAL 0x0020

/*
 * Infinite timeout value.
 */
#define PSP_NET_INET_INFTIM -1

int	sceNetInetPoll (struct SceNetInetPollfd *, SceNetInetNfds_t, int);

#ifdef __cplusplus
}
#endif

#endif 
