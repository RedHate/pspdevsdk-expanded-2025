/*
 * PSP Software Development Kit - https://github.com/pspdev
 * -----------------------------------------------------------------------
 * Licensed under the BSD license, see LICENSE in PSPSDK root for details.
 *
 * inethelper.c - Helper functions for internet related modules.
 *
 * Copyright (c) 2005 John Kelley <ps2dev@kelley.ca>
 * Copyright (c) 2005 Marcus R. Brown <mrbrown@ocgnet.org>
 *
 * This is a stupid fucking library if i've ever seen one. -ultros was here.
 * well atleast i fixed the module loading...
 * 
 */

#include <pspkernel.h>
#include <pspsdk.h>
#include <pspnet.h>
#include <pspnet_inet.h>
#include <pspnet_resolver.h>
#include <pspnet_apctl.h>

#include <pspnet/netinet/in.h>
#include <pspnet/netinet/ip_var.h>
#include <pspnet/netinet/udp_var.h>
#include <pspnet/netinet/tcp.h>
#include <pspnet/netinet/tcp_var.h>
#include <pspnet/netinet/tcp_fsm.h>

#include <psputility_netmodules.h>

//#include <pspNetApDialogDummy.h>

#ifdef F_pspSdkLoadInetModules
int pspSdkLoadInetModules()
{
	sceUtilityLoadNetModule(PSP_NET_MODULE_COMMON);
	sceUtilityLoadNetModule(PSP_NET_MODULE_INET);
	sceUtilityLoadNetModule(PSP_NET_MODULE_COMMON);
	sceUtilityLoadNetModule(PSP_NET_MODULE_ADHOC);
	sceUtilityLoadNetModule(PSP_NET_MODULE_INET);
	sceUtilityLoadNetModule(PSP_NET_MODULE_PARSEURI);
	sceUtilityLoadNetModule(PSP_NET_MODULE_PARSEHTTP);
	sceUtilityLoadNetModule(PSP_NET_MODULE_HTTP);
	sceUtilityLoadNetModule(PSP_NET_MODULE_SSL);
	return 0;
}
#endif

#ifdef F_pspSdkUnLoadInetModules
int pspSdkLoadInetModules()
{
	sceUtilityUnloadNetModule(PSP_NET_MODULE_COMMON);
	sceUtilityUnloadNetModule(PSP_NET_MODULE_INET);
	sceUtilityUnloadNetModule(PSP_NET_MODULE_COMMON);
	sceUtilityUnloadNetModule(PSP_NET_MODULE_ADHOC);
	sceUtilityUnloadNetModule(PSP_NET_MODULE_INET);
	sceUtilityUnloadNetModule(PSP_NET_MODULE_PARSEURI);
	sceUtilityUnloadNetModule(PSP_NET_MODULE_PARSEHTTP);
	sceUtilityUnloadNetModule(PSP_NET_MODULE_HTTP);
	sceUtilityUnloadNetModule(PSP_NET_MODULE_SSL);
	return 0;
}
#endif

#ifdef F_pspSdkInetInit
int pspSdkInetInit()
{
	u32 retVal;

	retVal = sceNetInit(0x20000, 0x20, 0x1000, 0x20, 0x1000);
	if (retVal != 0)
		return retVal;

	retVal = sceNetInetInit();
	if (retVal != 0)
		return retVal;

	retVal = sceNetResolverInit();
	if (retVal != 0)
		return retVal;
	
	retVal = sceNetApctlInit(0x1600, 0x42);
	if (retVal != 0)
		return retVal;

/*
	retVal = sceNetApDialogDummyInit();
	if(retVal != 0)
		return retVal;
*/
	return 0;
}
#endif

#ifdef F_pspSdkInetTerm
void pspSdkInetTerm()
{
	//sceNetApDialogDummyTerm();
	sceNetApctlTerm();
	sceNetResolverTerm();
	sceNetInetTerm();
	sceNetTerm();
}
#endif
