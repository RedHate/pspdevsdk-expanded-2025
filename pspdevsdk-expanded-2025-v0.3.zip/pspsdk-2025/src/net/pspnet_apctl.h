#ifndef __PSPNET_APCTL_H__
#define __PSPNET_APCTL_H__

#ifdef __cplusplus
extern "C" {
#endif

#include <psptypes.h>
#include <pspkerneltypes.h>
#include <psputility_netparam.h>

/* state */
#define PSP_NET_APCTL_STATE_Disconnected     0
#define PSP_NET_APCTL_STATE_Scanning         1
#define PSP_NET_APCTL_STATE_Joining          2
#define PSP_NET_APCTL_STATE_IPObtaining      3
#define PSP_NET_APCTL_STATE_IPObtained       4
#define PSP_NET_APCTL_STATE_MAX              5

/* event */
#define PSP_NET_APCTL_EVENT_CONNECT_REQ      0
#define PSP_NET_APCTL_EVENT_SCAN_REQ         1
#define PSP_NET_APCTL_EVENT_SCAN_COMPLETED   2
#define PSP_NET_APCTL_EVENT_ESTABLISH        3
#define PSP_NET_APCTL_EVENT_GET_IP           4
#define PSP_NET_APCTL_EVENT_DISCONNECT_REQ   5
#define PSP_NET_APCTL_EVENT_ERROR            6
#define PSP_NET_APCTL_EVENT_INFO             7 /* reserved */

/* code */
#define PSP_NET_APCTL_INFO_CNF_NAME          0
#define PSP_NET_APCTL_INFO_BSSID             1
#define PSP_NET_APCTL_INFO_SSID              2
#define PSP_NET_APCTL_INFO_SSID_LEN          3
#define PSP_NET_APCTL_INFO_AUTH_PROTO        4
#define PSP_NET_APCTL_INFO_RSSI              5
#define PSP_NET_APCTL_INFO_CHANNEL           6
#define PSP_NET_APCTL_INFO_PWRSAVE           7
#define PSP_NET_APCTL_INFO_IP_ADDRESS        8
#define PSP_NET_APCTL_INFO_NETMASK           9
#define PSP_NET_APCTL_INFO_DEFAULT_ROUTE     10
#define PSP_NET_APCTL_INFO_PRIMARY_DNS       11
#define PSP_NET_APCTL_INFO_SECONDARY_DNS     12
#define PSP_NET_APCTL_INFO_HTTP_PROXY_FLAG   13
#define PSP_NET_APCTL_INFO_HTTP_PROXY_SERVER 14
#define PSP_NET_APCTL_INFO_HTTP_PROXY_PORT   15

/* auth_proto */
#define PSP_NET_APCTL_INFO_AUTH_PROTO_NOAUTH       0
#define PSP_NET_APCTL_INFO_AUTH_PROTO_WEP          1

/* http_proxy_flag */
#define PSP_NET_APCTL_INFO_HTTP_PROXY_OFF          0
#define PSP_NET_APCTL_INFO_HTTP_PROXY_ON           1

#define PSP_NET_APCTL_BSSID_LEN                    6
#define PSP_NET_APCTL_SSID_LEN                     32
#define PSP_NET_APCTL_TEMP_CNF_ID                  0
#define PSP_NET_APCTL_SSID_LEN                     32
#define PSP_NET_APCTL_WEP_KEY_LEN                  13
#define PSP_NET_APCTL_CNF_NAME_LEN                 64
#define PSP_NET_APCTL_IPV4_ADDR_STR_LEN            16
#define PSP_NET_APCTL_HOSTNAME_LEN                 128
#define PSP_NET_APCTL_AUTH_NAME_LEN                128
#define PSP_NET_APCTL_AUTH_KEY_LEN                 128


union SceNetApctlInfo {
	SceChar8 cnf_name[PSP_NET_APCTL_CNF_NAME_LEN];
	SceUChar8 bssid[PSP_NET_APCTL_BSSID_LEN];
	SceUChar8 ssid[PSP_NET_APCTL_SSID_LEN];
	SceSize ssidlen;
	SceUInt32 auth_proto;
	SceUChar8 rssi;
	SceUChar8 channel;
	SceUChar8 pwrsave;
	SceChar8 ip_address[PSP_NET_APCTL_IPV4_ADDR_STR_LEN];
	SceChar8 netmask[PSP_NET_APCTL_IPV4_ADDR_STR_LEN];
	SceChar8 default_route[PSP_NET_APCTL_IPV4_ADDR_STR_LEN];
	SceChar8 primary_dns[PSP_NET_APCTL_IPV4_ADDR_STR_LEN];
	SceChar8 secondary_dns[PSP_NET_APCTL_IPV4_ADDR_STR_LEN];
	SceUInt32 http_proxy_flag;
	SceChar8 http_proxy_server[PSP_NET_APCTL_HOSTNAME_LEN];
	SceUShort16 http_proxy_port;
};

/**
 * Init the apctl.
 *
 * @param stacksize - The stack size of the internal thread.
 *
 * @param prio - The priority of the internal thread.
 *
 * @return < 0 on error.
 */
int sceNetApctlInit(SceSize stacksize,int prio);
/**
 * Terminate the apctl.
 *
 * @return < 0 on error.
 */
int sceNetApctlTerm(void);
/**
 * Get the apctl information.
 *
 * @param code - One of the PSP_NET_APCTL_INFO_* defines.
 *
 * @param info - Pointer to a ::SceNetApctlInfo.
 *
 * @return < 0 on error.
 */
int sceNetApctlGetInfo(int code, union SceNetApctlInfo *info);

typedef void (*sceNetApctlHandler)(int prev_state,int new_state,int event,int error_code,void *arg);
/**
 * Add an apctl event handler.
 *
 * @param handler - Pointer to the event handler function.
 *
 * @param arg - Value to be passed to the pArg parameter of the handler function.
 *
 * @return A handler id or < 0 on error.
 */
int sceNetApctlAddHandler(sceNetApctlHandler handler,void *arg);
/**
 * Delete an apctl event handler.
 *
 * @param id - A handler as created returned from sceNetApctlAddHandler.
 *
 * @return < 0 on error.
 */
int sceNetApctlDelHandler(int id);
/**
 * Connect to an access point.
 *
 * @param cnf_id - The index of the connection.
 *
 * @return < 0 on error.
 */
int sceNetApctlConnect(int cnf_id);
/**
 * Disconnect from an access point.
 *
 * @return < 0 on error.
 */
int sceNetApctlDisconnect(void);
/**
 * Get the state of the access point connection.
 *
 * @param state - Pointer to receive the current state (one of the PSP_NET_APCTL_STATE_* defines).
 *
 * @return < 0 on error.
 */
int sceNetApctlGetState(int *state);

#ifdef __cplusplus
}
#endif

#endif
