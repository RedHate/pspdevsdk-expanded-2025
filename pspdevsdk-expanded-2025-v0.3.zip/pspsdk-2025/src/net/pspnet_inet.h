#ifndef __PSPNET_INET_H__
#define __PSPNET_INET_H__

#include <psptypes.h>
#include <pspkerneltypes.h>
#include <pspnet/netinet/in.h>
#include <pspnet/netinet/ip_var.h>
#include <pspnet/netinet/tcp.h>
#include <pspnet/netinet/tcp_fsm.h>
#include <pspnet/netinet/tcp_var.h>
#include <pspnet/netinet/udp_var.h>
#include <pspnet/sys/poll.h>
#include <pspnet/sys/select.h>
#include <pspnet/sys/socket.h>
#include <pspnet/sys/time.h>
#include <pspnet/sys/uio.h>

/**
 * Init the inet library
 *
 * @return 0 on success, < 0 on error
 */
int sceNetInetInit(void);
/**
 * Terminate the inet library
 *
 * @return 0 on success, < 0 on error
 */
int sceNetInetTerm(void);
/**
 * Get inet error 
 *
 * @return 0 on success, < 0 on error
 */
int sceNetInetGetErrno(void);
/**
 * Inet close socket
 *
 * @return 0 on success, < 0 on error
 */
int sceNetInetClose(int s);
/**
 * Inet close socket with RST
 *
 * @return 0 on success, < 0 on error
 */
int sceNetInetCloseWithRST(int s);

/**
 * IP address to plain network address for client connections
 * 
 * @return - network address in machine specific endianess
 */
SceUInt32 sceNetInetInetAddr(const char *cp);

/**
 * Convert Internet host address from numbers-and-dots notation in CP
 * into binary data and store the result in the structure ADDR.
 * 
 * @param ip - IP address string "192.168.1.10"
 * @param addr - destination struct SceNetInetInAddr network address
 * 
 * @return < 0 on failure
 */
int sceNetInetInetAton(const char *cp, struct SceNetInetInAddr *addr);

/**
 * Convert Internet number in IN to ASCII representation.  The return value
 * is a pointer to an internal array containing the string.
 * 
 * @param addr - destination struct SceNetInetInAddr network address
 * 
 * @return - IP address string "192.168.1.10"
 */
const char *sceNetInetInetNtoa(struct SceNetInetInAddr *addr);

/**
 * Convert from presentation format of an Internet number in buffer
 * starting at CP to the binary network format and store result for
 * interface type AF in buffer starting at DEST.  
 * 
 * @param af  - one of the PSP_NET_INET_AF params (found in <pspnet/sys/socket.h>)
 * @param cp - the string used for the port "32"
 * @param dst - destination buffer for the output name
 * 
 * @return < 0 on failure
 */
int sceNetInetInetPton(int af, const char *cp, void *dst);

/**
 * Convert a Internet address in binary network format for interface
 * type AF in buffer starting at CP to presentation form and place
 * result in buffer of length LEN astarting at BUF.
 * 
 * @param af  - one of the PSP_NET_INET_AF params (found in <pspnet/sys/socket.h>)
 * 
 */
const char *sceNetInetInetNtop(int af, const void *src, char *dst, SceSize size);

/*
 * bitswap functions (allegrex)
 */

/**
 * Host to nameshort
 *
 * @return the bit flipped 16bit value (network endianess)
 */
static __inline__ SceUShort16 sceNetHtons(SceUShort16 host16){
    return __builtin_allegrex_wsbh(host16);
}
/**
 * Host to namelong
 *
 * @return the bit flipped 32bit value (network endianess)
 */
static __inline__ SceUInt32 sceNetHtonl(SceUInt32 host32){
    return __builtin_allegrex_wsbw(host32);
}
/**
 * Hame to hostshort
 *
 * @return the bit flipped 16bit value (host endianess)
 */
static __inline__ SceUShort16 sceNetNtohs(SceUShort16 net16){
    return __builtin_allegrex_wsbh(net16);
}
/**
 * Hame to hostlong
 *
 * @return the bit flipped 32bit value (host endianess)
 */
static __inline__ SceUInt32 sceNetNtohl(SceUInt32 net32){
    return __builtin_allegrex_wsbw(net32);
}

#ifdef __cplusplus
}
#endif

#endif 
