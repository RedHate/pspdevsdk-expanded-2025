#ifndef __PSPNET_RESOLVER_H__
#define __PSPNET_RESOLVER_H__

#ifdef __cplusplus
extern "C" {
#endif

#include <psptypes.h>
#include <pspkerneltypes.h>
#include <pspnet/netinet/in.h>
#include <pspnet_inet.h>

/**
 * Inititalise the resolver library
 *
 * @return 0 on sucess, < 0 on error.
 */
int sceNetResolverInit( void );
/**
 * Terminate the resolver library
 *
 * @return 0 on success, < 0 on error
 */
int sceNetResolverTerm( void );
/**
 * Create a resolver object
 *
 * @param rid - Pointer to receive the resolver id
 * @param buf - Temporary buffer
 * @param buflen - Length of the temporary buffer
 *
 * @return 0 on success, < 0 on error
 */
int sceNetResolverCreate( int *rid, void *buf, SceSize buflen );
/**
 * Delete a resolver
 *
 * @param rid - The resolver to delete
 *
 * @return 0 on success, < 0 on error
 */
int sceNetResolverDelete( int rid );
/**
 * Begin a name to address lookup
 *
 * @param rid - Resolver id
 * @param hostname - Name to resolve
 * @param addr - Pointer to SceNetInetInAddr structure to receive the address
 * @param timeout - Number of seconds before timeout
 * @param retry - Number of retires
 *
 * @return 0 on success, < 0 on error
 */
int sceNetResolverStartNtoA( int rid, const char *hostname, struct SceNetInetInAddr *addr, unsigned int timeout, int retry );
/**
 * Begin a address to name lookup
 *
 * @param rid -Resolver id
 * @param addr - Pointer to the address to resolve (SceNetInetInAddr)
 * @param hostname - Buffer to receive the name
 * @param hostname_len - Length of the buffer
 * @param timeout - Number of seconds before timeout
 * @param retry - Number of retries
 *
 * @return 0 on success, < 0 on error
 */
int sceNetResolverStartAtoN( int rid, const struct SceNetInetInAddr *addr, char *hostname, SceSize hostname_len, unsigned int timeout, int retry);
/**
 * Stop a resolver operation
 * 
 * @param rid - Resolver id
 * 
 * @return 0 on success, < 0 on error
 */
int sceNetResolverStop(int rid);

#ifdef __cplusplus
}
#endif

#endif 
