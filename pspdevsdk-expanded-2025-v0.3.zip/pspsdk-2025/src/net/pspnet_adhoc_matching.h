#ifndef __PSPNET_ADHOC_MATCHING_H__
#define __PSPNET_ADHOC_MATCHING_H__

#ifdef __cplusplus
extern "C" {
#endif

/* Member */
struct SceNetAdhocMatchingMember {
	struct SceNetAdhocMatchingMember *next;
	struct SceNetEtherAddr addr;
	SceUChar8 padding[2];
} SceNetAdhocMatchingMember;

/** 
 * Linked list for sceNetAdhocMatchingGetMembers
 */
struct SceNetAdhocPoolStat {
	int size; 		/** Size of the pool */
	int maxsize; 	/** Maximum size of the pool */
	int freesize; 	/** Unused memory in the pool */
}SceNetAdhocPoolStat;

/* Mode */
#define PSP_NET_ADHOC_MATCHING_MODE_PARENT			1
#define PSP_NET_ADHOC_MATCHING_MODE_CHILD			2
#define PSP_NET_ADHOC_MATCHING_MODE_P2P				3

/* Event Type */
#define PSP_NET_ADHOC_MATCHING_EVENT_HELLO			1
#define PSP_NET_ADHOC_MATCHING_EVENT_REQUEST		2
#define PSP_NET_ADHOC_MATCHING_EVENT_LEAVE			3
#define PSP_NET_ADHOC_MATCHING_EVENT_DENY			4
#define PSP_NET_ADHOC_MATCHING_EVENT_CANCEL			5
#define PSP_NET_ADHOC_MATCHING_EVENT_ACCEPT			6
#define PSP_NET_ADHOC_MATCHING_EVENT_ESTABLISHED	7
#define PSP_NET_ADHOC_MATCHING_EVENT_TIMEOUT		8
#define PSP_NET_ADHOC_MATCHING_EVENT_ERROR			9
#define PSP_NET_ADHOC_MATCHING_EVENT_BYE			10

#define PSP_NET_ADHOC_MATCHING_MAXNUM				16
#define PSP_NET_ADHOC_MATCHING_MAXOPTLEN			65511
#define PSP_NET_ADHOC_MATCHING_MAXHELLOOPTLEN		65503

/** Matching callback */
typedef void (*sceNetAdhocMatchingHandler)(int, int, struct SceNetEtherAddr *, int, void *);

/** 
 * Initialise the Adhoc matching library
 *
 * @param poolsize - Internal memory pool size. Lumines uses 0x20000
 * 
 * @return 0 on success, < 0 on error
 */
int sceNetAdhocMatchingInit(SceSize poolsize);
/**
 * Terminate the Adhoc matching library
 *
 * @return 0 on success, < 0 on error
 */
int sceNetAdhocMatchingTerm(void);
/**
 * Create an Adhoc matching object
 *
 * @param mode - One of ::SceNetAdhocMatchingModes
 * @param maxnum - Maximum number of peers to match (only used when mode is PSP_ADHOC_MATCHING_MODE_HOST)
 * @param port - Port. Lumines uses 0x22B
 * @param rxbuflen - Receiving buffer size
 * @param hello_int - Hello message send delay in microseconds (only used when mode is PSP_ADHOC_MATCHING_MODE_HOST or PSP_ADHOC_MATCHING_MODE_PTP)
 * @param keepalive_int - Ping send delay in microseconds. Lumines uses 0x5B8D80 (only used when mode is PSP_ADHOC_MATCHING_MODE_HOST or PSP_ADHOC_MATCHING_MODE_PTP)
 * @param keepalive_count - Initial count of the of the resend counter. Lumines uses 3
 * @param rexmt_int - Message send delay in microseconds
 * @param handler - Callback to be called for matching
 *
 * @return ID of object on success, < 0 on error.
 */
int sceNetAdhocMatchingCreate(int mode,int maxnum,SceUShort16 port,int rxbuflen,unsigned int hello_int,unsigned int keepalive_int,int keepalive_count,unsigned int rexmt_int,sceNetAdhocMatchingHandler handler);
/**
 * Start a matching object
 *
 * @param id - The ID returned from ::sceNetAdhocMatchingCreate
 * @param event_th_prio - Priority of the event handler thread. Lumines uses 0x10
 * @param event_th_stack - Stack size of the event handler thread. Lumines uses 0x2000
 * @param input_th_prio - Priority of the input handler thread. Lumines uses 0x10
 * @param input_th_stack - Stack size of the input handler thread. Lumines uses 0x2000
 * @param hello_optlen - Size of hellodata
 * @param hello_opt - Pointer to block of data passed to callback
 *
 * @return 0 on success, < 0 on error
 */
int sceNetAdhocMatchingStart(int id,int event_th_prio,int event_th_stack,int input_th_prio,int input_th_stack,int hello_optlen,const void *hello_opt);
/** 
 * Stop a matching object
 *
 * @param id - The ID returned from ::sceNetAdhocMatchingCreate
 *
 * @return 0 on success, < 0 on error.
 */
int sceNetAdhocMatchingStop(int id);
/**
 * Delete an Adhoc matching object
 *
 * @param id - The ID returned from ::sceNetAdhocMatchingCreate
 *
 * @return 0 on success, < 0 on error.
 */
int sceNetAdhocMatchingDelete(int id);
/**
 * Select a matching target
 *
 * @param id - The ID returned from ::sceNetAdhocMatchingCreate
 * @param target - MAC address to select
 * @param optlen - Optional data length
 * @param opt - Pointer to the optional data
 *
 * @return 0 on success, < 0 on error.
 */
int sceNetAdhocMatchingSelectTarget(int id,const struct SceNetEtherAddr *target,int optlen,const void *opt);
/**
 * Cancel a matching target
 *
 * @param id - The ID returned from ::sceNetAdhocMatchingCreate
 * @param target - The MAC address to cancel
 *
 * @return 0 on success, < 0 on error.
 */
int sceNetAdhocMatchingCancelTarget(int id,const struct SceNetEtherAddr *target);
/**
 * Cancel a matching target (with optional data)
 *
 * @param matchingid - The ID returned from ::sceNetAdhocMatchingCreate
 * @param mac - The MAC address to cancel
 * @param optlen - Optional data length
 * @param optdata - Pointer to the optional data
 *
 * @return 0 on success, < 0 on error.
 */
int sceNetAdhocMatchingCancelTargetWithOpt(int matchingid, unsigned char *mac, int optlen, void *optdata);
/**
 * Send data to a matching target
 *
 * @param matchingid - The ID returned from ::sceNetAdhocMatchingCreate
 * @param mac - The MAC address to send the data to
 * @param datalen - Length of the data
 * @param data - Pointer to the data
 *
 * @return 0 on success, < 0 on error.
 */
int sceNetAdhocMatchingSendData(int matchingid, unsigned char *mac, int datalen, void *data);
/**
 * Abort a data send to a matching target
 *
 * @param matchingid - The ID returned from ::sceNetAdhocMatchingCreate
 * @param mac - The MAC address to send the data to
 *
 * @return 0 on success, < 0 on error.
 */
int sceNetAdhocMatchingAbortSendData(int matchingid, unsigned char *mac);
/**
 * Set the optional hello message
 *
 * @param id - The ID returned from ::sceNetAdhocMatchingCreate
 * @param optlen - Length of the hello data
 * @param opt - Pointer to the hello data
 *
 * @return 0 on success, < 0 on error.
 */
int sceNetAdhocMatchingSetHelloOpt(int id,int optlen,const void *opt);
/**
 * Get the optional hello message
 *
 * @param id - The ID returned from ::sceNetAdhocMatchingCreate
 * @param buflen - Length of the hello data
 * @param buf - Pointer to the hello data
 *
 * @return 0 on success, < 0 on error.
 */
int sceNetAdhocMatchingGetHelloOpt(int id,int *buflen,void *buf);
/**
 * Get a list of matching members
 *
 * @param id - The ID returned from ::sceNetAdhocMatchingCreate
 * @param buflen - The length of the list.
 * @param buf - An allocated area of size length.
 *
 * @return 0 on success, < 0 on error.
 */
int sceNetAdhocMatchingGetMembers(int id,int *buflen,void *buf);
/**
 * Get the maximum memory usage by the matching library
 *
 * @return The memory usage on success, < 0 on error.
 */
int sceNetAdhocMatchingGetPoolMaxAlloc(void);
/**
 * Get the status of the memory pool used by the matching library
 *
 * @param poolstat - A ::SceNetAdhocPoolStat.
 *
 * @return 0 on success, < 0 on error.
 */
int sceNetAdhocMatchingGetPoolStat(struct SceNetAdhocPoolStat *poolstat);

#ifdef __cplusplus
}
#endif

#endif 
