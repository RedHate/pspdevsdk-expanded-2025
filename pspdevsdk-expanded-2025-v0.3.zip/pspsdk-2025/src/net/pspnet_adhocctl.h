#ifndef __PSPNET_ADHOCCTL_H__
#define __PSPNET_ADHOCCTL_H__

#ifdef __cplusplus
extern "C" {
#endif

/* adhocctl event */
#define PSP_NET_ADHOCCTL_EVENT_ERROR			0
#define PSP_NET_ADHOCCTL_EVENT_CONNECT			1
#define PSP_NET_ADHOCCTL_EVENT_DISCONNECT		2
#define PSP_NET_ADHOCCTL_EVENT_SCAN				3
#define PSP_NET_ADHOCCTL_EVENT_GAMEMODE			4
/* Reserved */
#define PSP_NET_ADHOCCTL_EVENT_INFO				5

/* adhocctl state */
#define PSP_NET_ADHOCCTL_STATE_DISCONNECTED		0
#define PSP_NET_ADHOCCTL_STATE_CONNECTED		1
#define PSP_NET_ADHOCCTL_STATE_SCANNING			2
#define PSP_NET_ADHOCCTL_STATE_GAMEMODE			3

/* Adhoc ID */
#define PSP_NET_ADHOCCTL_ADHOCID_LEN 9
#define PSP_NET_ADHOCCTL_ADHOCTYPE_PRODUCT_ID	0
#define PSP_NET_ADHOCCTL_ADHOCTYPE_RESERVED		1
#define PSP_NET_ADHOCCTL_ADHOCTYPE_SYSTEM		2

struct SceNetAdhocctlAdhocId {
	int type;
	SceUChar8 data[PSP_NET_ADHOCCTL_ADHOCID_LEN];
	SceUChar8 padding[3];
};

/* Group Name */
#define PSP_NET_ADHOCCTL_GROUPNAME_LEN 8
struct SceNetAdhocctlGroupName {
	SceUChar8 data[PSP_NET_ADHOCCTL_GROUPNAME_LEN];
};

/* Nickname */
#define PSP_NET_ADHOCCTL_NICKNAME_LEN	128
struct SceNetAdhocctlNickname {
	SceUChar8 data[PSP_NET_ADHOCCTL_NICKNAME_LEN];
};

/* Peer Info */
struct SceNetAdhocctlPeerInfo {
	struct SceNetAdhocctlPeerInfo *next;
	struct SceNetAdhocctlNickname nickname;
	struct SceNetEtherAddr mac_addr;
	SceUChar8 padding[2];
};

/* SSID */
#define PSP_NET_ADHOCCTL_BSSID_LEN	6
struct SceNetAdhocctlBSSId {
	SceUChar8 data[PSP_NET_ADHOCCTL_BSSID_LEN];
	SceUChar8 padding[2];
};

/* IBSS Parameter */
struct SceNetAdhocctlParameter {
	int channel;
	struct SceNetAdhocctlGroupName group_name;
	struct SceNetAdhocctlNickname nickname;
	struct SceNetAdhocctlBSSId bssid;
};

/* Network mode */
#define PSP_NET_ADHOCCTL_MODE_ADHOC				0
#define PSP_NET_ADHOCCTL_MODE_GAMEMODE			1
/* IBSS Scan information */
struct SceNetAdhocctlScanInfo {
	struct SceNetAdhocctlScanInfo *next;
	int channel;
	struct SceNetAdhocctlGroupName group_name;
	struct SceNetAdhocctlBSSId bssid;
	int mode;
};

typedef void (*sceNetAdhocctlHandler)
	(int event,
	int error_code,
	void *arg
	);

/* GameMode information */
#define PSP_NET_ADHOCCTL_GAMETYPE_1A	1
#define PSP_NET_ADHOCCTL_GAMETYPE_1B	2
#define PSP_NET_ADHOCCTL_GAMETYPE_2A	3

#define PSP_NET_ADHOCCTL_GAMEMODE_MAX_MEMBERS	16
struct SceNetAdhocctlGameModeInfo {
	int num;
	struct SceNetEtherAddr member[PSP_NET_ADHOCCTL_GAMEMODE_MAX_MEMBERS];
};

/**
 * Initialise the Adhoc control library
 *
 * @param stacksize - Stack size of the adhocctl thread. Set to 0x2000
 * @param prio - Priority of the adhocctl thread. Set to 0x30
 * @param adhoc_id - Pass a filled in ::SceNetAdhocctlAdhocId
 *
 * @return 0 on success, < 0 on error
 */
int sceNetAdhocctlInit(SceSize stacksize,int prio, const struct SceNetAdhocctlAdhocId *adhoc_id);
/**
 * Terminate the Adhoc control library
 *
 * @return 0 on success, < on error.
 */
int sceNetAdhocctlTerm(void);
/**
 * Connect to the Adhoc control
 *
 * @param group_name - The name of the connection (maximum 8 alphanumeric characters).
 *
 * @return 0 on success, < 0 on error.
 */
int sceNetAdhocctlConnect(const struct SceNetAdhocctlGroupName *group_name);
/**
 * Connect to the Adhoc control (as a host)
 *
 * @param group_name - The name of the connection (maximum 8 alphanumeric characters).
 *
 * @return 0 on success, < 0 on error.
 */
int sceNetAdhocctlCreate(const struct SceNetAdhocctlGroupName *group_name);
/**
 * Connect to the Adhoc control (as a client)
 *
 * @param scan_info - A valid ::SceNetAdhocctlScanInfo struct that has been filled by sceNetAchocctlGetScanInfo
 *
 * @return 0 on success, < 0 on error.
 */
int sceNetAdhocctlJoin(const struct SceNetAdhocctlScanInfo *scan_info);
/**
 * Disconnect from the Adhoc control
 *
 * @return 0 on success, < 0 on error
 */
int sceNetAdhocctlDisconnect(void);
/**
 * Scan the adhoc channels
 *
 * @return 0 on success, < 0 on error.
 */
int sceNetAdhocctlScan(void);
/**
 * Register an adhoc event handler
 *
 * @param handler - The event handler.
 * @param arg - args to pass to handler callback
 *
 * @return Handler id on success, < 0 on error.
 */
int sceNetAdhocctlAddHandler(sceNetAdhocctlHandler handler,void *arg);
/**
 * Delete an adhoc event handler
 *
 * @param id - The handler id as returned by sceNetAdhocctlAddHandler.
 *
 * @return 0 on success, < 0 on error.
 */
int sceNetAdhocctlDelHandler(int id);
/**
 * Get the state of the Adhoc control
 *
 * @param state - Pointer to an integer to receive the status. Can continue when it becomes 1.
 *
 * @return 0 on success, < 0 on error
 */
int sceNetAdhocctlGetState(int *state);
/**
 * Get the adhoc ID
 *
 * @param adhoc_id - A pointer to a  ::productStruct
 *
 * @return 0 on success, < 0 on error.
 */
int sceNetAdhocctlGetAdhocId(struct SceNetAdhocctlAdhocId *adhoc_id);
/**
 * Get a list of peers
 *
 * @param buflen - The length of the list.
 * @param buf - An allocated area of size length.
 *
 * @return 0 on success, < 0 on error.
 */
int sceNetAdhocctlGetPeerList(int *buflen,void *buf);
/**
 * Get peer information
 *
 * @param addr - The mac address of the peer.
 * @param size - Size of peerinfo.
 * @param info - Pointer to store the information.
 *
 * @return 0 on success, < 0 on error.
 */
int sceNetAdhocctlGetPeerInfo(const struct SceNetEtherAddr *addr, int size, struct SceNetAdhocctlPeerInfo *info);
/**
 * Get mac address from nickname
 *
 * @param nickname - The nickname.
 * @param buflen - The length of the list.
 * @param buf - An allocated area of size length.
 *
 * @return 0 on success, < 0 on error.
 */
int sceNetAdhocctlGetAddrByName(const struct SceNetAdhocctlNickname *nickname,int *buflen,void *buf);
/**
 * Get nickname from a mac address
 *
 * @param addr - The mac address.
 * @param nickname - Pointer to a char buffer where the nickname will be stored.
 *
 * @return 0 on success, < 0 on error.
 */
int sceNetAdhocctlGetNameByAddr(const struct SceNetEtherAddr *addr,struct SceNetAdhocctlNickname *nickname);
/**
 * Get Adhocctl parameter
 *
 * @param parameter - Pointer to a ::SceNetAdhocctlParameter
 *
 * @return 0 on success, < 0 on error.
 */
int sceNetAdhocctlGetParameter(struct SceNetAdhocctlParameter *parameter);
/**
 * Scan the adhoc channels
 *
 * @return 0 on success, < 0 on error.
 */
int sceNetAdhocctlScan(void);
/**
 * Get the results of a scan
 *
 * @param buflen - The length of the list.
 * @param buf - An allocated area of size length.
 *
 * @return 0 on success, < 0 on error.
 */
int sceNetAdhocctlGetScanInfo(int *buflen,void *buf);
/**
 * Connect to the Adhoc control game mode (as a host)
 *
 * @param group_name - The name of the connection (maximum 8 alphanumeric characters).
 * @param game_type - Pass 1.
 * @param num - The total number of players (including the host).
 * @param members - A pointer to a list of the participating mac addresses, host first, then clients.
 * @param timeout - Timeout in microseconds.
 * @param flag - pass 0.
 *
 * @return 0 on success, < 0 on error.
 */
int sceNetAdhocctlCreateEnterGameMode(const struct SceNetAdhocctlGroupName *group_name,int game_type,int num,const struct SceNetEtherAddr *members,SceUInt timeout,int flag);
/**
 * Connect to the Adhoc control game mode (as a client)
 *
 * @param group_name - The name of the connection (maximum 8 alphanumeric characters).
 * @param gc - The mac address of the host.
 * @param timeout - Timeout in microseconds.
 * @param flag - pass 0.
 *
 * @return 0 on success, < 0 on error.
 */
int sceNetAdhocctlJoinEnterGameMode(const struct SceNetAdhocctlGroupName *group_name, const struct SceNetEtherAddr *gc, SceUInt timeout, int flag);
/**
 * Exit game mode.
 *
 * @return 0 on success, < 0 on error.
 */
int sceNetAdhocctlExitGameMode(void);
/**
 * Get game mode information
 *
 * @param info - Pointer to store the info.
 *
 * @return 0 on success, < 0 on error.
 */
int sceNetAdhocctlGetGameModeInfo(struct SceNetAdhocctlGameModeInfo *info);


#ifdef __cplusplus
}
#endif

#endif 
