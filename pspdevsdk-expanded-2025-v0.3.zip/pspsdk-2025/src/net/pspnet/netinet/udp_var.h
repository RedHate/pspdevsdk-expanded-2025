#ifndef __PSPNET_NETINET_UDP_VAR_H__
#define __PSPNET_NETINET_UDP_VAR_H__

#ifdef __cplusplus
extern "C" {
#endif

struct SceNetInetUdpstat {
					/* input statistics: */
	SceUInt64 udps_ipackets;		/* total input packets */
	SceUInt64 udps_hdrops;		/* packet shorter than header */
	SceUInt64 udps_badsum;		/* checksum error */
	SceUInt64 udps_badlen;		/* data length larger than packet */
	SceUInt64 udps_noport;		/* no socket on port */
	SceUInt64 udps_noportbcast;	/* of above, arrived as broadcast */
	SceUInt64 udps_fullsock;		/* not delivered, input socket full */
	SceUInt64 udps_pcbhashmiss;	/* input packets missing pcb hash */
					/* output statistics: */
	SceUInt64 udps_opackets;		/* total output packets */
};

struct SceNetInetUdpcbstat {
	struct SceNetInetUdpcbstat *next;
	unsigned int		us_so_snd_sb_cc;/* actual chars in send buffer */
	unsigned int		us_so_rcv_sb_cc;/* actual chars in recv buffer */
	struct SceNetInetInAddr	us_inp_laddr;	/* local address */
	struct SceNetInetInAddr	us_inp_faddr;	/* foreign address */
	SceUShort16	us_inp_lport;	/* local port */
	SceUShort16	us_inp_fport;	/* foreign port */
};

int sceNetInetGetUdpcbstat(int *unk, void *buf);
#ifdef __cplusplus
}
#endif

#endif 
