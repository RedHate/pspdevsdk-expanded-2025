#ifndef __PSPNET_NETINET_TCP_FSM_H__
#define __PSPNET_NETINET_TCP_FSM_H__

#ifdef __cplusplus
extern "C" {
#endif

/*
 * TCP FSM state definitions.
 * Per RFC793, September, 1981.
 */

#define	PSP_NET_INET_TCP_NSTATES			11

#define	PSP_NET_INET_TCPS_CLOSED			0	/* closed */
#define	PSP_NET_INET_TCPS_LISTEN			1	/* listening for connection */
#define	PSP_NET_INET_TCPS_SYN_SENT			2	/* active, have sent syn */
#define	PSP_NET_INET_TCPS_SYN_RECEIVED		3	/* have send and received syn */
/* states < TCPS_ESTABLISHED are those where connections not established */
#define	PSP_NET_INET_TCPS_ESTABLISHED		4	/* established */
#define	PSP_NET_INET_TCPS_CLOSE_WAIT		5	/* rcvd fin, waiting for close */
/* states > TCPS_CLOSE_WAIT are those where user has closed */
#define	PSP_NET_INET_TCPS_FIN_WAIT_1		6	/* have closed, sent fin */
#define	PSP_NET_INET_TCPS_CLOSING			7	/* closed xchd FIN; await ACK */
#define	PSP_NET_INET_TCPS_LAST_ACK			8	/* had fin and close; await FIN ACK */
/* states > TCPS_CLOSE_WAIT && < TCPS_FIN_WAIT_2 await ACK of FIN */
#define	PSP_NET_INET_TCPS_FIN_WAIT_2		9	/* have closed, fin is acked */
#define	PSP_NET_INET_TCPS_TIME_WAIT			10	/* in 2*msl quiet wait after close */
#ifdef __cplusplus
}
#endif

#endif 
