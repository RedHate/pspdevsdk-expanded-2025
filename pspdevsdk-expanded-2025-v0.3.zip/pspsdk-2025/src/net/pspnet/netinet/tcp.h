#ifndef __PSPNET_NETINET_TCP_H__
#define __PSPNET_NETINET_TCP_H__

#ifdef __cplusplus
extern "C" {
#endif

#define	PSP_NET_INET_TCP_NODELAY	0x01	/* don't delay send to coalesce packets */
#define	PSP_NET_INET_TCP_MAXSEG		0x02	/* set maximum segment size */

#ifdef __cplusplus
}
#endif

#endif 
