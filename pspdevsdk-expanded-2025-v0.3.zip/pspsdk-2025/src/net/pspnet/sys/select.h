#ifndef __PSPINET_SYS_SELECT_H__
#define __PSPINET_SYS_SELECT_H__

#ifdef __cplusplus
extern "C" {
#endif

#include <string.h>
#include <pspnet/sys/time.h>

#define PSP_NET_INET_FD_SETSIZE	256

typedef unsigned int SceNetInetFdMask;

#define PSP_NET_INET_NFDBITS		32		/* sizeof(SceNetInetFdMask) * 8 */
#define PSP_NET_INET_NFDBITS_SHIFT	5		/* 2^5 = 32 */
#define PSP_NET_INET_NFDBITS_MASK	0x1f	/* 5 bit mask */

typedef struct SceNetInetFdSet {
	SceNetInetFdMask		__fds_bits[8]; /*howmany(PSP_NET_INET_FD_SETSIZE, PSP_NET_INET_NFDBITS)*/
} SceNetInetFdSet;

#define SceNetInetFD_SET(n, p) ((p)->fds_bits[(n)>>PSP_NET_INET_NFDBITS_SHIFT] |=  (1 << ((n) & PSP_NET_INET_NFDBITS_MASK)))
#define SceNetInetFD_CLR(n, p) ((p)->fds_bits[(n)>>PSP_NET_INET_NFDBITS_SHIFT] &= ~(1 << ((n) & PSP_NET_INET_NFDBITS_MASK)))
#define SceNetInetFD_ISSET(n, p) ((p)->fds_bits[(n)>>PSP_NET_INET_NFDBITS_SHIFT] &   (1 << ((n) & PSP_NET_INET_NFDBITS_MASK)))
#define SceNetInetFD_ZERO(p) (void)memset((p), 0, sizeof(*(p)))

int	sceNetInetSelect(int nfds, SceNetInetFdSet *readfds, SceNetInetFdSet *writefds, SceNetInetFdSet *exceptfds, struct SceNetInetTimeval *timeout);

#ifdef __cplusplus
}
#endif

#endif 
