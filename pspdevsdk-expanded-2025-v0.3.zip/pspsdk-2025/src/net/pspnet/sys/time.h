#ifndef __PSPINET_SYS_TIME_H__
#define __PSPINET_SYS_TIME_H__

#ifdef __cplusplus
extern "C" {
#endif

struct SceNetInetTimeval {
	unsigned int    tv_sec;         /* seconds */
	unsigned int    tv_usec;        /* and microseconds */
};
#ifdef __cplusplus
}
#endif

#endif 
