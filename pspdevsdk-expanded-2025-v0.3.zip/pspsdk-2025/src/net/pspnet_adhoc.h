#ifndef __PSPNET_IN_H__
#define __PSPNET_IN_H__

#ifdef __cplusplus
extern "C" {
#endif
#include <pspnet.h>

/* socket descriptor for sceNetAdhocPoll() */
struct SceNetAdhocPollSd {
	int id;
	int events;
	int revents;
}SceNetAdhocPollSd;

#define PSP_NET_ADHOC_EV_SEND		0x0001
#define PSP_NET_ADHOC_EV_RECV		0x0002
#define PSP_NET_ADHOC_EV_CONNECT	0x0004
#define PSP_NET_ADHOC_EV_ACCEPT		0x0008
#define PSP_NET_ADHOC_EV_FLUSH		0x0010
#define PSP_NET_ADHOC_EV_INVALID	0x0100
#define PSP_NET_ADHOC_EV_DELETE		0x0200
#define PSP_NET_ADHOC_EV_ALERT		0x0400
#define PSP_NET_ADHOC_EV_DISCONNECT	0x0800

/* PDP statistics */
struct SceNetAdhocPdpStat {
	struct SceNetAdhocPdpStat *next;
	int id;
	struct SceNetEtherAddr laddr;
	SceUShort16 lport;
	unsigned int rcv_sb_cc;
};

/* PTP statistics */
#define PSP_NET_ADHOC_PTP_STATE_CLOSED		0
#define PSP_NET_ADHOC_PTP_STATE_LISTEN		1
#define PSP_NET_ADHOC_PTP_STATE_SYN_SENT	2
#define PSP_NET_ADHOC_PTP_STATE_SYN_RCVD	3
#define PSP_NET_ADHOC_PTP_STATE_ESTABLISHED	4

struct SceNetAdhocPtpStat {
	struct SceNetAdhocPtpStat *next;
	int id;
	struct SceNetEtherAddr laddr;
	struct SceNetEtherAddr paddr;
	SceUShort16 lport;
	SceUShort16 pport;
	unsigned int snd_sb_cc;
	unsigned int rcv_sb_cc;
	int state;
};

/* flags for adhoc socket API */
#define PSP_NET_ADHOC_F_NONBLOCK		0x0001
#define PSP_NET_ADHOC_F_ALERTSEND		0x0010
#define PSP_NET_ADHOC_F_ALERTRECV		0x0020
#define PSP_NET_ADHOC_F_ALERTPOLL		0x0040
#define PSP_NET_ADHOC_F_ALERTCONNECT	0x0080
#define PSP_NET_ADHOC_F_ALERTACCEPT		0x0100
#define PSP_NET_ADHOC_F_ALERTFLUSH		0x0200
#define PSP_NET_ADHOC_F_ALERTALL \
	(PSP_NET_ADHOC_F_ALERTSEND \
		|PSP_NET_ADHOC_F_ALERTRECV \
		|PSP_NET_ADHOC_F_ALERTPOLL \
		|PSP_NET_ADHOC_F_ALERTCONNECT \
		|PSP_NET_ADHOC_F_ALERTACCEPT \
		|PSP_NET_ADHOC_F_ALERTFLUSH \
	)

/* PDP Maximum Fragment Size */
#define PSP_NET_ADHOC_PDP_MFS		1444

/* PDP Maximum Transfer Unit */
#define PSP_NET_ADHOC_PDP_MTU		65523

/* PTP Maximum Segment Size */
#define PSP_NET_ADHOC_PTP_MSS		1444

/* GameMode Optional Data */
#define PSP_NET_ADHOC_GAMEMODE_F_UPDATE	0x00000001

struct SceNetAdhocGameModeOptData {
	SceSize size;
	SceUInt32 flag;
};
/** 
 * Initialise the adhoc library.
 *
 * @return 0 on success, < 0 on error
 */
int sceNetAdhocInit( void );
/**
 * Terminate the adhoc library
 *
 * @return 0 on success, < 0 on error
 */
int sceNetAdhocTerm( void );
/**
 * Poll a socket
 *
 * @param sds  - Socket descriptor
 * @param nsds - Number of socket descriptors
 * @param timeout - Timeout in microseconds.
 * @param flag - Set to 0 to block, 1 for non-blocking.
 *
 * @return //havent tested, find out for yourself
 */
int sceNetAdhocPollSocket( struct SceNetAdhocPollSd *sds, int nsds, unsigned int timeout, int flag );
/**
 * Set socket alert
 *
 * @param id - The ID returned from ::sceNetAdhocPdpCreate
 * @param flag - Set to 0 to block, 1 for non-blocking.
 *
 * @return //havent tested, find out for yourself
 */
int sceNetAdhocSetSocketAlert( int id, int flag );
/**
 * Get socket alert
 *
 * @param id - The ID returned from ::sceNetAdhocPdpCreate
 * @param flag - Set to 0 to block, 1 for non-blocking.
 *
 * @return //havent tested, find out for yourself
 */
int sceNetAdhocGetSocketAlert( int id, int *flag );
/**
 * Create a PDP object.
 *
 * @param saddr - Your MAC address (from sceWlanGetEtherAddr)
 * @param sport - Port to use, lumines uses 0x309
 * @param bufsize - Socket buffer size, lumines sets to 0x400
 * @param flag - Set to 0 to block, 1 for non-blocking.
 *
 * @return The ID of the PDP object (< 0 on error)
 */
int sceNetAdhocPdpCreate( const struct SceNetEtherAddr *saddr, SceUShort16 sport, unsigned int bufsize, int flag );
/**
 * Set a PDP packet to a destination
 *
 * @param id - The ID as returned by ::sceNetAdhocPdpCreate
 * @param daddr - The destination MAC address, can be set to all 0xFF for broadcast
 * @param dport - The port to send to
 * @param data - The data to send
 * @param len - The length of the data.
 * @param timeout - Timeout in microseconds.
 * @param flag - Set to 0 to block, 1 for non-blocking.
 *
 * @return Bytes sent, < 0 on error
 */
int sceNetAdhocPdpSend( int id, const struct SceNetEtherAddr *daddr, SceUShort16 dport, const void *data, int len, unsigned int timeout, int flag );
/**
 * Receive a PDP packet
 *
 * @param id - The ID of the PDP object, as returned by ::sceNetAdhocPdpCreate
 * @param saddr - Buffer to hold the source mac address of the sender
 * @param sport - Buffer to hold the port number of he received data
 * @param buf - Data buffer
 * @param len - The length of the data buffer
 * @param timeout - Timeout in microseconds.
 * @param flag - Set to 0 to block, 1 for non-blocking.
 *
 * @return Number of bytes received, < 0 on error.
 */
int sceNetAdhocPdpRecv( int id, struct SceNetEtherAddr *saddr, SceUShort16 *sport, void *buf, int *len, unsigned int timeout, int flag );
/**
 * Delete a PDP object.
 *
 * @param id - The ID returned from ::sceNetAdhocPdpCreate
 * @param flag - Set to 0 to block, 1 for non-blocking.
 *
 * @return 0 on success, < 0 on error
 */
int sceNetAdhocPdpDelete( int id, int flag );
/**
 * Get the status of all PDP objects
 *
 * @param buflen - Pointer to the size of the stat array (e.g 20 for one structure)
 * @param buf - Pointer to a list of ::pdpStatStruct structures.
 *
 * @return 0 on success, < 0 on error
 */
int sceNetAdhocGetPdpStat( int *buflen, void *buf );
/**
 * Open a PTP connection
 *
 * @param saddr - Local mac address.
 * @param sport - Local port.
 * @param daddr - Destination mac.
 * @param dport - Destination port
 * @param bufsize - Socket buffer size
 * @param rexmt_int - Interval between retrying (microseconds).
 * @param rexmt_cnt - Number of retries.
 * @param flag - Set to 0 to block, 1 for non-blocking.
 *
 * @return A socket ID on success, < 0 on error.
 */
int sceNetAdhocPtpOpen( const struct SceNetEtherAddr *saddr, SceUShort16 sport, const struct SceNetEtherAddr *daddr, SceUShort16 dport, unsigned int bufsize, unsigned int rexmt_int, int rexmt_cnt, int flag );
/**
 * Wait for connection created by sceNetAdhocPtpOpen()
 *
 * @param id - A socket ID.
 * @param timeout - Timeout in microseconds.
 * @param flag - Set to 0 to block, 1 for non-blocking.
 *
 * @return 0 on success, < 0 on error.
 */
int sceNetAdhocPtpConnect( int id, unsigned int timeout, int flag );
/**
 * Wait for an incoming PTP connection
 *
 * @param saddr - Local mac address.
 * @param sport - Local port.
 * @param bufsize - Socket buffer size
 * @param rexmt_int - Interval between retrying (microseconds).
 * @param rexmt_cnt - Number of retries.
 * @param backlog - Connection queue length.
 * @param flag - Set to 0 to block, 1 for non-blocking.
 *
 * @return A socket ID on success, < 0 on error.
 */
int sceNetAdhocPtpListen( const struct SceNetEtherAddr *saddr, SceUShort16 sport, unsigned int bufsize, unsigned int rexmt_int, int rexmt_cnt, int backlog, int flag );
/**
 * Accept an incoming PTP connection
 *
 * @param id - A socket ID.
 * @param addr - Connecting peers mac.
 * @param port - Connecting peers port.
 * @param timeout - Timeout in microseconds.
 * @param flag - Set to 0 to block, 1 for non-blocking.
 *
 * @return 0 on success, < 0 on error.
 */
int sceNetAdhocPtpAccept( int id, struct SceNetEtherAddr *addr, SceUShort16 *port, unsigned int timeout, int flag );
/**
 * Send data
 *
 * @param id - A socket ID.
 * @param data - Data to send.
 * @param datasize - Size of the data.
 * @param timeout - Timeout in microseconds.
 * @param flag - Set to 0 to block, 1 for non-blocking.
 *
 * @return 0 success, < 0 on error.
 */
int sceNetAdhocPtpSend( int id, const void *data, int *len, unsigned int timeout, int flag );
/**
 * Receive data
 *
 * @param id - A socket ID.
 * @param buf - Buffer for the received data.
 * @param len - Size of the data received.
 * @param timeout - Timeout in microseconds.
 * @param flag - Set to 0 to block, 1 for non-blocking.
 *
 * @return 0 on success, < 0 on error.
 */
int sceNetAdhocPtpRecv( int id, void *buf, int *len, unsigned int timeout, int flag );
/**
 * Wait for data in the buffer to be sent
 *
 * @param id - A socket ID.
 * @param timeout - Timeout in microseconds.
 * @param flag - Set to 0 to block, 1 for non-blocking.
 *
 * @return A socket ID on success, < 0 on error.
 */
int sceNetAdhocPtpFlush( int id, unsigned int timeout, int flag );
/**
 * Close a socket
 *
 * @param id - A socket ID.
 * @param flag - Set to 0 to block, 1 for non-blocking.
 *
 * @return A socket ID on success, < 0 on error.
 */
int sceNetAdhocPtpClose( int id, int flag) ;
/**
 * Get the status of all PTP objects
 *
 * @param buflen - Pointer to the size of the stat array (e.g 20 for one structure)
 * @param buf - Pointer to a list of ::ptpStatStruct structures.
 *
 * @return 0 on success, < 0 on error
 */
int sceNetAdhocGetPtpStat( int *buflen, void *buf );
/**
 * Create own game object type data.
 *
 * @param ptr - A pointer to the game object data.
 * @param size - Size of the game data.
 *
 * @return 0 on success, < 0 on error.
 */
int sceNetAdhocGameModeCreateMaster( const void *ptr, SceSize size );
/**
 * Create peer game object type data.
 *
 * @param src - The mac address of the peer.
 * @param ptr - A pointer to the game object data.
 * @param size - Size of the game data.
 *
 * @return The id of the replica on success, < 0 on error.
 */
int sceNetAdhocGameModeCreateReplica( const struct SceNetEtherAddr *src, void *ptr, SceSize size );
/**
 * Update own game object type data.
 *
 * @return 0 on success, < 0 on error.
 */
int sceNetAdhocGameModeUpdateMaster( void );
/**
 * Update peer game object type data.
 *
 * @param id - The id of the replica returned by sceNetAdhocGameModeCreateReplica.
 * @param optdata - Pass 0.
 *
 * @return 0 on success, < 0 on error.
 */
int sceNetAdhocGameModeUpdateReplica( int id, struct SceNetAdhocGameModeOptData *optdata );
/**
 * Delete own game object type data.
 *
 * @return 0 on success, < 0 on error.
 */
int sceNetAdhocGameModeDeleteMaster( void );
/**
 * Delete peer game object type data.
 *
 * @param id - The id of the replica.
 *
 * @return 0 on success, < 0 on error.
 */
int sceNetAdhocGameModeDeleteReplica( int id );

#ifdef __cplusplus
}
#endif

#endif 
