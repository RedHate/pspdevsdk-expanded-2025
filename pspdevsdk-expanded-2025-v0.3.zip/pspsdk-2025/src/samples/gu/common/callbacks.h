#ifndef common_callbacks_h
#define common_callbacks_h

#ifdef __cplusplus
extern "C" {
#endif

int running();
int setupCallbacks(void);

#ifdef __cplusplus
}
#endif

#endif
