/*
 * PSP Software Development Kit - https://github.com/pspdev
 * -----------------------------------------------------------------------
 * Licensed under the BSD license, see LICENSE in PSPSDK root for details.
 *
 * main.c - Sample to demonstrate proper use of the systemparam functions
 *
 * Copyright (c) 2005 John Kelley <ps2dev@kelley.ca>
 *
 */
#include <pspkernel.h>
#include <pspdebug.h>
#include <pspdisplay.h>
#include <stdio.h>
#include <string.h>
#include <pspmoduleinfo.h>
#include <psputility.h>
#include <psputility_netparam.h>
#include <pspctrl.h>

/* Define the module info section */
PSP_MODULE_INFO("NetParam Sample", 0, 1, 00);

//Just to leave room for expansion
#define NUM_NETPARAMS 17

/* Define printf, just to make typing easier */
#define printf  pspDebugScreenPrintf

/* Exit callback */
int exit_callback(int arg1, int arg2, void *common)
{
    sceKernelExitGame();
	return 0;
}

/* Callback thread */
int CallbackThread(SceSize args, void *argp)
{
    int cbid = sceKernelCreateCallback("Exit Callback", exit_callback, NULL);
    sceKernelRegisterExitCallback(cbid);
    sceKernelSleepThreadCB();

	return 0;
}

/* Sets up the callback thread and returns its thread id */
int SetupCallbacks(void)
{
    int thid = sceKernelCreateThread("update_thread", CallbackThread, 0x11, 0xFA0, 0, 0);
    if (thid >= 0)
	sceKernelStartThread(thid, 0, 0);
    return thid;
}

/* main routine */
int main(int argc, char *argv[])
{

    int netConfIndex = 1;
    int numNetConfigs = 1;
    union SceUtilityNetParamEntry data;
    SceCtrlData pad;
    u32 oldButtons;
    
    //init screen and callbacks
    pspDebugScreenInit();
    pspDebugScreenClear();
    
    SetupCallbacks();
    
    // Setup Pad
    sceCtrlSetSamplingCycle(0);
    sceCtrlSetSamplingMode(0);
    sceCtrlReadBufferPositive(&pad, 1);
    oldButtons = pad.Buttons;
    
    // Determine # of net configs
    while (sceUtilityCheckNetParam(numNetConfigs) == 0) {
    	numNetConfigs++;
    }
    numNetConfigs--;
    
    for (;;) {
		
    	pspDebugScreenSetXY(0, 0);
    	printf("NetParam Sample v1.0 by John_K\n\n");
    	
/*
		union SceUtilityNetParamEntry {
			SceChar8 cnf_name[64]; 				//#define SCE_UTILITY_NET_PARAM_CODE_CNF_NAME           0 // string
			SceChar8 ssid[32 + 1]; 				//#define SCE_UTILITY_NET_PARAM_CODE_SSID               1 // string
			SceUInt32 auth_proto;				//#define SCE_UTILITY_NET_PARAM_CODE_AUTH_PROTO         2 // int
			SceChar8 wep_key[13];				//#define SCE_UTILITY_NET_PARAM_CODE_WEP_KEY            3 // string
			SceUInt32 how_to_set_ip;			//#define SCE_UTILITY_NET_PARAM_CODE_HOW_TO_SET_IP      4 // int
			SceChar8 ip_address[16];			//#define SCE_UTILITY_NET_PARAM_CODE_IP_ADDRESS         5 // string
			SceChar8 netmask[16];				//#define SCE_UTILITY_NET_PARAM_CODE_NETMASK            6 // string
			SceChar8 default_route[16];			//#define SCE_UTILITY_NET_PARAM_CODE_DEFAULT_ROUTE      7 // string
			SceUInt32 dns_flag;					//#define SCE_UTILITY_NET_PARAM_CODE_DNS_FLAG           8 // int
			SceChar8 primary_dns[16];			//#define SCE_UTILITY_NET_PARAM_CODE_PRIMARY_DNS        9 // string
			SceChar8 secondary_dns[16];			//#define SCE_UTILITY_NET_PARAM_CODE_SECONDARY_DNS     10 // string
			SceChar8 auth_name[128];			//#define SCE_UTILITY_NET_PARAM_CODE_AUTH_NAME         11 // string
			SceChar8 auth_key[128];				//#define SCE_UTILITY_NET_PARAM_CODE_AUTH_KEY   	   12 // string
			SceUInt32 http_proxy_flag;			//#define SCE_UTILITY_NET_PARAM_CODE_HTTP_PROXY_FLAG   13 // int
			SceChar8 http_proxy_server[128];	//#define SCE_UTILITY_NET_PARAM_CODE_HTTP_PROXY_SERVER 14 // string
			SceUInt32 http_proxy_port;			//#define SCE_UTILITY_NET_PARAM_CODE_HTTP_PROXY_PORT   15 // int
												//#define PSP_NETPARAM_UNKNOWN1     16 // int
												//#define PSP_NETPARAM_UNKNOWN2     17 // int
		};
*/
    	
    	printf("Net Configuration #%d:\n", netConfIndex);
 
		printf("param %03d: ret(0x%08X) string(%s)\n",      SCE_UTILITY_NET_PARAM_CODE_CNF_NAME, 			sceUtilityGetNetParam(netConfIndex, SCE_UTILITY_NET_PARAM_CODE_CNF_NAME, &data), 			data.cnf_name);
		printf("param %03d: ret(0x%08X) string(%s)\n",      SCE_UTILITY_NET_PARAM_CODE_SSID, 				sceUtilityGetNetParam(netConfIndex, SCE_UTILITY_NET_PARAM_CODE_SSID, &data), 				data.ssid);
		printf("param %03d: ret(0x%08X) long int(%08lX)\n", SCE_UTILITY_NET_PARAM_CODE_AUTH_PROTO, 			sceUtilityGetNetParam(netConfIndex, SCE_UTILITY_NET_PARAM_CODE_AUTH_PROTO, &data), 			data.auth_proto);
		printf("param %03d: ret(0x%08X) string(%s)\n",      SCE_UTILITY_NET_PARAM_CODE_WEP_KEY, 			sceUtilityGetNetParam(netConfIndex, SCE_UTILITY_NET_PARAM_CODE_WEP_KEY, &data), 			data.wep_key);
		printf("param %03d: ret(0x%08X) long int(%08lX)\n", SCE_UTILITY_NET_PARAM_CODE_HOW_TO_SET_IP, 		sceUtilityGetNetParam(netConfIndex, SCE_UTILITY_NET_PARAM_CODE_HOW_TO_SET_IP, &data), 		data.how_to_set_ip);
		printf("param %03d: ret(0x%08X) string(%s)\n",      SCE_UTILITY_NET_PARAM_CODE_IP_ADDRESS, 			sceUtilityGetNetParam(netConfIndex, SCE_UTILITY_NET_PARAM_CODE_IP_ADDRESS, &data), 			data.ip_address);
		printf("param %03d: ret(0x%08X) string(%s)\n",      SCE_UTILITY_NET_PARAM_CODE_NETMASK,	 			sceUtilityGetNetParam(netConfIndex, SCE_UTILITY_NET_PARAM_CODE_NETMASK, &data), 			data.netmask);
		printf("param %03d: ret(0x%08X) string(%s)\n",      SCE_UTILITY_NET_PARAM_CODE_DEFAULT_ROUTE, 		sceUtilityGetNetParam(netConfIndex, SCE_UTILITY_NET_PARAM_CODE_DEFAULT_ROUTE, &data), 		data.default_route);
		printf("param %03d: ret(0x%08X) long int(%08lX)\n", SCE_UTILITY_NET_PARAM_CODE_DNS_FLAG, 			sceUtilityGetNetParam(netConfIndex, SCE_UTILITY_NET_PARAM_CODE_DNS_FLAG, &data), 			data.dns_flag);
		printf("param %03d: ret(0x%08X) string(%s)\n",      SCE_UTILITY_NET_PARAM_CODE_PRIMARY_DNS, 		sceUtilityGetNetParam(netConfIndex, SCE_UTILITY_NET_PARAM_CODE_PRIMARY_DNS, &data), 		data.primary_dns);
		printf("param %03d: ret(0x%08X) string(%s)\n",      SCE_UTILITY_NET_PARAM_CODE_SECONDARY_DNS, 		sceUtilityGetNetParam(netConfIndex, SCE_UTILITY_NET_PARAM_CODE_SECONDARY_DNS, &data), 		data.secondary_dns);
		printf("param %03d: ret(0x%08X) string(%s)\n",      SCE_UTILITY_NET_PARAM_CODE_AUTH_NAME, 			sceUtilityGetNetParam(netConfIndex, SCE_UTILITY_NET_PARAM_CODE_AUTH_NAME, &data), 			data.auth_name);
		printf("param %03d: ret(0x%08X) string(%s)\n",      SCE_UTILITY_NET_PARAM_CODE_AUTH_KEY, 			sceUtilityGetNetParam(netConfIndex, SCE_UTILITY_NET_PARAM_CODE_AUTH_KEY, &data), 			data.auth_key);
		printf("param %03d: ret(0x%08X) long int(%08lX)\n", SCE_UTILITY_NET_PARAM_CODE_HTTP_PROXY_FLAG, 	sceUtilityGetNetParam(netConfIndex, SCE_UTILITY_NET_PARAM_CODE_HTTP_PROXY_FLAG, &data), 	data.http_proxy_flag);
		printf("param %03d: ret(0x%08X) string(%s)\n",      SCE_UTILITY_NET_PARAM_CODE_HTTP_PROXY_SERVER, 	sceUtilityGetNetParam(netConfIndex, SCE_UTILITY_NET_PARAM_CODE_HTTP_PROXY_SERVER, &data), 	data.http_proxy_server);
		printf("param %03d: ret(0x%08X) long int(%08lX)\n", SCE_UTILITY_NET_PARAM_CODE_HTTP_PROXY_PORT, 	sceUtilityGetNetParam(netConfIndex, SCE_UTILITY_NET_PARAM_CODE_HTTP_PROXY_PORT, &data), 	data.http_proxy_port);


    	printf("\nPress X to show details for next net configuration.\n");
    	sceDisplayWaitVblankStart();
		while (oldButtons == pad.Buttons) {
			sceCtrlReadBufferPositive(&pad, 1);
			if(pad.Buttons & PSP_CTRL_SELECT) {
				sceKernelExitGame();
			}
		}
	
		if (pad.Buttons & PSP_CTRL_RIGHT || pad.Buttons & PSP_CTRL_DOWN) {
			netConfIndex--;
			if(netConfIndex < 0)
			{
				netConfIndex = numNetConfigs;
			}
		}
		if (pad.Buttons & PSP_CTRL_RIGHT || pad.Buttons & PSP_CTRL_DOWN) {
			netConfIndex++;
			if(netConfIndex > numNetConfigs)
			{	
				netConfIndex = 1;
			}
		}
		
		oldButtons = pad.Buttons;
	}

    sceKernelSleepThread();
    sceKernelExitGame();

    return 0;
}

