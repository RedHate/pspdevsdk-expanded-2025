/*
 * PSP Software Development Kit - https://github.com/pspdev
 * -----------------------------------------------------------------------
 * Licensed under the BSD license, see LICENSE in PSPSDK root fordetails.
 *
 * main.c - Simple elf based network example.
 * 
 * Now 100% PSP API
 *
 * Copyright (c) 2005 James F <tyranid@gmail.com>
 * Copyright (c) 2025 Ultros (redhate) <redhate@ymail.com>
 *
 */

#include <errno.h>
#include <pspkernel.h>

#include <pspsdk.h>
#include <psputility.h>
#include <string.h>
#include <unistd.h>

#include <pspctrl.h>

#include <pspnet.h>
#include <pspnet_inet.h>
#include <pspnet_apctl.h>
#include <pspnet_resolver.h>
#include <pspnet/sys/socket.h>

#include <psphttp.h>
#include <pspssl.h>

#define printf pspDebugScreenPrintf

#define HELLO_MSG   "Hello there. Type away.\n"
#define MODULE_NAME " NetSample"
#define SERVER_PORT 23

#define APCTL_ERROR_NO_AP 0x80410180

PSP_MODULE_INFO(MODULE_NAME, 0, 1, 1);
PSP_MAIN_THREAD_ATTR(THREAD_ATTR_USER | THREAD_ATTR_VFPU);
//PSP_HEAP_SIZE_KB(1024*1024);
PSP_HEAP_THRESHOLD_SIZE_KB(0x8000);

/* Exit callback */
int exit_callback(int arg1, int arg2, void *common)
{
	sceKernelExitGame();
	return 0;
}

/* Callback thread */
int callback_thread(SceSize args, void *argp)
{
	int cbid = sceKernelCreateCallback("Exit Callback", exit_callback, NULL);
	sceKernelRegisterExitCallback(cbid);
	sceKernelSleepThreadCB();
	return 0;
}

/* Sets up the callback thread and returns its thread id */
int setup_callbacks(void)
{
	int thid = sceKernelCreateThread("update_thread", callback_thread, 0x11, 0xFA0, PSP_THREAD_ATTR_USER, 0);
	if(thid >= 0) sceKernelStartThread(thid, 0, 0);
	return thid;
}

/* Start a simple tcp echo server */
void start_server(const char *ip_address, uint16_t port)
{
	int new = -1;
	
	struct SceNetInetSockaddrIn local, client;
	SceNetInetSocklen_t size;

	int sock = sceNetInetSocket(PSP_NET_INET_AF_INET, PSP_NET_INET_SOCK_STREAM, 0);
	if(sock < 0)
	{
		printf(MODULE_NAME ": Error creating server socket %d\n", sock);
		CheckKernelError(sock);
		return;
	}

	printf(MODULE_NAME ": Socket created: %d\n", sock);

	local.sin_family      = PSP_NET_INET_AF_INET;
	local.sin_port 		  = sceNetHtons(port);
	local.sin_addr.s_addr = PSP_NET_INET_INADDR_ANY;
	
	int r;
	
	r = sceNetInetBind(sock, &local, sizeof(local));
	if(r != 0)
	{
		printf(MODULE_NAME ": Error binding socket %d\n", sock);
		CheckKernelError(r);
		return;
	}

	printf(MODULE_NAME ": Socket bind socket %d to port %d\n", sock, SERVER_PORT);
	
	r = sceNetInetListen(sock, 1);
	if(r != 0)
	{
		printf(MODULE_NAME ": Error calling listen\n");
		CheckKernelError(r);
		return;
	}

	printf(MODULE_NAME ": Listening for connections port %d\n", SERVER_PORT);

	SceNetInetFdSet set;
	SceNetInetFdSet setsave;

	SceNetInetFD_ZERO(&set);
	SceNetInetFD_SET(sock, &set);
	setsave = set;

	static char t_name[1024];
	static struct SceNetInetInAddr t_addr;
	
	while(1)
	{
		set = setsave;
		
		struct SceNetInetTimeval timeout;
		timeout.tv_sec  = 0;
		timeout.tv_usec = 50;
		
		r = sceNetInetSelect(PSP_NET_INET_FD_SETSIZE, &set, NULL, NULL, &timeout);
		if(r < 0)
		{
			printf(MODULE_NAME ": Select error\n");
			CheckKernelError(r);
			return;
		}
		
		int i;
		for(i=0; i<PSP_NET_INET_FD_SETSIZE; i++)
		{
			if(SceNetInetFD_ISSET(i, &set))
			{
				char data[1024];
				int val = i;
				if(val == sock)
				{
					
					new = sceNetInetAccept(sock, &client, &size);
					if(new < 0)
					{
						printf(MODULE_NAME ": Error inet accept %s\n", strerror(errno));
						sceNetInetShutdown(sock, PSP_NET_INET_SHUT_RDWR);
						CheckKernelError(r);
						return;
					}
					
				/*
					//sceNetInetInetNtoa() seems to be broken.. or misconfigured so we use the resolver instead
					printf( MODULE_NAME ": New connection port: %d from %s %d\n", 
							val, //fine
							sceNetInetInetNtoa(client), //not effing working!
							sceNetNtohs(client.sin_port) //works
						  );
				*/
					
					int rid = -1;
					char rbuf[1024];
					
					/* Create a resolver */
					r = sceNetResolverCreate(&rid, rbuf, sizeof(rbuf));
					if(r != 0)
					{
						printf(MODULE_NAME ": Error creating resolver\n");
						CheckKernelError(r);
					}
					
					// printf(MODULE_NAME ": Created resolver with id %d\n", rid);

					/* Resolve the network address to a name */
					r = sceNetResolverStartAtoN(rid, &client.sin_addr, t_name, sizeof(t_name), 2, 3);
					if(r != 0)
					{
						printf(MODULE_NAME ": Error resolving address to name\n");
						CheckKernelError(r);
					}

					// printf(MODULE_NAME ": Resolved %08X to %s\n", *(unsigned int*)&addr, name);

					/* Resolve a name to an network address for demonstration purposes */
					r = sceNetResolverStartNtoA(rid, t_name, &t_addr, 2, 3);
					if(r != 0)
					{
						printf(MODULE_NAME ": Error resolving name to address\n");
						CheckKernelError(r);
					}
					
					// printf(MODULE_NAME ": Resolved %s to %08X\n", name, *(unsigned int*)&addr);
					
					/* Delete the resolver */
					r = sceNetResolverDelete(rid);
					if((rid >= 0) && (r != 0))
					{
						printf(MODULE_NAME ": Error deleting resolver\n");
						CheckKernelError(r);
					}
					
					// printf(MODULE_NAME ": Deleting resolver with id %d\n", rid);
					
					/* Resolve the ip address of client */
					static char ip_addr[PSP_NET_INET_INET_ADDRSTRLEN+1];
					if(sceNetInetInetNtop(PSP_NET_INET_AF_INET,  &client.sin_addr, ip_addr, PSP_NET_INET_INET_ADDRSTRLEN) == NULL)
					{
						strcpy(ip_addr, "Invalid");
					}
					
					// pspDebugScreenClear();
					printf(MODULE_NAME ": %s (%s) on socket %d addr_in %08X\n", t_name, ip_addr, val, *(unsigned int*)&t_addr);  
					
					// set welcome message
					r = sceNetInetSend(new, HELLO_MSG, strlen(HELLO_MSG), PSP_NET_INET_SO_KEEPALIVE);
					if(r < 0)
					{
						printf(MODULE_NAME ": Error sending welcome message to socket\n");
						CheckKernelError(r);
					}
					
					// set fd
					SceNetInetFD_SET(new, &setsave);
				}
				else
				{
					int readbytes = sceNetInetRecv(val, data, sizeof(data), PSP_NET_INET_SO_KEEPALIVE);
					if(readbytes <= 0)
					{
						printf(MODULE_NAME ": Socket %d closed\n", val);
						SceNetInetFD_CLR(val, &setsave);
						sceNetInetShutdown(val, PSP_NET_INET_SHUT_RDWR);
					}
					else
					{
						printf(" %s: %.*s",t_name, readbytes, data);
						r = sceNetInetSend(val, data, readbytes, PSP_NET_INET_SO_KEEPALIVE);
						if(r < 0)
						{
							printf(MODULE_NAME ": Error sending message to socket\n");
							CheckKernelError(r);
						}
					}
				}
			}
		}
	}

	sceNetInetShutdown(sock, PSP_NET_INET_SHUT_RDWR);
}

void mac_info(){
	
	//print the ethernet address
	printf(MODULE_NAME ": Ethernet Address ");
	struct SceNetEtherAddr addr; 

	int r = sceNetGetLocalEtherAddr(&addr);
	if(r != 0){
		printf(MODULE_NAME ": Failed \n");
		CheckKernelError(r);
	}
	else{
		int i;
		for(i=0;i<PSP_NET_ETHER_ADDR_LEN;i++)
		{
			printf("%02X", addr.data[i]);
			if(i < PSP_NET_ETHER_ADDR_LEN-1) printf(":");
		}
	}
	printf("\n");

}

void apctl_info(){
	
	union SceNetApctlInfo info;
	
	if(sceNetApctlGetInfo(PSP_NET_APCTL_INFO_CNF_NAME, &info) == 0)
		printf(MODULE_NAME ": AP cnf_name      %s\n", info.cnf_name);

	if(sceNetApctlGetInfo(PSP_NET_APCTL_INFO_BSSID, &info) == 0)
		printf(MODULE_NAME ": AP bssid         %s\n", info.bssid);

	if(sceNetApctlGetInfo(PSP_NET_APCTL_INFO_SSID, &info) == 0)
		printf(MODULE_NAME ": AP ssid          %s\n", info.ssid);

	if(sceNetApctlGetInfo(PSP_NET_APCTL_INFO_SSID_LEN, &info) == 0)
		printf(MODULE_NAME ": AP ssidlen       %d\n", info.ssidlen);

	if(sceNetApctlGetInfo(PSP_NET_APCTL_INFO_AUTH_PROTO, &info) == 0)
	{
		printf(MODULE_NAME ": AP auth_proto    ");
		printf((!info.auth_proto)? "PSP_NET_APCTL_INFO_AUTH_PROTO_NOAUTH\n" : "PSP_NET_APCTL_INFO_AUTH_PROTO_WEP\n");
	}
	
	if(sceNetApctlGetInfo(PSP_NET_APCTL_INFO_RSSI, &info) == 0)
		printf(MODULE_NAME ": AP rssi          %d\n", info.rssi);

	if(sceNetApctlGetInfo(PSP_NET_APCTL_INFO_CHANNEL, &info) == 0)
		printf(MODULE_NAME ": AP channel       %d\n", info.channel);

	if(sceNetApctlGetInfo(PSP_NET_APCTL_INFO_PWRSAVE, &info) == 0)
		printf(MODULE_NAME ": AP pwrsave       %d\n", info.pwrsave);

	if(sceNetApctlGetInfo(PSP_NET_APCTL_INFO_IP_ADDRESS, &info) == 0)
		printf(MODULE_NAME ": AP ip_address    %s\n", info.ip_address);
		
	if(sceNetApctlGetInfo(PSP_NET_APCTL_INFO_NETMASK, &info) == 0)
		printf(MODULE_NAME ": AP netmask       %s\n", info.netmask);

	if(sceNetApctlGetInfo(PSP_NET_APCTL_INFO_DEFAULT_ROUTE, &info) == 0)
		printf(MODULE_NAME ": AP default_route %s\n", info.default_route);

	if(sceNetApctlGetInfo(PSP_NET_APCTL_INFO_PRIMARY_DNS, &info) == 0)
		printf(MODULE_NAME ": AP primary_dns   %s\n", info.primary_dns);

	if(sceNetApctlGetInfo(PSP_NET_APCTL_INFO_SECONDARY_DNS, &info) == 0)
		printf(MODULE_NAME ": AP secondary_dns %s\n", info.secondary_dns);

	if(sceNetApctlGetInfo(PSP_NET_APCTL_INFO_HTTP_PROXY_FLAG, &info) == 0)
	{
		printf(MODULE_NAME ": AP http_proxy_flag ");
		printf((!info.http_proxy_flag)? "PSP_NET_APCTL_INFO_HTTP_PROXY_OFF\n" : "PSP_NET_APCTL_INFO_HTTP_PROXY_ON\n");
	}
	
	if(sceNetApctlGetInfo(PSP_NET_APCTL_INFO_HTTP_PROXY_SERVER, &info) == 0)
		printf(MODULE_NAME ": AP http_proxy_server %s\n", info.http_proxy_server);

	if(sceNetApctlGetInfo(PSP_NET_APCTL_INFO_HTTP_PROXY_PORT, &info) == 0)
		printf(MODULE_NAME ": AP http_proxy_port %d\n", info.http_proxy_port);
		
}

/* Connect to an access point */
int connect_to_apctl(int config)
{
	/* Connect using the first profile */
	int r = sceNetApctlConnect(config);
	if(r != 0)
	{
		printf(MODULE_NAME ": Failed to get apctl config\n");
		CheckKernelError(r);
		return 0;
	}

	printf(MODULE_NAME ": Connecting to wifi AP\n");
	
	// last state var
	int laststate = 0;
	
	while(1)
	{
		// state var filled out by sceNetApctlGetState below
		int state = 0;
		
		// get the current apctl state
		r = sceNetApctlGetState(&state);
		if(r != 0)
		{
			printf(MODULE_NAME ": Failed to get apctl state\n");
			CheckKernelError(r);
			return 1;
		}
		
		// check the apctl state
		if(state != laststate)
		{
			switch(state)
			{
				case PSP_NET_APCTL_STATE_Disconnected:
					printf(MODULE_NAME ": Disconnected\n");
				break;
				case PSP_NET_APCTL_STATE_Scanning:
					printf(MODULE_NAME ": Scanning\n");
				break;
				case PSP_NET_APCTL_STATE_Joining:
					printf(MODULE_NAME ": Joining\n");
				break;
				case PSP_NET_APCTL_STATE_IPObtaining:
					printf(MODULE_NAME ": IP Obtaining\n");
				break;
				case PSP_NET_APCTL_STATE_IPObtained:
					printf(MODULE_NAME ": IP Obtained\n"); 
					return 0;
				break; // ip is obtained break the loop
				case PSP_NET_APCTL_STATE_MAX:
					printf(MODULE_NAME ": Max\n");
				break;
			}
		}
		
		// save the state from this loop
		laststate = state;
		
		// wait a little before polling again
		sceKernelDelayThread(50 * 1000); // 50ms
	}
	
	return 0;
}

int select_apctl_cfg(){
	
	int select = 1;

	/* pad input */
	SceCtrlData pad;
	sceCtrlSetSamplingCycle(0);
	sceCtrlSetSamplingMode(PSP_CTRL_MODE_ANALOG);

	// apctl config selection
	while(1)
	{
		pspDebugScreenSetXY(0, 2);
		printf(MODULE_NAME ": Welcome please select an access point\n");
		pspDebugScreenSetXY(0, 3);
		printf(MODULE_NAME ": AP Ctl selected: %d\n", select);
		pspDebugScreenSetXY(0, 4);
		printf(MODULE_NAME ": Press UP / DOWN to select AP, press X to choose\n");

		sceCtrlReadBufferPositive(&pad, 1);
		if (pad.Buttons != 0)
		{
			if (pad.Buttons & PSP_CTRL_UP)
			{
				if(select > 1) select--;
				sceKernelDelayThread(250000);
			}
			if (pad.Buttons & PSP_CTRL_DOWN)
			{
				// 3 wifi ap configs max (iirc)
				if(select < 3) select++;
				sceKernelDelayThread(250000);
			}
			if (pad.Buttons & PSP_CTRL_CROSS)
			{
				break;
			}
		}
	}
	
	return select;
	
}

/* Simple thread */
int main(int argc, char **argv)
{
	// set up the exit callback
	setup_callbacks();
	
	// init the debug lib
	pspDebugScreenInit();
	
	// load the network modules
	sceUtilityLoadNetModule(PSP_NET_MODULE_COMMON);
	sceUtilityLoadNetModule(PSP_NET_MODULE_INET);

	// var forreturn values
	u32 r;

	// init the network modules (in order)
	r = sceNetInit(0x20000, 0x20, 0x1000, 0x20, 0x1000);
	if(r != 0){ CheckKernelError(r); return r; }

	r = sceNetInetInit();
	if(r != 0){ CheckKernelError(r); return r; }

	r = sceNetResolverInit();
	if(r != 0){ CheckKernelError(r); return r; }
	
	r = sceNetApctlInit(0x1600, 0x42);
	if(r != 0){ CheckKernelError(r); return r; }


	int apCtrlConfSelect = select_apctl_cfg();
	
	// connect to apctl and start server
	do
	{
		/* add apctl selection */	
		if(connect_to_apctl(apCtrlConfSelect) == 0)
		{
			// print a message so we know somethings happened
			printf(MODULE_NAME ": Connected to wifi AP using config #%d\n", apCtrlConfSelect);
			
			apctl_info();
			mac_info();
			
			// connected, get my IPADDR and run test
			union SceNetApctlInfo info;
			start_server(info.ip_address, SERVER_PORT);
		}
		
	} while(0);
	
	// disconnect from ap
	sceNetApctlDisconnect();
	
	// terminate the network modules (in reverse order)

	r = sceNetApctlTerm();
	if(r != 0){ CheckKernelError(r); return r; }
	
	r = sceNetResolverTerm();
	if(r != 0){ CheckKernelError(r); return r; }
	
	r = sceNetInetTerm();
	if(r != 0){ CheckKernelError(r); return r; }
	
	r = sceNetTerm();
	if(r != 0){ CheckKernelError(r); return r; }
	
	// unload the network modules
	sceUtilityUnloadNetModule(PSP_NET_MODULE_INET);
	sceUtilityUnloadNetModule(PSP_NET_MODULE_COMMON);
	
	// exit delete
	sceKernelExitDeleteThread(0);

	return 0;
}

