/*
 * PSP Software Development Kit - https://github.com/pspdev
 * -----------------------------------------------------------------------
 * Licensed under the BSD license, see LICENSE in PSPSDK root for details.
 *
 * pspparse_http.h - Prototypes for the sceJpeg library
 *
 * Copyright (c) 2007 dot_blank
 *
 */
 
#include <libhttp/http_methods.h>
#include <libhttp/schemes.h>
#include <psptypes.h>
#include <kerneltypes.h>
#include <psperror.h>
 
#ifndef __PSPLIBPARSE_HTTP_H__
#define __PSPLIBPARSE_HTTP_H__

#ifdef __cplusplus
extern "C" {
#endif

#define PSP_PARSE_HTTP_MODULE_CODE			(0x42 << 8)
#define PSP_PARSE_HTTP_ERROR_PREFIX 		(0x805F4200)
#define PSP_PARSE_HTTP_NOT_FOUND			(0x80432025)
#define PSP_PARSE_HTTP_INVALID_RESPONSE 	(0x80432060)

int sceParseHttpResponseHeader(const SceUChar8 *header, SceSize header_len, const SceUChar8 *field_name, const SceUChar8 **field_value, SceSize *value_len);
int sceParseHttpStatusLine(const SceUChar8 *status_line, SceSize line_len, SceInt32 *http_major_ver,SceInt32 *http_minor_ver, SceInt32 *response_code, const SceUChar8 **reason_phrase, SceSize *phrase_len);


#ifdef __cplusplus
}
#endif

#endif
