/*
 * PSP Software Development Kit - https://github.com/pspdev
 * -----------------------------------------------------------------------
 * Licensed under the BSD license, see LICENSE in PSPSDK root for details.
 *
 * pspparse_uri.h - Prototypes for the sceJpeg library
 *
 * Copyright (c) 2007 dot_blank
 *
 */
 
#include <pspkerneltypes.h>
#include <psptypes.h>
 
#ifndef __PSPLIBPARSE_HTTP_H__
#define __PSPLIBPARSE_HTTP_H__

#ifdef __cplusplus
extern "C" {
#endif

#define PSP_PARSE_URI_MODULE_CODE		(0x30 << 8)

//errors
#define	PSP_URI_INVALID_ID				(0x80433100)
#define PSP_URI_OUT_OF_MEMORY			(0x80433022)
#define PSP_URI_INVALID_VALUE			(0x804331FE)
#define PSP_URI_INVALID_URI				(0x80433060)

//??
#define PSP_URI_BUILD_WITH_SCHEME		0x01
#define PSP_URI_BUILD_WITH_HOSTNAME		0x02
#define PSP_URI_BUILD_WITH_PORT			0x04
#define PSP_URI_BUILD_WITH_PATH			0x08
#define PSP_URI_BUILD_WITH_USERNAME		0x10
#define PSP_URI_BUILD_WITH_PASSWORD		0x20
#define PSP_URI_BUILD_WITH_QUERY		0x40
#define PSP_URI_BUILD_WITH_FRAGMENT		0x80
#define PSP_URI_BUILD_WITH_ALL			0xFFFF


/* example "https://user:pass@foo.com:1443/var/test.cgi?test#hoge"*/
typedef struct SceUriElement{
	SceBool			 opaque;	/* SceTrue / SceFalse */
	unsigned char	*scheme	;	/* "https" */
	unsigned char	*username;	/* "user" */
	unsigned char	*password;	/* "pass" */
	unsigned char	*hostname;	/* "foo.com" */
	unsigned char	*path;		/* "/var/test.cgi" */
	unsigned char	*query;		/* "?test" */
	unsigned char	*fragment;	/* "#hoge" */
	unsigned short	 port;		/*  1443 */
	unsigned char	 reserved[10];
} SceUriElement;

typedef void (*sceUriFreeFunction)(void *);
typedef void *(*sceUriMallocFunction)(SceSize);

#if defined(_LANGUAGE_C_PLUS_PLUS)||defined(__cplusplus)||defined(c_plusplus)
extern "C" {
#endif

int sceUriEscape(unsigned char *out, SceSize *require, SceSize prepare, const unsigned char *in);
int sceUriUnescape(unsigned char *out, SceSize *require, SceSize prepare, const unsigned char *in);
int sceUriParse(SceUriElement *out, const unsigned char *src_uri, void *pool, SceSize *require, SceSize prepare);
int sceUriBuild(unsigned char *out, SceSize *require, SceSize prepare, const SceUriElement *src_element,int option);

#ifdef __cplusplus
}
#endif

#endif
