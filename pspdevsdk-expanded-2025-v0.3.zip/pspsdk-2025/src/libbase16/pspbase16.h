/*
 * PSP Software Development Kit Expansion - https://github.com/redhate/pspdev
 * -----------------------------------------------------------------------
 * Licensed under the BSD license, see LICENSE in PSPSDK root for details.
 *
 * pspbase16.h - Prototypes for the libbase16 library
 *
 * Copyright (c) 2025 ultros
 *
 */
 
#ifndef __LIBBASE16_H__
#define __LIBBASE16_H__

#ifdef __cplusplus
extern "C" {
#endif

int   sceBase16Encoder(unsigned char *pDst, const unsigned char *pSrc, unsigned int uiSize);
int   sceBase16Decoder(unsigned char *pDst, const unsigned char *pSrc, unsigned int uiSize);

#ifdef __cplusplus
}
#endif

#endif

