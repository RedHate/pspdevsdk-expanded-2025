/*
 * PSP Software Development Kit - https://github.com/pspdev
 * -----------------------------------------------------------------------
 * Licensed under the BSD license, see LICENSE in PSPSDK root for details.
 *
 * psppower.h - Prototypes for the scePower library.
 *
 * Copyright (c) 2005 Marcus R. Brown <mrbrown@ocgnet.org>
 * Copyright (c) 2005 James Forshaw <tyranid@gmail.com>
 * Copyright (c) 2005 John Kelley <ps2dev@kelley.ca>
 * Copyright (c) 2005 David Perry <tias_dp@hotmail.com>
 *
 */
#ifndef __POWER_H__
#define __POWER_H__

#include <pspkerneltypes.h>

#ifdef __cplusplus
extern "C" {
#endif

//  Error code definition
#define PSP_POWER_ERROR_NO_BATTERY				0x802B0100		//  Battery not installed      
#define PSP_POWER_ERROR_DETECTING				0x802B0101		//  Getting battery information

/**
 * Power callback flags
 */

#define PSP_POWER_CALLBACKARG_BATTERY_CAP		0x0000007F		//  Battery Capacity                         
#define PSP_POWER_CALLBACKARG_BATTERYEXIST		0x00000080		//  Battery installation state 
#define PSP_POWER_CALLBACKARG_LOWBATTERY		0x00000100		//  Battery low state          
#define PSP_POWER_CALLBACKARG_POWERONLINE		0x00001000		//  External power supply state
#define PSP_POWER_CALLBACKARG_SUSPENDING		0x00010000		//  Suspending                 
#define PSP_POWER_CALLBACKARG_RESUMING			0x00020000		//  Resuming                   
#define PSP_POWER_CALLBACKARG_RESUME_COMP		0x00040000		//  Resume processing completed
#define PSP_POWER_CALLBACKARG_STANDINGBY		0x00080000		//  Standing by                
#define PSP_POWER_CALLBACKARG_HOLDSW			0x40000000		//  HOLD switch state          
#define PSP_POWER_CALLBACKARG_POWERSW			0x80000000		//  POWER switch state         


/**
 * Power tick flags
 */
/* All */
#define PSP_POWER_TICK_ALL		0
/* Suspend */
#define PSP_POWER_TICK_SUSPEND	1
/* Display */
#define PSP_POWER_TICK_DISPLAY	6

/**
 * Power Callback Function Definition
 *
 * @param unknown - unknown function, appears to cycle between 1,2 and 3
 * @param powerInfo - combination of PSP_POWER_CB_ flags
 */
typedef void (*powerCallback_t)(int unknown, int powerInfo);

/**
 * Register Power Callback Function
 *
 * @param slot - slot of the callback in the list, 0 to 15, pass -1 to get an auto assignment.
 * @param cbid - callback id from calling sceKernelCreateCallback
 *
 * @return 0 on success, the slot number if -1 is passed, < 0 on error.
 */
int scePowerRegisterCallback(int slot, SceUID cbid);

/**
 * Unregister Power Callback Function
 *
 * @param slot - slot of the callback
 *
 * @return 0 on success, < 0 on error.
 */
int scePowerUnregisterCallback(int slot);

/**
 * Check if unit is plugged in
 *
 * @return 1 if plugged in, 0 if not plugged in, < 0 on error.
 */
int scePowerIsPowerOnline(void);

/**
 * Check if a battery is present
 *
 * @return 1 if battery present, 0 if battery not present, < 0 on error.
 */
int scePowerIsBatteryExist(void);

/**
 * Check if the battery is charging
 *
 * @return 1 if battery charging, 0 if battery not charging, < 0 on error.
 */
int scePowerIsBatteryCharging(void);

/**
 * Get the status of the battery charging
 */
int scePowerGetBatteryChargingStatus(void);

/**
 * Check if the battery is low
 *
 * @return 1 if the battery is low, 0 if the battery is not low, < 0 on error.
 */
int scePowerIsLowBattery(void);

/**
 * Check if a suspend is required
 *
 * @return 1 if suspend is required, 0 otherwise
 */
int scePowerIsSuspendRequired(void);

/**
 * Returns battery remaining capacity
 *
 * @return battery remaining capacity in mAh (milliampere hour)
 */
int scePowerGetBatteryRemainCapacity(void);

/**
 * Returns battery full capacity
 *
 * @return battery full capacity in mAh (milliampere hour)
 */
int scePowerGetBatteryFullCapacity(void);

/**
 * Get battery life as integer percent
 *
 * @return Battery charge percentage (0-100), < 0 on error.
 */
int scePowerGetBatteryLifePercent(void);

/**
 * Get battery life as time
 *
 * @return Battery life in minutes, < 0 on error.
 */
int scePowerGetBatteryLifeTime(void);

/**
 * Get temperature of the battery
 */
int scePowerGetBatteryTemp(void);

/**
 * unknown? - crashes PSP in usermode
 */
int scePowerGetBatteryElec(void);

/**
 * Get battery volt level
 */
int scePowerGetBatteryVolt(void);

/**
 * Set CPU Frequency
 * @param cpufreq - new CPU frequency, valid values are 1 - 333
 */
int scePowerSetCpuClockFrequency(int cpufreq);

/**
 * Set Bus Frequency
 * @param busfreq - new BUS frequency, valid values are 1 - 167
 */
int scePowerSetBusClockFrequency(int busfreq);

/**
 * Alias for scePowerGetCpuClockFrequencyInt
 * @return frequency as int
 */
int scePowerGetCpuClockFrequency(void);

/**
 * Get CPU Frequency as Integer
 * @return frequency as int
 */
int scePowerGetCpuClockFrequencyInt(void);

/**
 * Get CPU Frequency as Float
 * @return frequency as float
 */
float scePowerGetCpuClockFrequencyFloat(void);

/**
 * Alias for scePowerGetBusClockFrequencyInt
 * @return frequency as int
 */
int scePowerGetBusClockFrequency(void);

/**
 * Get Bus fequency as Integer
 * @return frequency as int
 */
int scePowerGetBusClockFrequencyInt(void);

/**
 * Get Bus frequency as Float
 * @return frequency as float
 */
float scePowerGetBusClockFrequencyFloat(void);

/**
 * Set Clock Frequencies
 *
 * @param pllfreq - pll frequency, valid from 19-333
 * @param cpufreq - cpu frequency, valid from 1-333
 * @param busfreq - bus frequency, valid from 1-167
 * 
 * and:
 * 
 * cpufreq <= pllfreq
 * busfreq*2 <= pllfreq
 *
 */
int scePowerSetClockFrequency(int pllfreq, int cpufreq, int busfreq);

/**
 * Lock power switch
 *
 * Note: if the power switch is toggled while locked
 * it will fire immediately after being unlocked.
 *
 * @param unknown - pass 0
 *
 * @return 0 on success, < 0 on error.
 */
int scePowerLock(int unknown);

/**
 * Unlock power switch
 *
 * @param unknown - pass 0
 *
 * @return 0 on success, < 0 on error.
 */
int scePowerUnlock(int unknown);

/**
 * Generate a power tick, preventing unit from 
 * powering off and turning off display.
 *
 * @param type - Either PSP_POWER_TICK_ALL, PSP_POWER_TICK_SUSPEND or PSP_POWER_TICK_DISPLAY
 *
 * @return 0 on success, < 0 on error.
 */
int scePowerTick(int type);

/**
 * Get Idle timer
 *
 */
int scePowerGetIdleTimer(void);

/**
 * Enable Idle timer
 *
 * @param unknown - pass 0
 */
int scePowerIdleTimerEnable(int unknown);

/**
 * Disable Idle timer
 *
 * @param unknown - pass 0
 */
int scePowerIdleTimerDisable(int unknown);

/**
 * Request the PSP to go into standby
 *
 * @return 0 always
 */
int scePowerRequestStandby(void);

/**
 * Request the PSP to go into suspend
 *
 * @return 0 always
 */
int scePowerRequestSuspend(void);

float scePowerGetPllClockFrequencyFloat(void);

#ifdef __cplusplus
}
#endif

#endif
