/*
 * PSP Software Development Kit - https://github.com/pspdev
 * -----------------------------------------------------------------------
 * Licensed under the BSD license, see LICENSE in PSPSDK root for details.
 *
 * pspge.h - Prototypes for the sceGe library.
 *
 * Copyright (c) 2005 Marcus R. Brown <mrbrown@ocgnet.org>
 * Copyright (c) 2005 James Forshaw <tyranid@gmail.com>
 * Copyright (c) 2005 John Kelley <ps2dev@kelley.ca>
 *
 */
#ifndef __GE_H__
#define __GE_H__

#include <psptypes.h>

#ifdef __cplusplus
extern "C" {
#endif

/** Structure storing a stack (for CALL/RET) */
typedef struct SceGeStack{
	unsigned int stack[8]; /** The stack buffer */
} SceGeStack;

/* Graphics Engine save context */
typedef struct SceGeContext {
	unsigned int buffer[512];
} SceGeContext;

/** Typedef for a GE callback */
typedef void (*SceGeCallback)(int id, void *arg);

/* Callback parameters */
typedef struct SceGeCbParam {
	void	(*pSignalFunc)(int, void *);	/** GE callback for the signal interrupt */
	void	*pSignalCookie;					/** GE callback argument for signal interrupt */
	void	(*pFinishFunc)(int, void *);	/** GE callback for the finish interrupt */
	void	*pFinishCookie;					/** GE callback argument for finish interrupt */
} SceGeCbParam;

typedef struct SceGeListArgs
{
	/** Size of the structure (16) */
	unsigned int	size;
	/** Pointer to a context */
	SceGeContext*	context;
	/** Number of stacks to use */
	u32 numStacks;
	/** Pointer to the stacks (unused) */
	SceGeStack *stacks;
} SceGeListArgs;


/** Structure to hold the callback data */
typedef struct SceGeCallbackData
{
	/** GE callback for the signal interrupt */
	SceGeCallback signal_func;
	/** GE callback argument for signal interrupt */
	void *signal_arg;
	/** GE callback for the finish interrupt */
	SceGeCallback finish_func;
	/** GE callback argument for finish interrupt */
	void *finish_arg;
} SceGeCallbackData;

/**
 * Drawing queue interruption parameter
 */
typedef struct SceGeBreakParam {
	unsigned int	buf[4];
} SceGeBreakParam;

/**
 * Get the size of VRAM.
 *
 * @return The size of VRAM (in bytes).
 */
unsigned int sceGeEdramGetSize(void);

/**
 * Sets the EDRAM size to be enabled.
 *
 * @param size -size	The size (0x200000 or 0x400000). Will return an error if 0x400000 is specified for the PSP FAT.
 *
 * @return Zero on success, otherwise less than zero. 
 */
int sceGeEdramSetSize(int size);

/**
  * Get the eDRAM address.
  *
  * @return A pointer to the base of the eDRAM.
  */
void * sceGeEdramGetAddr(void);

/**
 * Retrieve the current value of a GE command.
 *
 * @param cmdno - The GE command register to retrieve (0 to 0xFF, both included).
 *
 * @return The value of the GE command, < 0 on error.
 */
unsigned int sceGeGetCmd(int cmdno);

/** GE matrix types. */
/* Get Graphics Engine matrix register */
#define PSP_GE_MTX_BONEA		0				/* bone matrix               */
#define PSP_GE_MTX_BONEB		1				/* bone matrix               */
#define PSP_GE_MTX_BONEC		2				/* bone matrix               */
#define PSP_GE_MTX_BONED		3				/* bone matrix               */
#define PSP_GE_MTX_BONEE		4				/* bone matrix               */
#define PSP_GE_MTX_BONEF		5				/* bone matrix               */
#define PSP_GE_MTX_BONEG		6				/* bone matrix               */
#define PSP_GE_MTX_BONEH		7				/* bone matrix               */
#define PSP_GE_MTX_WORLD		8				/* world matrix              */
#define PSP_GE_MTX_VIEW			9				/* view matrix               */
#define PSP_GE_MTX_PROJ			10				/* projection matrix         */
#define PSP_GE_MTX_TGEN			11				/* texture generating matrix */

/**
 * Retrieve a matrix of the given type.
 *
 * @param type - One of ::SceGeMatrixTypes.
 * @param matrix - Pointer to a variable to store the matrix.
 *
 * @return < 0 on error.
 */
int sceGeGetMtx(int type, void *matrix);

/**
 * Retrieve the stack of the display list currently being executed.
 *
 * @param stackId - The ID of the stack to retrieve.
 * @param stack - Pointer to a structure to store the stack, or NULL to not store it.
 *
 * @return The number of stacks of the current display list, < 0 on error.
 */
int sceGeGetStack(int stackId, SceGeStack *stack);


/**
 * Save the GE's current state.
 *
 * @param pCtx - Pointer to a ::SceGeContext.
 *
 * @return < 0 on error.
 */
int   sceGeSaveContext(SceGeContext *pCtx);

/**
 * Restore a previously saved GE context.
 *
 * @param pCtx - Pointer to a ::SceGeContext.
 *
 * @return < 0 on error.
 */
int   sceGeRestoreContext(const SceGeContext *pCtx);

/* Display list issuing options */
typedef struct SceGeListOptParam {
	unsigned int size;					/* sizeof(SceGeListOptParam) */
	SceGeContext *pGeContext;			/* context save area */
} SceGeListOptParam;

/**
  * Enqueue a display list at the tail of the GE display list queue.
  *
  * @param pMadr - The head of the list to queue.
  * @param pSadr - The stall address.
  * If NULL then no stall address is set and the list is transferred immediately.
  * @param cbid - ID of the callback set by calling sceGeSetCallback
  * @param pOpt - Structure containing GE context buffer address
  *
  * @return The ID of the queue, < 0 on error.
  */
int sceGeListEnQueue(const void *pMadr, const void *pSadr, int cbid, const SceGeListOptParam *pOpt);

/**
  * Enqueue a display list at the head of the GE display list queue.
  *
  * @param pMadr - The head of the list to queue.
  * @param pSadr - The stall address.
  * If NULL then no stall address is set and the list is transferred immediately.
  * @param cbid - ID of the callback set by calling sceGeSetCallback
  * @param pOpt - Structure containing GE context buffer address
  *
  * @return The ID of the queue, < 0 on error.
  */
int sceGeListEnQueueHead(const void *pMadr, const void *pSadr, int cbid, const SceGeListOptParam *pOpt);

/**
 * Cancel a queued or running list.
 *
 * @param qid - The ID of the queue.
 *
 * @return < 0 on error.
 */
int sceGeListDeQueue(int id);

/**
  * Update the stall address for the specified queue.
  *
  * @param id - The ID of the queue.
  * @param pSadr - The new stall address.
  *
  * @return < 0 on error
  */
int sceGeListUpdateStallAddr(int id, const void *pSadr);


/* Wait for display list completion */
#define PSP_GE_LIST_COMPLETED		0	/* Display list execution completed               */
#define PSP_GE_LIST_QUEUED			1	/* Queued                                         */
#define PSP_GE_LIST_DRAWING			2	/* Drawing operation in progress                  */
#define PSP_GE_LIST_STALLING		3	/* Reached stall address during drawing operation */
#define PSP_GE_LIST_PAUSED			4	/* Display list was interrupted                   */

/**
  * Wait for syncronisation of a list.
  *
  * @param id - The queue ID of the list to sync.
  * @param mode - 0 if you want to wait for the list to be completed, or 1 if you just want to peek the actual state.
  *
  * @return The specified queue status, one of ::SceGeListState.
  */
int sceGeListSync(int id, int mode);

/**
  * Wait for drawing to complete.
  *
  * @param mode - 0 if you want to wait for the drawing to be completed, or 1 if you just want to peek the state of the display list currently being executed.
  *
  * @return The current queue status, one of ::SceGeListState.
  */
int sceGeDrawSync(int mode);

/**
  * Register callback handlers for the the GE.
  *
  * @param cb - Configured callback data structure.
  *
  * @return The callback ID, < 0 on error.
  */
int sceGeSetCallback(SceGeCbParam *pParam);

/**
  * Unregister the callback handlers.
  *
  * @param id - The ID of the callbacks, returned by sceGeSetCallback().
  *
  * @return < 0 on error
  */
int sceGeUnsetCallback(int id);

/**
 * Interrupt drawing queue.
 *
 * @param mode - If set to 1, reset all the queues.
 * @param pParam - Unused (just K1-checked).
 *
 * @return The stopped queue ID if mode isn't set to 0, otherwise 0, and < 0 on error.
 */
int sceGeBreak(int mode, SceGeBreakParam *pParam);

/**
 * Restart drawing queue.
 *
 * @return < 0 on error.
 */
int sceGeContinue(void);

/**
 * Set the eDRAM address translation mode.
 *
 * @param width - 0 to not set the translation width, otherwise 512, 1024, 2048 or 4096.
 *
 * @return The previous width if it was set, otherwise 0, < 0 on error.
 */
int sceGeEdramSetAddrTranslation(int width);


#ifdef __cplusplus
}
#endif

#endif /* __GE_H__ */
