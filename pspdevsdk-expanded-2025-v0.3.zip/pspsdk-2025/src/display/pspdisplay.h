/*
 * PSP Software Development Kit - https://github.com/pspdev
 * -----------------------------------------------------------------------
 * Licensed under the BSD license, see LICENSE in PSPSDK root for details.
 *
 * pspdisplay.h - Prototypes for the sceDisplay library.
 *
 * Copyright (c) 2005 Marcus R. Brown <mrbrown@ocgnet.org>
 * Copyright (c) 2005 James Forshaw <tyranid@gmail.com>
 * Copyright (c) 2005 John Kelley <ps2dev@kelley.ca>
 * Copyright (c) 2007 Alexander Berl <raphael@fx-world.org>
 *
 */
#ifndef __DISPLAY_H__
#define __DISPLAY_H__

#ifdef __cplusplus
extern "C" {
#endif


// errors
#define PSP_DISPLAY_ERROR_OK    	 (0)
#define PSP_DISPLAY_ERROR_POINTER    (0x80000103)
#define PSP_DISPLAY_ERROR_ARGUMENT   (0x80000107)


#define PSP_DISPLAY_MODE_LCD			0				// LCDC output mode                            
#define PSP_DISPLAY_MODE_VESA1A			0x1A			// VESA 1A(VGA) output mode                    
#define PSP_DISPLAY_MODE_PSEUDO_VGA		0x60			// pseudo VGA output mode                      

/*
	Output Mode						Pixel shape		VSYNC freq(theoretical)	Available
	----------------------------------------------------------------------------------------------------
	PSP_DISPLAY_MODE_LCD			Square			59.94005995Hz			Both actual PSP(TM) and TOOL
	PSP_DISPLAY_MODE_VESA1A			Square			59.94047618Hz			TOOL only
	PSP_DISPLAY_MODE_PSEUDO_VGA		NOT square		59.94005995Hz			TOOL only
*/

#define PSP_DISPLAY_PIXEL_RGB565		0				// R:G:B  =5:6:5    16bit 
#define PSP_DISPLAY_PIXEL_RGBA5551		1				// R:G:B:A=5:5:5:1  16bit 
#define PSP_DISPLAY_PIXEL_RGBA4444		2				// R:G:B:A=4:4:4:4  16bit 
#define PSP_DISPLAY_PIXEL_RGBA8888		3				// R:G:B:A=8:8:8:8  32bit 


/**
 * Set display mode
 *
 * @par Example1:
 * @code
 * @endcode
 *
 * @param iMode - Display mode, normally 0.
 * @param iDisplayWidth - Width of screen in pixels.
 * @param iDisplayHeight - Height of screen in pixels.
 *
 * @return ???
 */
int sceDisplaySetMode(int iMode, int iDisplayWidth, int iDisplayHeight);

/**
 * Get display mode
 *
 * @param piMode - Pointer to an integer to receive the current mode.
 * @param piDisplayWidth - Pointer to an integer to receive the current width.
 * @param piDisplayHeight - Pointer to an integer to receive the current height,
 *
 * @return 0 on success
 */
int sceDisplayGetMode(int *piMode, int *piDisplayWidth, int *piDisplayHeight);

/**
 * Display set framebuf
 *
 * @param ppFrameBuf - address of start of framebuffer
 * @param piFrameWidth - buffer width (must be power of 2)
 * @param piPixelFormat - One of ::sceDisplayPixelFormats.
 * @param iUpdateTimingMode - One of ::sceDisplaySetBufSync
 *
 * @return 0 on success
 */

#define PSP_DISPLAY_UPDATETIMING_NEXTHSYNC	0
#define PSP_DISPLAY_UPDATETIMING_NEXTVSYNC	1
int sceDisplaySetFrameBuf(const void *pFrameBuf, int iFrameWidth, int iPixelFormat, int iUpdateTimingMode);
/**
 * Get Display Framebuffer information
 *
 * @param ppFrameBuf - pointer to void* to receive address of start of framebuffer
 * @param piFrameWidth - pointer to int to receive buffer width (must be power of 2)
 * @param piPixelFormat - pointer to int to receive one of ::sceDisplayPixelFormats.
 * @param iUpdateTimingMode - One of ::sceDisplaySetBufSync
 *
 * @return 0 on success
 */
int sceDisplayGetFrameBuf(const void **ppFrameBuf, int *piFrameWidth, int *piPixelFormat, int iUpdateTimingMode);

/**
 * Number of vertical blank pulses up to now
 */
unsigned int sceDisplayGetVcount(void);

/**
 * Wait for vertical blank start
 */
int sceDisplayWaitVblankStart(void);

/**
 * Wait for vertical blank start with callback
 */
int sceDisplayWaitVblankStartCB(void);

/**
 * Wait for vertical blank
 */
int sceDisplayWaitVblank(void);

/**
 * Wait for vertical blank with callback
 */
int sceDisplayWaitVblankCB(void);

/**
 * Get accumlated HSYNC count
 */
int sceDisplayGetAccumulatedHcount(void);

/**
 * Get current HSYNC count
 */
int sceDisplayGetCurrentHcount(void);

/**
 * Get number of frames per second
 */
float sceDisplayGetFramePerSec(void);

/**
 * Get whether or not frame buffer is being displayed
 */
int sceDisplayIsForeground(void);

/**
 * Test whether VBLANK is active
 */
int sceDisplayIsVblank(void);

/** 
 * Registers interrupt callback that is called at the start of VBLANK 
 */
int sceDisplaySetVblankCallback(int idx, void (*pFunc)(int idx, void *cookie), void *cookie);

/*
    //in stub library but no prototype deduced.
	IMPORT_FUNC	"sceDisplay",0x7ED59BC4,sceDisplaySetHoldMode
	IMPORT_FUNC	"sceDisplay",0xA544C486,sceDisplaySetResumeMode
 */

#ifdef __cplusplus
}
#endif

#endif
